# Zuparty — Server-first launch setup

## What this build does
- Wallet starts at **0 Coins** for the clean launch state.
- Games read and mutate Coins only through server RPCs.
- Client users cannot update the `zp_profiles.coins` column directly.
- Fake/mock room lists were removed from Home and Search. Rooms shown there come from `zp_rooms`.
- New rooms are refreshed on Home every 15 seconds and immediately after creation.
- Users can submit an **Agent application** from Profile.
- Approved agents get the **وكيل شحن Zuparty** badge and a remote server-served recharge panel.
- Admins can review agent applications from the same remote panel.
- Electronic payment methods remain closed.

## Supabase deployment
1. Run `supabase/migrations/20260831000000_zuparty_backend.sql` in the Supabase SQL editor or deploy it with the Supabase CLI.
2. Deploy the Edge Function at `supabase/functions/agent-panel`.
3. Make sure Anonymous Auth is enabled because the current app uses anonymous sessions.
4. Create the first admin manually after you know the admin's Supabase user UUID:

```sql
insert into public.zp_staff_roles(user_id, role, status, badge)
values ('YOUR_ADMIN_USER_UUID', 'admin', 'active', 'إدارة Zuparty')
on conflict (user_id) do update set role='admin', status='active', badge='إدارة Zuparty';
```

Do not put service-role keys in Flutter or in the Edge Function source. The Edge Function uses the caller's user JWT and the public/publishable Supabase key.

## Agent flow
User → Profile → طلب صفة وكيل شحن → server application → Admin approves → role becomes `agent` → app shows badge and opens the remote panel. No app update is required when an agent is approved.

## Recharge flow
Agent enters the user's UUID and Coins → server RPC checks active agent role → locks the user's wallet row → increments Coins → writes an immutable wallet transaction. The Flutter client never writes the balance itself.

## Important launch note
The SQL migration intentionally resets existing test profiles to **0 Coins** for the requested clean launch state. Remove that final reset statement before production if existing balances must be preserved.
