import { createClient } from 'npm:@supabase/supabase-js@2';
import { RtcRole, RtcTokenBuilder } from 'npm:agora-token@2.0.5';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response(JSON.stringify({ error: 'method_not_allowed' }), { status: 405, headers: { ...cors, 'Content-Type': 'application/json' } });

  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('missing_authorization');

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) throw new Error('not_authenticated');

    const body = await req.json();
    const channel = String(body.channel ?? '').trim();
    const uid = Number(body.uid ?? 0);
    if (!channel || channel.length > 64 || !Number.isInteger(uid) || uid <= 0 || uid > 4294967295) {
      throw new Error('invalid_channel_or_uid');
    }

    const appId = Deno.env.get('AGORA_APP_ID');
    const certificate = Deno.env.get('AGORA_APP_CERTIFICATE');
    if (!appId || !certificate) throw new Error('agora_server_secrets_missing');

    const expiresIn = 3600;
    const privilegeExpiredTs = Math.floor(Date.now() / 1000) + expiresIn;
    const token = RtcTokenBuilder.buildTokenWithUid(
      appId,
      certificate,
      channel,
      uid,
      RtcRole.PUBLISHER,
      privilegeExpiredTs,
    );

    return new Response(JSON.stringify({ token, appId, uid, channel, expiresAt: privilegeExpiredTs }), {
      headers: { ...cors, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : 'internal_error' }), {
      status: 400,
      headers: { ...cors, 'Content-Type': 'application/json' },
    });
  }
});
