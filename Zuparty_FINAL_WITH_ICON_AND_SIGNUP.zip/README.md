# Zuparty — واجهة أولية (UI فقط) — نسخة محدّثة

## كيفية التشغيل

1. تأكد أن Flutter مثبت عندك: https://docs.flutter.dev/get-started/install
2. فك ضغط الملف وادخل للمجلد:
   ```
   cd zuparty
   ```
3. حمّل الاعتماديات:
   ```
   flutter pub get
   ```
4. شغّل التطبيق:
   ```
   flutter run
   ```

## محتوى الشاشات (كلها فارغة/مؤقتة، UI فقط بلا وظائف حقيقية)

- **رأسية**: دائرة بحث + إطار فيه 4 مربعات فارغة (اختصارات تطبيقات) + 3 مربعات فارغة تحتهم
- **غرفة**: إطار فيه دائرة بعلامة + فالنص
- **دردشة**: دائرتين على اليسار (أيقونة تطبيقات + أيقونة هدية)
- **بروفيل**: إطار فيه دائرة فارغة للصورة + أزرار (دعوة الأصدقاء، VIP، SVIP، خدمة العملاء، الإعدادات) + 3 دوائر صغار فالأسفل (جوج فيهم + ووحدة فارغة)

## الخطوة الجاية

- ربط شاشة الغرفة بنظام صوتي حقيقي (LiveKit / Agora)
- ربط تسجيل الدخول والبروفيل بـ backend حقيقي
- إضافة منطق الألعاب والاختصارات

## ملاحظات معروفة (Phase 1)

- التطبيق حاليًا مثبّت على `Directionality: RTL` بشكل كامل عبر `MaterialApp.builder` لأن المحتوى كله عربي. هذا طبيعي فهاد المرحلة، وغادي يتبدّل لنظام ديناميكي (RTL/LTR حسب اللغة المختارة) فمرحلة تعدد اللغات (i18n).
- الخط المستعمل حاليًا هو خط النظام الافتراضي (بلا Font مخصص مرفق فالمشروع). إذا تزاد خط زعما "Cairo" فـ `assets/fonts/` ويتصرح فـ `pubspec.yaml` تحت `flutter/fonts`، يقدر يترتبط فـ `lib/theme/app_theme.dart`.

## كيفاش تحط صور ديالك بدل الأيقونات

1. حط الصور ديالك (PNG/JPG) جوة المجلد `assets/images/`
   مثال: `assets/images/search.png`
2. فملف `pubspec.yaml` هادشي راه مكتوب ديجا:
   ```yaml
   flutter:
     assets:
       - assets/images/
   ```
3. فملف `lib/main.dart`، الدوائر (`_CircleIcon`) تقدر تاخد صورة بدل الأيقونة:
   ```dart
   // بدل
   const _CircleIcon(icon: Icons.search),
   // كتب
   const _CircleIcon(imagePath: 'assets/images/search.png'),
   ```
4. بعد ما تزيد الصور، دير:
   ```
   flutter pub get
   flutter run
   ```

نفس الطريقة تصدق على أيقونات الشريط السفلي (`BottomNavigationBarItem`) — بدل `Icon(_icons[i])` بـ `Image.asset('assets/images/your_icon.png')`.


## Latest visual update
- App launcher icon uses the supplied Zuparty game-cat image.
- Account sign-up/login screen uses the supplied purple social image as its background.
