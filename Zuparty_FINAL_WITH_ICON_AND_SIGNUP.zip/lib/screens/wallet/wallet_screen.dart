import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../routing/app_page_route.dart';
import '../../services/zuparty_backend.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import 'transactions_screen.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool _loading = true;
  int _balance = MockData.userCoinBalance;
  List<WalletTransaction> _transactions = [];

  @override
  void initState() {
    super.initState();
    _loadWallet();
  }

  Future<void> _loadWallet() async {
    try {
      final profile = await ZupartyBackend.instance.getWalletProfile();
      final rows = await ZupartyBackend.instance.getWalletTransactions();
      final balance = (profile['coins'] as num?)?.toInt() ?? 0;
      final txs = rows.map(_txFromRow).toList();
      if (mounted) {
        setState(() {
          _balance = balance;
          MockData.userCoinBalance = balance;
          _transactions = txs;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  WalletTransaction _txFromRow(Map<String, dynamic> row) {
    final type = switch (row['type']?.toString()) {
      'recharge' => WalletTxType.recharge,
      'game_win' => WalletTxType.gameWin,
      'game_bet' => WalletTxType.gameLoss,
      'gift_sent' => WalletTxType.giftSent,
      'gift_received' => WalletTxType.giftReceived,
      'vip_sub' => WalletTxType.vipSub,
      _ => WalletTxType.recharge,
    };
    final created = DateTime.tryParse(row['created_at']?.toString() ?? '') ?? DateTime.now();
    return WalletTransaction(
      id: row['id']?.toString() ?? created.microsecondsSinceEpoch.toString(),
      type: type,
      title: _titleFor(row['type']?.toString()),
      amount: (row['amount'] as num?)?.toInt() ?? 0,
      time: created.toLocal(),
    );
  }

  String _titleFor(String? type) {
    switch (type) {
      case 'game_win': return 'ربح لعبة';
      case 'game_bet': return 'لعب — خصم Coins';
      case 'recharge': return 'إعادة شحن';
      default: return type ?? 'معاملة';
    }
  }

  Future<void> _openRecharge(CoinPackage pkg) async {
    final ok = await zpConfirmSheet(
      context,
      title: 'طلب شحن ${pkg.priceLabel}',
      message: 'سيتم إنشاء طلب دفع على السيرفر بقيمة ${pkg.priceLabel} مقابل ${pkg.coins} Coins. هذه النسخة لا تنفّذ تحويل USDT الحقيقي ولا تضيف الرصيد تلقائياً.',
      confirmLabel: 'إنشاء الطلب',
      icon: Icons.add_card_rounded,
      color: AppColors.primary,
    );
    if (!ok || !mounted) return;
    try {
      final usd = int.parse(pkg.priceLabel.replaceAll(RegExp(r'[^0-9]'), ''));
      final order = await ZupartyBackend.instance.createRechargeOrder(
        packageId: pkg.id,
        usdCents: usd * 100,
        coins: pkg.coins,
        paymentMethod: 'usdt_bep20_demo',
      );
      if (!mounted) return;
      zpToast(context, 'تم إنشاء طلب الشحن ${order['id']}. بانتظار التحقق من الدفع.');
    } catch (e) {
      if (mounted) zpToast(context, 'تعذر إنشاء طلب الشحن: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: zpAppBar('المحفظة', actions: [
        IconButton(
          icon: const Icon(Icons.receipt_long_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.push(context, appPageRoute(builder: (_) => TransactionsScreen(serverTransactions: _transactions))),
        ),
      ]),
      body: _loading
          ? const AppSkeletonList(itemCount: 6, itemHeight: 60)
          : RefreshIndicator(
              onRefresh: _loadWallet,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(AppSpacing.lg),
                children: [
                  _buildBalanceCard(),
                  const SizedBox(height: AppSpacing.xl),
                  // Recharge methods are intentionally hidden for regular users.
                  // Agent/manual recharge will be exposed later from the admin/agent panel.
                  ZpSectionHeader(title: 'آخر المعاملات', actionLabel: 'عرض الكل', onAction: () => Navigator.push(context, appPageRoute(builder: (_) => TransactionsScreen(serverTransactions: _transactions)))),
                  ..._buildRecentTx(),
                ],
              ),
            ),
    );
  }

  Widget _buildBalanceCard() => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(AppSpacing.xl),
    decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl), boxShadow: AppShadows.card),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('رصيدك الحالي', style: TextStyle(color: Colors.white70, fontSize: 12.5)),
      const SizedBox(height: 6),
      Row(children: [const Icon(Icons.monetization_on_rounded, color: Colors.white, size: 28), const SizedBox(width: 8), Text('$_balance', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 30))]),
      const SizedBox(height: 4),
      const Text('Coins — محفوظة على السيرفر', style: TextStyle(color: Colors.white70, fontSize: 12)),
    ]),
  );

  Widget _buildPackagesGrid() => GridView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    padding: const EdgeInsets.only(top: AppSpacing.sm),
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: .78),
    itemCount: MockData.coinPackages.length,
    itemBuilder: (_, i) {
      final pkg = MockData.coinPackages[i];
      return GestureDetector(
        onTap: () => _openRecharge(pkg),
        child: Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.md), border: Border.all(color: pkg.isBestValue ? AppColors.primary : AppColors.border), boxShadow: AppShadows.card),
          child: Stack(children: [
            if (pkg.isBestValue) Positioned(top: 0, right: 0, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3), decoration: const BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.only(topRight: Radius.circular(AppRadius.md), bottomLeft: Radius.circular(AppRadius.md))), child: const Text('الأفضل', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800)))),
            Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.monetization_on_rounded, color: Color(0xFFF9A825), size: 26), const SizedBox(height: 6), Text('${pkg.coins}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)), const SizedBox(height: 4), Text(pkg.priceLabel, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))])),
          ]),
        ),
      );
    },
  );

  List<Widget> _buildRecentTx() {
    final tx = _transactions.take(4).toList();
    if (tx.isEmpty) return [const AppEmptyState(icon: Icons.receipt_long_outlined, title: 'لا توجد معاملات بعد')];
    return tx.map((t) => TxTile(tx: t)).toList();
  }
}

class TxTile extends StatelessWidget {
  final WalletTransaction tx;
  const TxTile({super.key, required this.tx});
  IconData get _icon => switch (tx.type) {
    WalletTxType.recharge => Icons.add_card_rounded,
    WalletTxType.giftSent => Icons.card_giftcard_rounded,
    WalletTxType.giftReceived => Icons.redeem_rounded,
    WalletTxType.gameWin => Icons.emoji_events_rounded,
    WalletTxType.gameLoss => Icons.sports_esports_rounded,
    WalletTxType.vipSub => Icons.workspace_premium_rounded,
  };
  @override
  Widget build(BuildContext context) {
    final positive = tx.amount >= 0;
    return Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(AppSpacing.md), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.md), boxShadow: AppShadows.card), child: Row(children: [
      Container(width: 40, height: 40, decoration: BoxDecoration(color: (positive ? AppColors.success : AppColors.danger).withOpacity(.1), shape: BoxShape.circle), child: Icon(_icon, size: 19, color: positive ? AppColors.success : AppColors.danger)),
      const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tx.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)), Text('${tx.time.day}/${tx.time.month} — ${tx.time.hour.toString().padLeft(2,'0')}:${tx.time.minute.toString().padLeft(2,'0')}', style: const TextStyle(fontSize: 10.5, color: AppColors.grey500))])),
      Text('${positive ? '+' : ''}${tx.amount}', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: positive ? AppColors.success : AppColors.danger)),
    ]));
  }
}
