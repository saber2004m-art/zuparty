import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../routing/app_page_route.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import 'gift_history_screen.dart';
import '../../services/zuparty_backend.dart';

/// ============================================================
/// Phase 5 — Part 2: Gift Center — تصنيفات، بطاقات هدايا،
/// إرسال هدية (Local UI)، آخر الهدايا، سجل الهدايا.
/// ============================================================
class GiftCenterScreen extends StatefulWidget {
  const GiftCenterScreen({super.key});

  @override
  State<GiftCenterScreen> createState() => _GiftCenterScreenState();
}

class _GiftCenterScreenState extends State<GiftCenterScreen> {
  late List<GiftCategoryModel> _categories;
  int _selected = 0;
  bool _loading = true;
  int _balance = 0;

  @override
  void initState() {
    super.initState();
    _categories = MockData.giftCategories;
    _loadBalance();
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  Future<void> _loadBalance() async {
    try {
      final row = await ZupartyBackend.instance.getWalletProfile();
      if (mounted) setState(() => _balance = (row['coins'] as num?)?.toInt() ?? 0);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('p7_gifts_title'), actions: [
        IconButton(
          icon: const Icon(Icons.history_rounded, color: AppColors.textPrimary),
          tooltip: S.tr('p7_gift_history'),
          onPressed: () => Navigator.push(context, appPageRoute(builder: (_) => const GiftHistoryScreen())),
        ),
      ]),
      body: _loading
          ? const AppSkeletonList(itemCount: 5, itemHeight: 70)
          : Column(
              children: [
                _buildBalanceBar(),
                _buildCategoryTabs(),
                Expanded(child: _buildGiftGrid()),
                _buildRecentGifts(),
              ],
            ),
    );
  }

  Widget _buildBalanceBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, 0),
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.md),
      decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.lg)),
      child: Row(
        children: [
          const Icon(Icons.monetization_on_rounded, color: Colors.white, size: 22),
          const SizedBox(width: 8),
          Text(S.tr('p7_balance'), style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
          const SizedBox(width: 6),
          Text('$_balance', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
          const Spacer(),
          const Text('Coins', style: TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildCategoryTabs() {
    return SizedBox(
      height: 46,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
        itemCount: _categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final selected = i == _selected;
          return GestureDetector(
            onTap: () => setState(() => _selected = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: selected ? AppColors.primary : AppColors.surface,
                borderRadius: BorderRadius.circular(AppRadius.pill),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(_categories[i].icon, size: 15, color: selected ? Colors.white : AppColors.grey600),
                  const SizedBox(width: 6),
                  Text(_categories[i].label, style: TextStyle(color: selected ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.w700, fontSize: 12.5)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildGiftGrid() {
    final gifts = _categories[_selected].gifts;
    if (gifts.isEmpty) {
      return AppEmptyState(icon: Icons.card_giftcard_outlined, title: S.tr('p7_no_gifts_category'));
    }
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.sm),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.78),
      itemCount: gifts.length,
      itemBuilder: (context, i) => _GiftCard(
        gift: gifts[i],
        onTap: () => _openSendSheet(gifts[i]),
      ),
    );
  }

  Widget _buildRecentGifts() {
    final recent = MockData.voiceRoomGiftHistory;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
      decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.divider))),
      child: SizedBox(
        height: 64,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
          itemCount: recent.length,
          separatorBuilder: (_, __) => const SizedBox(width: 14),
          itemBuilder: (context, i) => Row(
            children: [
              ZpAvatar(imagePath: recent[i].sender.avatarPath, size: 34),
              const SizedBox(width: 6),
              Text(recent[i].gift.emoji, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 2),
              Text('x${recent[i].quantity}', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openSendSheet(GiftModel gift) async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl))),
      builder: (_) => SendGiftSheet(receiverName: 'ربيع', initialGift: gift),
    );
    if (result != null && mounted) {
      _showGiftAnimation(result['gift'] as GiftModel);
    }
  }

  void _showGiftAnimation(GiftModel gift) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'gift',
      barrierColor: Colors.black.withOpacity(0.35),
      transitionDuration: const Duration(milliseconds: 350),
      pageBuilder: (_, __, ___) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim, __, ___) {
        final scale = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: anim, curve: Curves.elasticOut));
        return Opacity(
          opacity: anim.value.clamp(0, 1),
          child: ScaleTransition(
            scale: scale,
            child: Center(
              child: Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl), boxShadow: AppShadows.floating),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(gift.emoji, style: const TextStyle(fontSize: 64)),
                    const SizedBox(height: 10),
                    Text(S.trParams('p7_gift_sent', {'gift': gift.name}), style: AppTextStyles.h3),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
    Future.delayed(const Duration(milliseconds: 1100), () {
      if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
    });
  }
}

class _GiftCard extends StatelessWidget {
  final GiftModel gift;
  final VoidCallback onTap;
  const _GiftCard({required this.gift, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(AppRadius.md)),
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(gift.emoji, style: const TextStyle(fontSize: 30)),
            const SizedBox(height: 4),
            Text(gift.name, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.monetization_on_rounded, size: 11, color: Color(0xFFF9A825)),
                const SizedBox(width: 2),
                Text('${gift.price}', style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondary)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom Sheet موحّد لإرسال هدية — يُستعمل من Chat وGift Center
/// (اختيار هدية + كمية + تأكيد) — Local UI فقط، يرجّع النتيجة للمستدعي.
class SendGiftSheet extends StatefulWidget {
  final String receiverName;
  final GiftModel? initialGift;
  const SendGiftSheet({super.key, required this.receiverName, this.initialGift});

  @override
  State<SendGiftSheet> createState() => _SendGiftSheetState();
}

class _SendGiftSheetState extends State<SendGiftSheet> {
  late GiftModel _selected;
  int _quantity = 1;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _selected = widget.initialGift ?? MockData.gifts.first;
  }

  Future<void> _confirm() async {
    setState(() => _sending = true);
    try {
      // Safe build: gift balance is authoritative on the server.
      // The receiver ID must come from a real room/member profile, never from a hardcoded mock user.
      throw StateError('real_receiver_required');
    } catch (e) {
      if (mounted) {
        setState(() => _sending = false);
        zpToast(context, 'الإرسال يحتاج معرف المستخدم الحقيقي من السيرفر.', icon: Icons.info_outline_rounded);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.xl),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
              const SizedBox(height: AppSpacing.md),
              Text(S.trParams('p7_send_gift_to', {'name': widget.receiverName}), style: AppTextStyles.h3),
              const SizedBox(height: AppSpacing.md),
              SizedBox(
                height: 92,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: MockData.gifts.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, i) {
                    final g = MockData.gifts[i];
                    final selected = g.id == _selected.id;
                    return GestureDetector(
                      onTap: () => setState(() => _selected = g),
                      child: Container(
                        width: 76,
                        decoration: BoxDecoration(
                          color: selected ? AppColors.primary.withOpacity(0.1) : AppColors.surface,
                          borderRadius: BorderRadius.circular(AppRadius.md),
                          border: Border.all(color: selected ? AppColors.primary : Colors.transparent, width: 1.5),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(g.emoji, style: const TextStyle(fontSize: 26)),
                            const SizedBox(height: 4),
                            Text(g.name, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
                            Text('${g.price}', style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              Row(
                children: [
                  Text(S.tr('p7_quantity'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                  const Spacer(),
                  _qtyButton(Icons.remove_rounded, () => setState(() => _quantity = (_quantity - 1).clamp(1, 99))),
                  SizedBox(width: 36, child: Text('$_quantity', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800))),
                  _qtyButton(Icons.add_rounded, () => setState(() => _quantity = (_quantity + 1).clamp(1, 99))),
                ],
              ),
              const SizedBox(height: AppSpacing.lg),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: _sending ? null : _confirm,
                  icon: _sending
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.card_giftcard_rounded, size: 18),
                  label: Text(_sending ? S.tr('p7_sending') : S.trParams('p7_send_for', {'cost': (_selected.price * _quantity).toString()})),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _qtyButton(IconData icon, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(width: 32, height: 32, decoration: const BoxDecoration(color: AppColors.surface, shape: BoxShape.circle), child: Icon(icon, size: 16)),
      );
}
