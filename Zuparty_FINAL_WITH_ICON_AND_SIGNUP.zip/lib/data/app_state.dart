/// Session-level display state. Authoritative Coins always live on the server.
class AppState {
  static String userName = 'مستخدم Zuparty';
  static String? userGender;
  static bool isNewAccount = true;
  static int userCoins = 0;
}
