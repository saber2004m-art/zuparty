import 'dart:math';
import 'package:supabase_flutter/supabase_flutter.dart';

class ZupartyConfig {
  static const supabaseUrl = 'https://kwlcvnyznahfkyfvmymw.supabase.co';
  static const supabasePublishableKey = 'sb_publishable_pzWRXTsydWX_FoyWnF_Tmg_5VWO-vKd';
  static const agoraAppId = '9c9ae439ddc34fc383b97ccf34dacd5a';
}

class ZupartyBackend {
  ZupartyBackend._();
  static final instance = ZupartyBackend._();
  SupabaseClient get client => Supabase.instance.client;

  Future<void> ensureSignedIn() async {
    if (client.auth.currentSession != null && client.auth.currentUser != null) return;
    throw StateError('not_authenticated');
  }

  Future<AuthResponse> signUp({required String email, required String password, required String name, String? gender}) async {
    final response = await client.auth.signUp(email: email.trim(), password: password);
    if (response.user != null && response.session != null) {
      await ensureProfile(name: name, gender: gender);
    }
    return response;
  }

  Future<AuthResponse> signIn({required String email, required String password}) async {
    final response = await client.auth.signInWithPassword(email: email.trim(), password: password);
    if (response.session == null || response.user == null) throw StateError('login_failed');
    return response;
  }

  Future<void> signOut() => client.auth.signOut();

  Future<Map<String, dynamic>> updateMyProfile({String? name, String? gender, String? avatarUrl}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_update_my_profile', params: {
      'p_display_name': name,
      'p_gender': gender,
      'p_avatar_url': avatarUrl,
    });
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid profile response');
  }

  Future<Map<String, dynamic>> sendGift({required String receiverId, required String giftId, int quantity = 1}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_send_gift', params: {
      'p_receiver_id': receiverId,
      'p_gift_id': giftId,
      'p_quantity': quantity,
    });
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid gift response');
  }

  Future<String> ensureProfile({required String name, String? gender}) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    await client.from('zp_profiles').upsert({
      'id': uid,
      'display_name': name.isEmpty ? 'مستخدم Zuparty' : name,
      'gender': gender,
    });
    return uid;
  }


  Future<Map<String, dynamic>> getMyStaffRole() async {
    await ensureSignedIn();
    final result = await client.rpc('zp_my_staff_role');
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    return <String, dynamic>{};
  }

  Future<Map<String, dynamic>> applyAsAgent({String note = ''}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_apply_agent', params: {'p_note': note});
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid agent application response');
  }

  String agentPanelUrl() {
    final token = client.auth.currentSession?.accessToken;
    if (token == null || token.isEmpty) throw StateError('not_authenticated');
    return '${ZupartyConfig.supabaseUrl}/functions/v1/agent-panel?token=${Uri.encodeComponent(token)}';
  }

  Future<void> joinRoom(String roomId) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    await client.from('zp_room_members').upsert({'room_id': roomId, 'user_id': uid});
  }

  Future<void> leaveRoom(String roomId) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    await client.from('zp_room_members').delete().eq('room_id', roomId).eq('user_id', uid);
  }

  Future<List<Map<String, dynamic>>> listRooms() async {
    await ensureSignedIn();
    final raw = await client.from('zp_rooms').select().order('created_at', ascending: false).limit(100);
    final rooms = (raw as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final ownerIds = rooms.map((r) => r['owner_id']?.toString()).whereType<String>().toSet().toList();
    if (ownerIds.isNotEmpty) {
      final profiles = await client.from('zp_profiles').select('id,display_name,avatar_url').inFilter('id', ownerIds);
      final byId = <String, Map<String,dynamic>>{};
      for (final p in profiles as List) { final m=Map<String,dynamic>.from(p as Map); byId[m['id'].toString()]=m; }
      for (final r in rooms) { final o=byId[r['owner_id']?.toString()]; if(o!=null){ r['owner_name']=o['display_name']; r['owner_avatar']=o['avatar_url']; } }
    }
    return rooms;
  }

  Future<Map<String, dynamic>> createRoom({
    required String name,
    required String roomCode,
    required String? imagePath,
    required String? category,
    required String description,
    required String announcement,
    required bool isPrivate,
    required int effectIndex,
  }) async {
    await ensureSignedIn();
    final row = await client.from('zp_rooms').insert({
      'room_code': roomCode,
      'name': name,
      'image_path': imagePath,
      'category': category,
      'description': description,
      'announcement': announcement,
      'is_private': isPrivate,
      'effect_index': effectIndex,
      'owner_id': client.auth.currentUser!.id,
    }).select().single();
    return Map<String, dynamic>.from(row);
  }

  Future<Map<String, dynamic>> getOrCreateGameRound(String gameId) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_get_or_create_game_round', params: {'p_game_id': gameId});
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Unable to create game round');
  }

  Future<Map<String, dynamic>> placeGameBet({
    required String gameId, required String roundId, required String choice, required int amount,
  }) async {
    throw StateError('game_wagering_disabled');
  }

  Future<Map<String, dynamic>> resolveGameRound(String roundId) async {
    throw StateError('game_wagering_disabled');
  }

  Future<Map<String, dynamic>> getWalletProfile() async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    final row = await client.from('zp_profiles').select('coins').eq('id', uid).single();
    return Map<String, dynamic>.from(row);
  }

  Future<List<Map<String, dynamic>>> getWalletTransactions({int limit = 50}) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    final rows = await client.from('zp_wallet_transactions').select().eq('user_id', uid).order('created_at', ascending: false).limit(limit);
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> createRechargeOrder({required String packageId, required int usdCents, required int coins, required String paymentMethod}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_create_recharge_order', params: {
      'p_package_id': packageId,
      'p_usd_cents': usdCents,
      'p_coins': coins,
      'p_payment_method': paymentMethod,
    });
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid recharge order response');
  }

  Future<List<Map<String, dynamic>>> loadRoomMessages(String roomId) async {
    await ensureSignedIn();
    final rows = await client.from('zp_room_messages').select().eq('room_id', roomId).order('created_at', ascending: true).limit(100);
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> sendRoomMessage({required String roomId, required String text}) async {
    await ensureSignedIn();
    await client.from('zp_room_messages').insert({
      'room_id': roomId,
      'sender_id': client.auth.currentUser!.id,
      'message_type': 'text',
      'text': text,
    });
  }

  Future<Map<String, dynamic>> getAgoraToken({required String channel, required int uid}) async {
    await ensureSignedIn();
    final response = await client.functions.invoke('agora-token', body: {
      'channel': channel,
      'uid': uid,
    });
    if (response.data is! Map) throw StateError('Invalid Agora token response');
    return Map<String, dynamic>.from(response.data as Map);
  }

  int stableAgoraUid() {
    final id = client.auth.currentUser?.id;
    if (id == null) return Random().nextInt(0x7fffffff) + 1;
    var hash = 2166136261;
    for (final c in id.codeUnits) {
      hash ^= c;
      hash = (hash * 16777619) & 0x7fffffff;
    }
    return hash == 0 ? 1 : hash;
  }
}
