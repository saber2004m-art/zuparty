import 'dart:async';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:permission_handler/permission_handler.dart';
import 'zuparty_backend.dart';

class AgoraVoiceService {
  AgoraVoiceService({required this.channelName});
  final String channelName;
  final backend = ZupartyBackend.instance;
  RtcEngine? _engine;
  int? _uid;
  bool _joined = false;
  StreamSubscription? _tokenSub;

  RtcEngine? get engine => _engine;
  bool get joined => _joined;

  Future<void> initialize({required void Function(RtcConnection connection, int remoteUid, bool joined) onRemoteUser}) async {
    if (_engine != null) return;
    final mic = await Permission.microphone.request();
    if (!mic.isGranted) throw StateError('microphone_permission_denied');
    final engine = createAgoraRtcEngine();
    _engine = engine;
    await engine.initialize(const RtcEngineContext(appId: ZupartyConfig.agoraAppId, channelProfile: ChannelProfileType.channelProfileCommunication));
    engine.registerEventHandler(RtcEngineEventHandler(
      onJoinChannelSuccess: (connection, elapsed) {
        _joined = true;
      },
      onUserJoined: (connection, remoteUid, elapsed) => onRemoteUser(connection, remoteUid, true),
      onUserOffline: (connection, remoteUid, reason) => onRemoteUser(connection, remoteUid, false),
      onTokenPrivilegeWillExpire: (connection, token) async {
        if (_uid == null) return;
        final data = await backend.getAgoraToken(channel: channelName, uid: _uid!);
        await engine.renewToken(data['token'] as String);
      },
      onRequestToken: (connection) async {
        if (_uid == null) return;
        final data = await backend.getAgoraToken(channel: channelName, uid: _uid!);
        await engine.joinChannel(
          token: data['token'] as String,
          channelId: channelName,
          uid: _uid!,
          options: const ChannelMediaOptions(autoSubscribeAudio: true),
        );
      },
      onError: (err, msg) {},
    ));
    await engine.enableAudio();
    await engine.setDefaultAudioRouteToSpeakerphone(true);
  }

  Future<void> join({bool publish = false}) async {
    final engine = _engine;
    if (engine == null) throw StateError('Agora engine not initialized');
    if (_joined) return;
    _uid = backend.stableAgoraUid();
    final data = await backend.getAgoraToken(channel: channelName, uid: _uid!);
    final token = data['token'] as String;
    await engine.setClientRole(role: publish ? ClientRoleType.clientRoleBroadcaster : ClientRoleType.clientRoleAudience);
    await engine.joinChannel(
      token: token,
      channelId: channelName,
      uid: _uid!,
      options: ChannelMediaOptions(
        clientRoleType: publish ? ClientRoleType.clientRoleBroadcaster : ClientRoleType.clientRoleAudience,
        publishMicrophoneTrack: publish,
        autoSubscribeAudio: true,
      ),
    );
  }

  Future<void> setPublishing(bool enabled) async {
    final engine = _engine;
    if (engine == null) return;
    await engine.setClientRole(role: enabled ? ClientRoleType.clientRoleBroadcaster : ClientRoleType.clientRoleAudience);
    await engine.updateChannelMediaOptions(ChannelMediaOptions(
      clientRoleType: enabled ? ClientRoleType.clientRoleBroadcaster : ClientRoleType.clientRoleAudience,
      publishMicrophoneTrack: enabled,
      autoSubscribeAudio: true,
    ));
  }

  Future<void> muteLocal(bool muted) async => _engine?.muteLocalAudioStream(muted);
  Future<void> setSpeaker(bool enabled) async => _engine?.setEnableSpeakerphone(enabled);

  Future<void> dispose() async {
    await _tokenSub?.cancel();
    _tokenSub = null;
    final engine = _engine;
    _engine = null;
    _joined = false;
    if (engine != null) {
      await engine.leaveChannel();
      await engine.release();
    }
  }
}
