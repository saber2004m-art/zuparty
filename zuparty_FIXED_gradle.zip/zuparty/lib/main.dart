import 'dart:async';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'theme/app_theme.dart';
import 'widgets/app_states.dart';
import 'data/models.dart';
import 'data/mock_data.dart';
import 'routing/app_page_route.dart';
import 'data/app_state.dart';
import 'screens/rooms/create_room_screen.dart';
import 'screens/rooms/room_details_screen.dart';
import 'screens/rooms/voice_room_screen.dart';
import 'screens/chat/chat_list_screen.dart';
import 'screens/wallet/wallet_screen.dart';
import 'screens/gifts/gift_center_screen.dart';
import 'screens/vip/vip_screen.dart';
import 'screens/profile/profile_screen.dart';
import 'screens/notifications/notifications_screen.dart';
import 'screens/rankings/rankings_screen.dart';
import 'screens/events/events_center_screen.dart';
import 'screens/search/search_screen.dart';
import 'data/locale_controller.dart';
import 'l10n/app_strings.dart';

void main() {
  runApp(const ZupartyApp());
}

/// رسالة موحدة للتفاعلات التي تبقى محلية في النسخة التجريبية
void _profilePlaceholder(BuildContext context, String label) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('$label: متاحة محليًا في النسخة التجريبية'), duration: const Duration(seconds: 2)),
  );
}

class ZupartyApp extends StatelessWidget {
  const ZupartyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Zuparty',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      builder: (context, child) {
        return ValueListenableBuilder<String>(
          valueListenable: LocaleController.languageCode,
          builder: (context, lang, _) {
            return Directionality(
              textDirection: LocaleController.isRtl ? TextDirection.rtl : TextDirection.ltr,
              child: child!,
            );
          },
        );
      },
      home: const SignUpScreen(),
    );
  }
}

/// شاشة إنشاء الحساب: الاسم + اختيار الجنس (مطلوب قبل الدخول للتطبيق)
class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _nameController = TextEditingController(text: 'مستخدم Zuparty');
  String? _selectedGender;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Widget _genderOption(String label, {required bool selected, required String solidAsset, required String lightAsset, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 84,
            height: 84,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: selected ? Colors.deepOrange : Colors.transparent, width: 2.5),
            ),
            child: Image.asset(selected ? solidAsset : lightAsset, fit: BoxFit.contain),
          ),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(fontWeight: selected ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('إنشاء حساب', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 26),
              TextField(
                controller: _nameController,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  labelText: 'الاسم',
                  filled: true,
                  fillColor: Colors.grey.shade100,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 30),
              const Align(alignment: Alignment.centerRight, child: Text('الجنس', style: TextStyle(fontWeight: FontWeight.bold))),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _genderOption(
                    'ذكر',
                    selected: _selectedGender == 'ذكر',
                    solidAsset: 'assets/images/gender_male_solid.webp',
                    lightAsset: 'assets/images/gender_male_light.webp',
                    onTap: () => setState(() => _selectedGender = 'ذكر'),
                  ),
                  _genderOption(
                    'أنثى',
                    selected: _selectedGender == 'أنثى',
                    solidAsset: 'assets/images/gender_female_solid.webp',
                    lightAsset: 'assets/images/gender_female_light.webp',
                    onTap: () => setState(() => _selectedGender = 'أنثى'),
                  ),
                ],
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: _selectedGender == null
                      ? null
                      : () {
                          AppState.userName = _nameController.text.trim().isEmpty
                              ? 'مستخدم Zuparty'
                              : _nameController.text.trim();
                          AppState.userGender = _selectedGender;
                          AppState.isNewAccount = true;
                          Navigator.of(context).pushReplacement(
                            appPageRoute(builder: (_) => const HomeShell()),
                          );
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('متابعة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// الهيكل العام: شاشة فارغة + 4 أزرار تنقل فالأسفل
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _currentIndex = 0;
  final List<RoomModel> _minimizedRooms = [];

  final List<String> _imagePaths = const [
    'assets/images/home.webp',
    'assets/images/room_plus.webp',
    'assets/images/message.png',
    'assets/images/profile.png',
  ];

  final List<String> _labels = const ['الرئيسية', 'الغرف', 'الدردشة', 'البروفيل'];

  Future<void> _openRoom(RoomModel room) async {
    setState(() => _minimizedRooms.removeWhere((r) => r == room));
    // Voice Room UI (current) replaces the old LiveRoomScreen, which has
    // been removed from the project as dead/unreachable code.
    final action = await Navigator.push<String>(
      context,
      appPageRoute(
        builder: (_) => VoiceRoomScreen(
          room: room,
          onOpenProfile: (user) => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: user))),
        ),
      ),
    );
    if (!mounted) return;
    if (action == 'minimize') {
      setState(() => _minimizedRooms.add(room));
    } else {
      // خروج نهائي: نصفّي حالة الغرفة باش تبدأ من جديد فالمرة الجاية
      setState(() {
        room.ownerSeat = null;
        room.seatsData = null;
        room.isRoomLocked = false;
        room.selfMicLocked = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(onOpenRoom: _openRoom),
      RoomScreen(onOpenRoom: _openRoom),
      const ChatListScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      body: Stack(
        children: [
          SafeArea(
            child: IndexedStack(
              index: _currentIndex,
              children: screens,
            ),
          ),
          // فقاعات الغرف المصغّرة (تصغير بدل الخروج الكامل)
          if (_minimizedRooms.isNotEmpty)
            Positioned(
              left: 14,
              bottom: 72,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: _minimizedRooms.map((room) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: GestureDetector(
                      onTap: () => _openRoom(room),
                      child: Container(
                        width: 52,
                        height: 52,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.primary, width: 2),
                          boxShadow: AppShadows.floating,
                        ),
                        child: Image.asset(
                          room.imagePath ?? 'assets/images/room_bg_official.webp',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        // باقي الخصائص (الألوان، نوع الخط) كتجي من AppTheme.light()
        // .bottomNavigationBarTheme — مصدر واحد موحّد لتصميم شريط التنقل.
        selectedFontSize: 11,
        unselectedFontSize: 11,
        items: List.generate(4, (i) {
          return BottomNavigationBarItem(
            icon: Image.asset(_imagePaths[i], width: 24, height: 24),
            label: _labels[i],
          );
        }),
      ),
    );
  }
}

/// عنصر مربع فارغ (Placeholder) بحدود متقطعة أو عادية
class _EmptyBox extends StatelessWidget {
  final bool dashedFrame;

  const _EmptyBox({this.dashedFrame = false});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }
}

/// عنصر مربع فيه صورة (بدل المربع الفارغ)
class _ImageBox extends StatelessWidget {
  final String imagePath;

  const _ImageBox({required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Image.asset(imagePath, fit: BoxFit.cover),
      ),
    );
  }
}

/// دائرة فارغة، أو فيها أيقونة، أو فيها صورة ديالك (imagePath)
class _CircleIcon extends StatelessWidget {
  final IconData? icon;
  final String? imagePath; // مثال: 'assets/images/profile.png' (لازم تكون موجودة فعليًا فـ assets/images/)
  final double size;

  const _CircleIcon({this.icon, this.imagePath, this.size = 48});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.grey.shade100,
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: imagePath != null
          ? Image.asset(imagePath!, fit: BoxFit.cover)
          : (icon != null
              ? Icon(icon, size: size * 0.45, color: Colors.grey.shade600)
              : null),
    );
  }
}

/// إطار بحدود متقطعة (Dashed-style بسيط باستعمال حدود عادية خفيفة)
class _FrameBox extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;

  const _FrameBox({required this.child, this.padding = const EdgeInsets.all(14)});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
      ),
      child: child,
    );
  }
}

// ========================= شاشة 1: الرئيسية =========================
class HomeScreen extends StatefulWidget {
  final void Function(RoomModel room) onOpenRoom;
  const HomeScreen({super.key, required this.onOpenRoom});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

enum _HomeLoadState { loading, loaded, error }

class _HomeScreenState extends State<HomeScreen> {
  _HomeLoadState _state = _HomeLoadState.loading;

  final PageController _bannerController = PageController();
  int _bannerIndex = 0;
  Timer? _bannerTimer;

  @override
  void initState() {
    super.initState();
    _loadHome();
  }

  @override
  void dispose() {
    _bannerTimer?.cancel();
    _bannerController.dispose();
    super.dispose();
  }

  Future<void> _loadHome() async {
    setState(() => _state = _HomeLoadState.loading);
    try {
      await Future.delayed(const Duration(milliseconds: 450));
      if (!mounted) return;
      setState(() => _state = _HomeLoadState.loaded);
      _startBannerAutoplay();
    } catch (_) {
      if (!mounted) return;
      setState(() => _state = _HomeLoadState.error);
    }
  }

  void _startBannerAutoplay() {
    _bannerTimer?.cancel();
    final banners = MockData.banners;
    if (banners.length <= 1) return;
    _bannerTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted || !_bannerController.hasClients) return;
      final next = (_bannerIndex + 1) % banners.length;
      _bannerController.animateToPage(
        next,
        duration: const Duration(milliseconds: 420),
        curve: Curves.easeOutCubic,
      );
    });
  }

  void _openSearch() {
    Navigator.push(
      context,
      appPageRoute(
        builder: (_) => SearchScreen(
          onOpenRoom: (r) async => widget.onOpenRoom(r),
          onOpenGame: (g) => showGamesLauncherSheet(context, initialGame: g),
        ),
      ),
    );
  }

  void _handleBannerTap(BannerItem banner) {
    if (banner.opensVip) {
      Navigator.push(context, appPageRoute(builder: (_) => const VipScreen()));
      return;
    }
    if (banner.targetRoomId != null) {
      final all = [...MockData.featuredRooms, ...MockData.popularRooms, ...MockData.recommendedRooms];
      final matches = all.where((r) => r.id == banner.targetRoomId);
      if (matches.isNotEmpty) {
        widget.onOpenRoom(matches.first);
        return;
      }
    }
    _profilePlaceholder(context, banner.title);
  }

  void _openEventDetails(EventItem event) {
    final daysLeft = event.endDate.difference(DateTime.now()).inDays;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.lg)),
        title: Text(event.title, style: AppTextStyles.h3, textAlign: TextAlign.center),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(event.description, style: AppTextStyles.body, textAlign: TextAlign.center),
            const SizedBox(height: AppSpacing.md),
            Text(
              daysLeft > 0
                  ? S.trParams('home_days_left_template', {'days': '$daysLeft'})
                  : S.tr('home_event_ending_soon'),
              style: AppTextStyles.caption,
            ),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(S.tr('ok'))),
        ],
      ),
    );
  }

  void _openUserProfile(UserModel user) {
    Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: user)));
  }

  void _openGame(GameModel game) {
    showGamesLauncherSheet(context, initialGame: game);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: _loadHome,
          child: _buildBody(),
        ),
      ),
    );
  }

  Widget _buildBody() {
    switch (_state) {
      case _HomeLoadState.loading:
        return _buildLoadingSkeleton();
      case _HomeLoadState.error:
        return ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            const SizedBox(height: 110),
            AppErrorState(message: S.tr('home_load_error'), onRetry: _loadHome),
          ],
        );
      case _HomeLoadState.loaded:
        return _buildContent();
    }
  }

  Widget _buildLoadingSkeleton() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(AppSpacing.lg),
      children: [
        Row(
          children: const [
            AppSkeleton(width: 44, height: 44, radius: 22),
            SizedBox(width: 10),
            Expanded(child: AppSkeleton(height: 14)),
          ],
        ),
        const SizedBox(height: AppSpacing.lg),
        const AppSkeleton(height: 150, radius: AppRadius.lg),
        const SizedBox(height: AppSpacing.lg),
        const AppSkeleton(height: 120, radius: AppRadius.lg),
        const SizedBox(height: AppSpacing.lg),
        SizedBox(
          height: 130,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: 3,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, __) => const AppSkeleton(width: 150, height: 130, radius: AppRadius.lg),
          ),
        ),
        const SizedBox(height: AppSpacing.lg),
        const AppSkeletonList(itemCount: 3, itemHeight: 64),
      ],
    );
  }

  Widget _buildContent() {
    final banners = MockData.banners;
    final featured = MockData.featuredRooms;
    final popular = MockData.popularRooms;
    final recommended = MockData.recommendedRooms;
    final onlineUsers = MockData.onlineUsers;
    final events = MockData.events;
    final rankings = MockData.rankings;
    final games = MockData.games;

    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(child: _buildHeader()),
        SliverToBoxAdapter(child: _buildBannerSection(banners)),
        SliverToBoxAdapter(child: _HomeSectionHeader(title: S.tr('home_section_featured_rooms'))),
        SliverToBoxAdapter(child: _buildFeaturedRoomsSection(featured)),
        SliverToBoxAdapter(child: _HomeSectionHeader(title: S.tr('home_section_popular'))),
        SliverToBoxAdapter(child: _buildCompactRoomsSection(popular)),
        SliverToBoxAdapter(child: _HomeSectionHeader(title: S.tr('home_section_recommended'))),
        SliverToBoxAdapter(child: _buildCompactRoomsSection(recommended)),
        SliverToBoxAdapter(child: _HomeSectionHeader(title: S.tr('home_section_online_now'))),
        SliverToBoxAdapter(child: _buildOnlineUsersSection(onlineUsers)),
        SliverToBoxAdapter(child: _buildVipSection()),
        SliverToBoxAdapter(
          child: _HomeSectionHeader(
            title: S.tr('home_section_events'),
            onSeeAll: () => Navigator.push(context, appPageRoute(builder: (_) => const EventsCenterScreen())),
          ),
        ),
        SliverToBoxAdapter(child: _buildEventsSection(events)),
        SliverToBoxAdapter(
          child: _HomeSectionHeader(
            title: S.tr('home_section_rankings'),
            onSeeAll: () => Navigator.push(context, appPageRoute(builder: (_) => const RankingsScreen())),
          ),
        ),
        SliverToBoxAdapter(child: _buildRankingsSection(rankings)),
        SliverToBoxAdapter(child: _HomeSectionHeader(title: S.tr('home_section_games'))),
        SliverToBoxAdapter(child: _buildGamesSection(games)),
        const SliverToBoxAdapter(child: SizedBox(height: 28)),
      ],
    );
  }

  // ---------------- HEADER ----------------
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.sm),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const ProfileScreen())),
            child: const _CircleIcon(imagePath: 'assets/images/profile.png', size: 46),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppState.userName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.h3,
                ),
                const SizedBox(height: 3),
                GestureDetector(
                  onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const WalletScreen())),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset('assets/images/icon_wallet.webp', width: 14, height: 14),
                      const SizedBox(width: 4),
                      Text('${AppState.userCoins} ${S.tr('room_ranking_unit_coins')}', style: AppTextStyles.caption.copyWith(color: AppColors.primary, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          _HeaderIconButton(icon: Icons.search, onTap: _openSearch),
          const SizedBox(width: 6),
          _HeaderIconButton(
            icon: Icons.notifications_none,
            showDot: MockData.notifications.isNotEmpty,
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const NotificationsScreen())),
          ),
        ],
      ),
    );
  }

  // ---------------- BANNERS ----------------
  Widget _buildBannerSection(List<BannerItem> banners) {
    if (banners.isEmpty) {
      return _sectionEmpty(S.tr('home_no_banners'), icon: Icons.info_outline);
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
      child: Column(
        children: [
          SizedBox(
            height: 140,
            child: PageView.builder(
              controller: _bannerController,
              itemCount: banners.length,
              onPageChanged: (i) => setState(() => _bannerIndex = i),
              itemBuilder: (context, index) {
                final banner = banners[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: _BannerCard(banner: banner, onTap: () => _handleBannerTap(banner)),
                );
              },
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(banners.length, (i) {
              final active = i == _bannerIndex;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: active ? AppColors.primary : AppColors.grey300,
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  // ---------------- FEATURED ROOMS ----------------
  Widget _buildFeaturedRoomsSection(List<RoomModel> rooms) {
    if (rooms.isEmpty) {
      return _sectionEmpty(S.tr('home_no_featured_rooms'), icon: Icons.star_border);
    }
    return SizedBox(
      height: 172,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        scrollDirection: Axis.horizontal,
        itemCount: rooms.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final room = rooms[i];
          return _FeaturedRoomCard(room: room, onTap: () => widget.onOpenRoom(room));
        },
      ),
    );
  }

  // ---------------- POPULAR / RECOMMENDED ROOMS ----------------
  Widget _buildCompactRoomsSection(List<RoomModel> rooms) {
    if (rooms.isEmpty) {
      return _sectionEmpty(S.tr('home_no_rooms'), icon: Icons.meeting_room_outlined);
    }
    return SizedBox(
      height: 128,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        scrollDirection: Axis.horizontal,
        itemCount: rooms.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final room = rooms[i];
          return _CompactRoomCard(room: room, onTap: () => widget.onOpenRoom(room));
        },
      ),
    );
  }

  // ---------------- ONLINE USERS ----------------
  Widget _buildOnlineUsersSection(List<UserModel> users) {
    if (users.isEmpty) {
      return _sectionEmpty(S.tr('home_no_online_users'), icon: Icons.people_outline);
    }
    return SizedBox(
      height: 92,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        scrollDirection: Axis.horizontal,
        itemCount: users.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (context, i) {
          final user = users[i];
          return _OnlineUserAvatar(user: user, onTap: () => _openUserProfile(user));
        },
      ),
    );
  }

  // ---------------- VIP ----------------
  Widget _buildVipSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, 0),
      child: _VipPromoCard(
        onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const VipScreen())),
      ),
    );
  }

  // ---------------- EVENTS ----------------
  Widget _buildEventsSection(List<EventItem> events) {
    if (events.isEmpty) {
      return _sectionEmpty(S.tr('home_no_events'), icon: Icons.event_busy);
    }
    return SizedBox(
      height: 118,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        scrollDirection: Axis.horizontal,
        itemCount: events.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final event = events[i];
          return _EventCard(event: event, onTap: () => _openEventDetails(event));
        },
      ),
    );
  }

  // ---------------- RANKINGS ----------------
  Widget _buildRankingsSection(List<RankingEntry> rankings) {
    if (rankings.isEmpty) {
      return _sectionEmpty(S.tr('home_no_rankings'), icon: Icons.bar_chart);
    }
    final top = rankings.take(3).toList();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
      child: Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
        child: Column(
          children: List.generate(top.length, (i) {
            final entry = top[i];
            return _RankingRow(
              entry: entry,
              showDivider: i != top.length - 1,
              // الضغط على صف فالمعاينة المصغّرة كيفتح بروفيل المستخدم مباشرة؛
              // شاشة الترتيب الكاملة متاحة من زر "الكل" فرأس القسم.
              onTap: () => _openUserProfile(UserModel(
                id: 'rank_${entry.rank}',
                name: entry.userName,
                avatarPath: entry.avatarPath,
              )),
            );
          }),
        ),
      ),
    );
  }

  // ---------------- GAMES ----------------
  Widget _buildGamesSection(List<GameModel> games) {
    if (games.isEmpty) {
      return _sectionEmpty(S.tr('home_no_games'), icon: Icons.videogame_asset);
    }
    return SizedBox(
      height: 108,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        scrollDirection: Axis.horizontal,
        itemCount: games.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final game = games[i];
          return _GameTile(game: game, onTap: () => _openGame(game));
        },
      ),
    );
  }

  Widget _sectionEmpty(String message, {IconData icon = Icons.inbox_outlined}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg)),
        child: Column(
          children: [
            Icon(icon, color: AppColors.grey400, size: 28),
            const SizedBox(height: 6),
            Text(message, style: AppTextStyles.caption, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

/// عنوان قسم موحّد فـ Home
class _HomeSectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback? onSeeAll;
  const _HomeSectionHeader({required this.title, this.onSeeAll});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, AppSpacing.sm),
      child: Row(
        children: [
          Text(title, style: AppTextStyles.h3),
          const Spacer(),
          if (onSeeAll != null)
            GestureDetector(
              onTap: onSeeAll,
              child: Text(S.tr('see_all'), style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 12.5)),
            ),
        ],
      ),
    );
  }
}

/// زر أيقونة دائري بسيط للهيدر (بحث / إشعارات) مع نقطة تنبيه اختيارية
class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool showDot;

  const _HeaderIconButton({required this.icon, required this.onTap, this.showDot = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: AppShadows.card),
            child: Icon(icon, color: AppColors.textPrimary, size: 20),
          ),
          if (showDot)
            Positioned(
              top: 6,
              right: 6,
              child: Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(color: AppColors.danger, shape: BoxShape.circle),
              ),
            ),
        ],
      ),
    );
  }
}

/// كرت Banner فـ الـ Carousel (تدرّج لوني + أيقونة + عنوان)
class _BannerCard extends StatelessWidget {
  final BannerItem banner;
  final VoidCallback onTap;
  const _BannerCard({required this.banner, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppRadius.lg),
          gradient: LinearGradient(colors: banner.gradientColors, begin: Alignment.topRight, end: Alignment.bottomLeft),
          boxShadow: AppShadows.card,
        ),
        child: Stack(
          children: [
            Positioned(
              left: -18,
              bottom: -18,
              child: Icon(banner.icon, size: 120, color: Colors.white.withOpacity(0.12)),
            ),
            Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(banner.icon, color: Colors.white, size: 26),
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    banner.title,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    banner.subtitle,
                    style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 12),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// كرت غرفة مميزة (كبير) — يحتوي غلاف، اسم، صاحب الروم، عدد المتصلين، التصنيف
class _FeaturedRoomCard extends StatefulWidget {
  final RoomModel room;
  final VoidCallback onTap;
  const _FeaturedRoomCard({required this.room, required this.onTap});

  @override
  State<_FeaturedRoomCard> createState() => _FeaturedRoomCardState();
}

class _FeaturedRoomCardState extends State<_FeaturedRoomCard> {
  double _scale = 1;

  void _setPressed(bool pressed) => setState(() => _scale = pressed ? 0.97 : 1);

  @override
  Widget build(BuildContext context) {
    final room = widget.room;
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => _setPressed(true),
      onTapUp: (_) => _setPressed(false),
      onTapCancel: () => _setPressed(false),
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 120),
        child: Container(
          width: 152,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 1.5,
                    child: Image.asset(room.imagePath ?? 'assets/images/room_bg_official.webp', fit: BoxFit.cover),
                  ),
                  if (room.category != null)
                    Positioned(
                      top: 6,
                      right: 6,
                      child: _CategoryChip(label: room.category!),
                    ),
                  Positioned(
                    left: 6,
                    bottom: 6,
                    child: _OnlineCountBadge(count: room.onlineCount),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(room.name, style: AppTextStyles.bodyBold.copyWith(fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                    if (room.ownerName != null) ...[
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          const _CircleIcon(imagePath: 'assets/images/profile.png', size: 16),
                          const SizedBox(width: 4),
                          Expanded(child: Text(room.ownerName!, style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis)),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// كرت غرفة مضغوط (Popular / Recommended)
class _CompactRoomCard extends StatelessWidget {
  final RoomModel room;
  final VoidCallback onTap;
  const _CompactRoomCard({required this.room, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 118,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.md), boxShadow: AppShadows.card),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(room.imagePath ?? 'assets/images/room_bg_official.webp', fit: BoxFit.cover),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black.withOpacity(0.55)],
                ),
              ),
            ),
            Positioned(
              left: 6,
              right: 6,
              bottom: 6,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(room.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      const Icon(Icons.people_alt, color: Colors.white, size: 11),
                      const SizedBox(width: 2),
                      Text('${room.onlineCount}', style: const TextStyle(color: Colors.white, fontSize: 10)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// شارة صغيرة للتصنيف فوق غلاف الروم
class _CategoryChip extends StatelessWidget {
  final String label;
  const _CategoryChip({required this.label});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(AppRadius.pill)),
      child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600)),
    );
  }
}

/// شارة عدد المتصلين فوق غلاف الروم
class _OnlineCountBadge extends StatelessWidget {
  final int count;
  const _OnlineCountBadge({required this.count});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(AppRadius.pill)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.people_alt, color: Colors.white, size: 10),
          const SizedBox(width: 3),
          Text('$count', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

/// أفاتار مستخدم متصل (دائري + مؤشر أونلاين + اسم)
class _OnlineUserAvatar extends StatelessWidget {
  final UserModel user;
  final VoidCallback onTap;
  const _OnlineUserAvatar({required this.user, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 62,
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                _CircleIcon(imagePath: user.avatarPath, size: 54),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 13,
                    height: 13,
                    decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                  ),
                ),
                if (user.isVip)
                  Positioned(
                    top: -4,
                    left: -4,
                    child: Icon(Icons.workspace_premium, size: 16, color: Colors.amber.shade700),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(user.name, style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

/// كرت VIP الترويجي فـ Home
class _VipPromoCard extends StatelessWidget {
  final VoidCallback onTap;
  const _VipPromoCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppRadius.lg),
          gradient: const LinearGradient(colors: [Color(0xFF6A3DE8), AppColors.secondary], begin: Alignment.topRight, end: Alignment.bottomLeft),
          boxShadow: AppShadows.card,
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), shape: BoxShape.circle),
              child: const Icon(Icons.workspace_premium, color: Colors.amber, size: 28),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('VIP', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
                      const SizedBox(width: 6),
                      Text(S.tr('home_vip_subtitle'), style: const TextStyle(color: Colors.white70, fontSize: 11)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    S.tr('home_vip_features'),
                    style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 11),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(AppRadius.pill),
                    child: LinearProgressIndicator(
                      value: 0.35,
                      minHeight: 5,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      valueColor: const AlwaysStoppedAnimation(Colors.amber),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.chevron_left, color: Colors.white70),
          ],
        ),
      ),
    );
  }
}

/// كرت فعالية (Event) مع Progress و Countdown تجريبي
class _EventCard extends StatelessWidget {
  final EventItem event;
  final VoidCallback onTap;
  const _EventCard({required this.event, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final total = event.endDate.difference(event.startDate).inSeconds.clamp(1, 1 << 30);
    final elapsed = DateTime.now().difference(event.startDate).inSeconds.clamp(0, total);
    final progress = (elapsed / total).clamp(0.0, 1.0).toDouble();
    final daysLeft = event.endDate.difference(DateTime.now()).inDays;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 230,
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppRadius.lg),
          gradient: const LinearGradient(colors: [Color(0xFFFF7043), AppColors.primaryDark]),
          boxShadow: AppShadows.card,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(event.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Text(event.description, style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis),
            const Spacer(),
            ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.pill),
              child: LinearProgressIndicator(value: progress, minHeight: 5, backgroundColor: Colors.white.withOpacity(0.25), valueColor: const AlwaysStoppedAnimation(Colors.white)),
            ),
            const SizedBox(height: 5),
            Text(
              daysLeft > 0
                  ? S.trParams('home_days_left_template', {'days': '$daysLeft'})
                  : S.tr('home_event_ends_soon_card'),
              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}

/// صف واحد فـ لائحة الترتيب المصغّرة (Home)
class _RankingRow extends StatelessWidget {
  final RankingEntry entry;
  final bool showDivider;
  final VoidCallback onTap;
  const _RankingRow({required this.entry, required this.showDivider, required this.onTap});

  Color _rankColor() {
    switch (entry.rank) {
      case 1:
        return const Color(0xFFFFC107);
      case 2:
        return const Color(0xFFB0BEC5);
      case 3:
        return const Color(0xFFD08A57);
      default:
        return AppColors.grey500;
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
            child: Row(
              children: [
                SizedBox(
                  width: 24,
                  child: Text('${entry.rank}', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: _rankColor(), fontSize: 15)),
                ),
                const SizedBox(width: 8),
                _CircleIcon(imagePath: entry.avatarPath, size: 38),
                const SizedBox(width: 10),
                Expanded(child: Text(entry.userName, style: AppTextStyles.bodyBold)),
                Text('${entry.score}', style: AppTextStyles.bodyBold.copyWith(color: AppColors.primary)),
              ],
            ),
          ),
          if (showDivider) const Divider(height: 1, indent: AppSpacing.md, endIndent: AppSpacing.md),
        ],
      ),
    );
  }
}

/// كرت لعبة صغير فـ معاينة الألعاب بالـ Home
class _GameTile extends StatelessWidget {
  final GameModel game;
  final VoidCallback onTap;
  const _GameTile({required this.game, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 92,
        decoration: BoxDecoration(
          color: game.color,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          boxShadow: [BoxShadow(color: game.color.withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 3))],
        ),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(game.emoji, style: const TextStyle(fontSize: 30)),
            const SizedBox(height: 6),
            Text(game.name, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

/// يفتح واجهة الألعاب الموجودة فعليًا (نفس تصميم Bottom Sheet المستعمل جوة الروم)
/// بدون ما نلمس أو نكرر منطق LiveRoomScreen — غير استعمال Widgets الموجودة (_GamesGrid / _GameWebView)
void showGamesLauncherSheet(BuildContext context, {GameModel? initialGame}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      return DraggableScrollableSheet(
        initialChildSize: 0.55,
        minChildSize: 0.4,
        maxChildSize: 0.85,
        expand: false,
        builder: (ctx, scrollController) {
          GameModel? selectedGame = initialGame;
          return StatefulBuilder(
            builder: (ctx, setSheetState) {
              return ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                child: Column(
                  children: [
                    Container(
                      color: const Color(0xFF160604),
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                      child: Row(
                        children: [
                          if (selectedGame != null)
                            IconButton(
                              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 16),
                              onPressed: () => setSheetState(() => selectedGame = null),
                            )
                          else
                            const SizedBox(width: 40),
                          Expanded(
                            child: Center(
                              child: Container(
                                width: 36,
                                height: 4,
                                decoration: BoxDecoration(color: Colors.grey.shade600, borderRadius: BorderRadius.circular(4)),
                              ),
                            ),
                          ),
                          const SizedBox(width: 40),
                        ],
                      ),
                    ),
                    Expanded(
                      child: selectedGame == null
                          ? _GamesGrid(
                              games: MockData.games,
                              onSelect: (game) => setSheetState(() => selectedGame = game),
                            )
                          : _GameWebView(
                              key: ValueKey(selectedGame!.id),
                              assetPath: selectedGame!.assetPath,
                              onClose: () => Navigator.of(ctx).pop(),
                            ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      );
    },
  );
}

class _ZupartySearchDelegate extends SearchDelegate<String> {
  final List<String> data = const ['السهرات العربية', 'Zuparty Music', 'Friends Lounge', 'Gaming Room', 'Lucky Fruit', 'Greedy Pro'];
  @override List<Widget>? buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override Widget buildResults(BuildContext context) => _results();
  @override Widget buildSuggestions(BuildContext context) => _results();
  Widget _results() {
    final list = data.where((x) => x.toLowerCase().contains(query.toLowerCase())).toList();
    return ListView(children: list.map((x) => ListTile(leading: const Icon(Icons.meeting_room_outlined), title: Text(x), trailing: const Icon(Icons.chevron_left))).toList());
  }
}

// ========================= شاشة 2: غرفة =========================
// ملاحظة: RoomModel وSeatModel وGameModel أصبحوا فـ lib/data/models.dart
// (Mock Data Foundation قابلة لإعادة الاستعمال فالمراحل القادمة)

/// شاشة "الغرف" (Phase 3 — Part 1): تجربة تصفّح احترافية —
/// هيدر + بحث محلي + تصنيفات + قائمة كروت غرف (Mock Data) + حالات
/// Loading/Loaded/Empty/Error. الضغط على أي روم كيفتح شاشة الروم
/// الموجودة فعليًا (LiveRoomScreen) عبر widget.onOpenRoom — بلا أي
/// Backend، بلا Voice Room جديد، وبلا أي تعديل فمنطق الروم نفسه.
class RoomScreen extends StatefulWidget {
  final void Function(RoomModel room) onOpenRoom;
  const RoomScreen({super.key, required this.onOpenRoom});

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

enum _RoomsLoadState { loading, loaded, error }

class _RoomScreenState extends State<RoomScreen> {
  // تصنيفات شاشة "الغرف": تصنيفات مختارة (شائع/موصى به/جديد) + تصنيفات نوع الروم
  // ملاحظة: القيم أدناه تبقى بالعربية لأنها تُستعمل كمفاتيح للفلترة (تُقارَن
  // مع room.category)، أما النص المعروض للمستخدم فكيتترجم عبر _categoryLabel().
  static const List<String> _categories = [
    'الكل', 'شائع', 'موصى به', 'جديد', 'موسيقى', 'دردشة', 'ألعاب', 'اجتماعي',
  ];

  static const Map<String, String> _categoryLabelKeys = {
    'الكل': 'rooms_cat_all',
    'شائع': 'rooms_cat_popular',
    'موصى به': 'rooms_cat_recommended',
    'جديد': 'rooms_badge_new',
    'موسيقى': 'rooms_cat_music',
    'دردشة': 'rooms_cat_chat',
    'ألعاب': 'rooms_cat_games',
    'اجتماعي': 'rooms_cat_social',
  };

  String _categoryLabel(String category) {
    final key = _categoryLabelKeys[category];
    return key != null ? S.tr(key) : category;
  }

  final TextEditingController _searchController = TextEditingController();
  final List<RoomModel> _myCreatedRooms = []; // غرف أنشأها المستخدم فهاد الجلسة (وظيفة موجودة مسبقًا)

  _RoomsLoadState _state = _RoomsLoadState.loading;
  List<RoomModel> _browseRooms = [];
  String _selectedCategory = 'الكل';
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadRooms();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadRooms() async {
    setState(() => _state = _RoomsLoadState.loading);
    try {
      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      setState(() {
        _browseRooms = MockData.browseRooms;
        _state = _RoomsLoadState.loaded;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _state = _RoomsLoadState.error);
    }
  }

  /// فلترة محلية: حسب التصنيف المختار + نص البحث (بالاسم / معرّف الروم / اسم صاحب الروم)
  List<RoomModel> get _filteredRooms {
    Iterable<RoomModel> list = _browseRooms;
    switch (_selectedCategory) {
      case 'شائع':
        list = list.where((r) => r.isPopular);
        break;
      case 'موصى به':
        list = list.where((r) => r.isRecommended);
        break;
      case 'جديد':
        list = list.where((r) => r.isNew);
        break;
      case 'الكل':
        break;
      default:
        list = list.where((r) => r.category == _selectedCategory);
    }
    final q = _searchQuery.trim().toLowerCase();
    if (q.isNotEmpty) {
      list = list.where((r) {
        final name = r.name.toLowerCase();
        final owner = (r.ownerName ?? '').toLowerCase();
        final code = (r.roomCode ?? r.id ?? '').toLowerCase();
        return name.contains(q) || owner.contains(q) || code.contains(q);
      });
    }
    return list.toList();
  }

  // ---------------------------------------------------------------
  // إنشاء غرفة (Phase 3 — Part 2): شاشة كاملة احترافية (CreateRoomScreen)
  // بدل الـ Dialog البسيط القديم. الروم الجديد كيتزاد لقائمة "الغرف"
  // محليًا (Mock Data فقط)، وكيتفتح مباشرة فـ Room Details.
  // ---------------------------------------------------------------
  Future<void> _openCreateRoomScreen() async {
    final result = await Navigator.push<RoomModel>(
      context,
      appPageRoute(
        builder: (_) => CreateRoomScreen(
          ownerName: AppState.userName,
          ownerAvatarPath: 'assets/images/profile.png',
        ),
      ),
    );

    if (result != null && mounted) {
      setState(() {
        _myCreatedRooms.add(result);
        _browseRooms = [result, ..._browseRooms];
      });
      if (!mounted) return;
      Navigator.push(
        context,
        appPageRoute(builder: (_) => RoomDetailsScreen(room: result, onOpenRoom: widget.onOpenRoom)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: _loadRooms,
          child: Column(
            children: [
              _buildHeader(),
              _buildSearchBar(),
              const SizedBox(height: AppSpacing.sm),
              _buildCategoryTabs(),
              const SizedBox(height: AppSpacing.sm),
              Expanded(child: _buildBody()),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------- HEADER ----------------
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.sm),
      child: Row(
        children: [
          Text(S.tr('rooms_title'), style: AppTextStyles.h2),
          const Spacer(),
          _HeaderIconButton(icon: Icons.add, onTap: _openCreateRoomScreen),
        ],
      ),
    );
  }

  // ---------------- SEARCH ----------------
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
      child: TextField(
        controller: _searchController,
        textAlign: TextAlign.right,
        onChanged: (v) => setState(() => _searchQuery = v),
        decoration: InputDecoration(
          hintText: S.tr('rooms_search_hint'),
          hintStyle: AppTextStyles.caption,
          prefixIcon: const Icon(Icons.search, color: AppColors.grey500),
          suffixIcon: _searchQuery.isEmpty
              ? null
              : IconButton(
                  icon: const Icon(Icons.clear, size: 18, color: AppColors.grey500),
                  onPressed: () {
                    _searchController.clear();
                    setState(() => _searchQuery = '');
                  },
                ),
        ),
      ),
    );
  }

  // ---------------- CATEGORY TABS ----------------
  Widget _buildCategoryTabs() {
    return SizedBox(
      height: 38,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        scrollDirection: Axis.horizontal,
        itemCount: _categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final cat = _categories[i];
          return _RoomFilterChip(
            label: _categoryLabel(cat),
            selected: cat == _selectedCategory,
            onTap: () => setState(() => _selectedCategory = cat),
          );
        },
      ),
    );
  }

  // ---------------- BODY (Loading / Error / Empty / Loaded) ----------------
  Widget _buildBody() {
    switch (_state) {
      case _RoomsLoadState.loading:
        return const AppSkeletonList(itemCount: 6, itemHeight: 88);
      case _RoomsLoadState.error:
        return ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            const SizedBox(height: 80),
            AppErrorState(message: S.tr('rooms_load_error'), onRetry: _loadRooms),
          ],
        );
      case _RoomsLoadState.loaded:
        final rooms = _filteredRooms;
        if (rooms.isEmpty) {
          final searching = _searchQuery.trim().isNotEmpty;
          return ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            children: [
              const SizedBox(height: 60),
              AppEmptyState(
                icon: searching ? Icons.search_off : Icons.meeting_room_outlined,
                title: searching ? S.tr('rooms_empty_search_title') : S.tr('rooms_empty_category_title'),
                subtitle: searching ? S.tr('rooms_empty_search_subtitle') : S.tr('rooms_empty_category_subtitle'),
              ),
            ],
          );
        }
        return ListView.separated(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxl),
          itemCount: rooms.length,
          separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.md),
          itemBuilder: (context, i) {
            final room = rooms[i];
            return _BrowseRoomCard(
              room: room,
              onTap: () => Navigator.push(
                context,
                appPageRoute(builder: (_) => RoomDetailsScreen(room: room, onOpenRoom: widget.onOpenRoom)),
              ),
            );
          },
        );
    }
  }
}

/// شريحة تصنيف قابلة للاختيار (تبويبات فلترة شاشة "الغرف") — انيميشن خفيف عند التبديل
class _RoomFilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _RoomFilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.pill),
          border: selected ? null : Border.all(color: AppColors.border),
          boxShadow: selected ? AppShadows.card : null,
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: AppTextStyles.bodyBold.copyWith(
            fontSize: 13,
            color: selected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

/// كرت غرفة فقائمة "الغرف" — كرت أفقي احترافي: غلاف، اسم، معرّف الروم،
/// صاحب الروم + أفاتار، عدد المتصلين، تصنيف، شارة (جديد/مشتعلة/مقفلة)، زر انضمام
class _BrowseRoomCard extends StatefulWidget {
  final RoomModel room;
  final VoidCallback onTap;
  const _BrowseRoomCard({required this.room, required this.onTap});

  @override
  State<_BrowseRoomCard> createState() => _BrowseRoomCardState();
}

class _BrowseRoomCardState extends State<_BrowseRoomCard> {
  double _scale = 1;
  void _setPressed(bool pressed) => setState(() => _scale = pressed ? 0.98 : 1);

  String? get _badgeLabel {
    final room = widget.room;
    if (room.isNew) return S.tr('rooms_badge_new');
    if (room.isPopular && room.onlineCount >= 150) return S.tr('rooms_badge_hot');
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final room = widget.room;
    final badge = _badgeLabel;
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => _setPressed(true),
      onTapUp: (_) => _setPressed(false),
      onTapCancel: () => _setPressed(false),
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 110),
        child: Container(
          padding: const EdgeInsets.all(AppSpacing.sm),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            boxShadow: AppShadows.card,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // غلاف الروم
              Stack(
                clipBehavior: Clip.none,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    child: Image.asset(
                      room.imagePath ?? 'assets/images/room_bg_official.webp',
                      width: 76,
                      height: 76,
                      fit: BoxFit.cover,
                    ),
                  ),
                  if (room.isRoomLocked)
                    Positioned(
                      top: 4,
                      left: 4,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(color: Colors.black.withOpacity(0.55), shape: BoxShape.circle),
                        child: Image.asset('assets/images/icon_lock.webp', width: 11, height: 11),
                      ),
                    ),
                  if (badge != null)
                    Positioned(
                      bottom: 4,
                      left: 4,
                      right: 4,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(AppRadius.sm)),
                        child: Text(
                          badge,
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: AppSpacing.md),
              // معلومات الروم
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(room.name, style: AppTextStyles.bodyBold, maxLines: 1, overflow: TextOverflow.ellipsis),
                        ),
                        if (room.category != null) ...[
                          const SizedBox(width: 6),
                          _CategoryChipLight(label: room.category!),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text('ID: ${room.roomCode ?? room.id ?? '—'}', style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _CircleIcon(imagePath: room.ownerAvatarPath ?? 'assets/images/profile.png', size: 20),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(room.ownerName ?? S.tr('unknown_owner'), style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
                        ),
                        const Icon(Icons.people_alt, size: 13, color: AppColors.grey500),
                        const SizedBox(width: 3),
                        Text('${room.onlineCount}', style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              // زر الانضمام / المشاهدة
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
                child: Text(S.tr('rooms_join_btn'), style: AppTextStyles.bodyBold.copyWith(color: AppColors.primary, fontSize: 12)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// شارة تصنيف خفيفة (خلفية فاتحة) تُستعمل فوق كروت "الغرف" الأفقية
/// (مختلفة عن _CategoryChip المستعملة فوق صور Home الغامقة)
class _CategoryChipLight extends StatelessWidget {
  final String label;
  const _CategoryChipLight({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(AppRadius.pill)),
      child: Text(label, style: AppTextStyles.caption.copyWith(fontSize: 10, fontWeight: FontWeight.w600)),
    );
  }
}

/// نموذج بيانات اللعبة: اسمها، مسار ملفها (index.html) جوة assets، ولون وأيقونة نصية للعرض فالشبكة
/// شبكة الألعاب المتاحة (تبان أول مرة كتحل ورقة الألعاب من الأسفل)
class _GamesGrid extends StatelessWidget {
  final List<GameModel> games;
  final ValueChanged<GameModel> onSelect;

  const _GamesGrid({required this.games, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF160604),
      padding: const EdgeInsets.all(16),
      child: GridView.builder(
        itemCount: games.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 14,
          mainAxisSpacing: 14,
          childAspectRatio: 0.85,
        ),
        itemBuilder: (context, index) {
          final game = games[index];
          return GestureDetector(
            onTap: () {
              if (!game.isPlayable) {
                ScaffoldMessenger.of(context).hideCurrentSnackBar();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${game.name} — متوفرة قريبًا 🚧'), duration: const Duration(seconds: 2)),
                );
                return;
              }
              onSelect(game);
            },
            child: Opacity(
              opacity: game.isPlayable ? 1.0 : 0.55,
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: game.color,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: game.color.withOpacity(0.4),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      alignment: Alignment.center,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Text(game.emoji, style: const TextStyle(fontSize: 34)),
                          if (!game.isPlayable)
                            Positioned(
                              bottom: 6,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: Colors.black.withOpacity(0.55), borderRadius: BorderRadius.circular(20)),
                                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                                  Icon(Icons.lock_outline_rounded, size: 10, color: Colors.white),
                                  SizedBox(width: 3),
                                  Text('قريبًا', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700)),
                                ]),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    game.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// عرض اللعبة المختارة جوة WebView (اللعبة عبارة عن ملف index.html مدمج فـ assets)
class _GameWebView extends StatefulWidget {
  final String assetPath;
  final VoidCallback onClose;

  const _GameWebView({super.key, required this.assetPath, required this.onClose});

  @override
  State<_GameWebView> createState() => _GameWebViewState();
}

class _GameWebViewState extends State<_GameWebView> {
  late final WebViewController _controller;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF160604))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _loading = false);
          },
          onWebResourceError: (error) {
            if (mounted) {
              setState(() {
                _loading = false;
                _error = error.description;
              });
            }
          },
        ),
      )
      ..loadFlutterAsset(widget.assetPath);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF160604),
      child: Stack(
        children: [
          Positioned.fill(child: WebViewWidget(controller: _controller)),
          if (_loading)
            const Positioned.fill(
              child: Center(child: CircularProgressIndicator(color: Colors.white)),
            ),
          if (_error != null)
            Positioned.fill(
              child: Container(
                color: const Color(0xFF160604),
                alignment: Alignment.center,
                padding: const EdgeInsets.all(24),
                child: Text(
                  'تعذر تحميل اللعبة',
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
