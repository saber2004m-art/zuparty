import 'package:flutter/material.dart';

/// ============================================================
/// Animations Foundation — انتقال صفحات خفيف واحترافي
/// بديل موحّد لـ MaterialPageRoute يضيف Fade + Slide بسيط
/// بدون التأثير على الأداء (مدة قصيرة + منحنى بسيط)
/// ============================================================
PageRouteBuilder<T> appPageRoute<T>({required WidgetBuilder builder}) {
  return PageRouteBuilder<T>(
    pageBuilder: (context, animation, secondaryAnimation) => builder(context),
    transitionDuration: const Duration(milliseconds: 240),
    reverseTransitionDuration: const Duration(milliseconds: 200),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0.03, 0), end: Offset.zero).animate(curved),
          child: child,
        ),
      );
    },
  );
}
