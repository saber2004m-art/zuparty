import 'package:flutter/material.dart';

/// ============================================================
/// Phase 5 — Part 3/3: تحكّم بسيط فاللغة الحالية للتطبيق
/// (بدون أي مكتبة خارجية — ValueNotifier + setState فـ ZupartyApp)
/// اللغات المدعومة: العربية (ar / RTL) — Français (fr) — English (en)
/// ============================================================
class LocaleController {
  LocaleController._();

  /// اللغة الحالية. القيمة الافتراضية العربية (نفس سلوك التطبيق قبل هاد الجزء).
  static final ValueNotifier<String> languageCode = ValueNotifier<String>('ar');

  static const Map<String, String> supportedLanguages = {
    'ar': 'العربية',
    'fr': 'Français',
    'en': 'English',
  };

  static bool get isRtl => languageCode.value == 'ar';

  static Locale get locale => Locale(languageCode.value);

  static void setLanguage(String code) {
    if (supportedLanguages.containsKey(code)) {
      languageCode.value = code;
    }
  }
}
