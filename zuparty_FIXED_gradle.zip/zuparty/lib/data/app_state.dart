import 'mock_data.dart';

/// ============================================================
/// حالة بسيطة على مستوى التطبيق (بدون backend حقيقي، غير جلسة مؤقتة)
/// Phase 5 — Part 2: تم فصلها فملف خاص باش تقدر تنستعمل من main.dart
/// ومن lib/screens/profile/profile_screen.dart بلا Circular Import.
/// ============================================================
class AppState {
  static String userName = 'مستخدم Zuparty';
  static String? userGender; // 'ذكر' أو 'أنثى'
  static bool isNewAccount = true; // كل حساب جديد كيبان عليه بادج NEW

  /// رصيد Coins المعروض فـ Home — موحّد مع MockData.userCoinBalance
  /// (نفس الرصيد المستعمل فالمحفظة/الهدايا/VIP) باش ما يبقاوش رصيدين مختلفين.
  static int get userCoins => MockData.userCoinBalance;
  static set userCoins(int value) => MockData.userCoinBalance = value;
}
