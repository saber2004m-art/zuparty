import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../data/mock_data.dart';
import '../../data/models.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import '../../widgets/app_states.dart';

/// ============================================================
/// Phase 5 — Part 3/3: شاشة الترتيب الكاملة (Rankings)
/// عام / أسبوعي / شهري × مستخدمين / غرف / هدايا / ثروة / مساهمة
/// كلها Mock Data محلية — Leaderboard UI مع بوديوم لأفضل 3.
/// ============================================================
enum _RankPeriod { global, weekly, monthly }

class RankingsScreen extends StatefulWidget {
  const RankingsScreen({super.key});

  @override
  State<RankingsScreen> createState() => _RankingsScreenState();
}

class _RankingsScreenState extends State<RankingsScreen> {
  _RankPeriod _period = _RankPeriod.global;
  int _categoryIndex = 0;

  late final List<Map<String, dynamic>> _categories = [
    {'label': S.tr('rankings_users'), 'icon': Icons.person_rounded},
    {'label': S.tr('rankings_rooms'), 'icon': Icons.meeting_room_rounded},
    {'label': S.tr('rankings_gifts'), 'icon': Icons.card_giftcard_rounded},
    {'label': S.tr('rankings_wealth'), 'icon': Icons.diamond_rounded},
    {'label': S.tr('rankings_contribution'), 'icon': Icons.volunteer_activism_rounded},
  ];

  List<RankingEntry> get _entries {
    // نختار لائحة Mock مناسبة حسب التصنيف + الفترة (بعض اللوائح مشتركة لعدة فترات فهاد Mock)
    switch (_categoryIndex) {
      case 0: // Users
        return _period == _RankPeriod.monthly ? MockData.monthlyRanking : MockData.rankings;
      case 1: // Rooms
        return MockData.roomWeeklyRanking;
      case 2: // Gifts
        return MockData.giftSendersRanking;
      case 3: // Wealth
        return MockData.userWealthRanking;
      case 4: // Contribution
        return MockData.contributionRanking;
      default:
        return MockData.rankings;
    }
  }

  @override
  Widget build(BuildContext context) {
    final entries = List<RankingEntry>.from(_entries)..sort((a, b) => a.rank.compareTo(b.rank));
    final podium = entries.take(3).toList();
    final rest = entries.length > 3 ? entries.sublist(3) : <RankingEntry>[];

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: zpAppBar(S.tr('rankings_title')),
      body: Column(
        children: [
          _buildPeriodTabs(),
          _buildCategoryChips(),
          const SizedBox(height: AppSpacing.sm),
          Expanded(
            child: entries.isEmpty
                ? AppEmptyState(icon: Icons.emoji_events_outlined, title: S.tr('rankings_empty'))
                : ListView(
                    padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxl),
                    children: [
                      if (podium.isNotEmpty) _Podium(entries: podium),
                      const SizedBox(height: AppSpacing.lg),
                      ...rest.map((e) => RankListTile(entry: e)),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodTabs() {
    final tabs = [
      (_RankPeriod.global, S.tr('rankings_global')),
      (_RankPeriod.weekly, S.tr('rankings_weekly')),
      (_RankPeriod.monthly, S.tr('rankings_monthly')),
    ];
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
      child: Row(
        children: tabs.map((t) {
          final selected = _period == t.$1;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _period = t.$1),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: selected ? AppColors.primary : AppColors.surface,
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
                alignment: Alignment.center,
                child: Text(
                  t.$2,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildCategoryChips() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.only(bottom: AppSpacing.md),
      child: SizedBox(
        height: 36,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
          itemCount: _categories.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (context, i) {
            final selected = _categoryIndex == i;
            return GestureDetector(
              onTap: () => setState(() => _categoryIndex = i),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected ? AppColors.primaryLight : AppColors.surface,
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                  border: Border.all(color: selected ? AppColors.primary : AppColors.border),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(_categories[i]['icon'] as IconData, size: 14, color: selected ? AppColors.primaryDark : AppColors.grey600),
                    const SizedBox(width: 5),
                    Text(
                      _categories[i]['label'] as String,
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: selected ? AppColors.primaryDark : AppColors.grey600),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// بوديوم أفضل 3 (Leaderboard UI)
class _Podium extends StatelessWidget {
  final List<RankingEntry> entries;
  const _Podium({required this.entries});

  @override
  Widget build(BuildContext context) {
    RankingEntry? at(int i) => entries.length > i ? entries[i] : null;
    final first = at(0), second = at(1), third = at(2);

    return Container(
      margin: const EdgeInsets.only(top: AppSpacing.lg),
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xl, horizontal: AppSpacing.md),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppColors.secondary, Color(0xFF241038)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        borderRadius: BorderRadius.circular(AppRadius.xl),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (second != null) _PodiumSpot(entry: second, height: 78, color: const Color(0xFFB0BEC5), place: 2),
          const SizedBox(width: 8),
          if (first != null) _PodiumSpot(entry: first, height: 104, color: const Color(0xFFFFD54F), place: 1),
          const SizedBox(width: 8),
          if (third != null) _PodiumSpot(entry: third, height: 62, color: const Color(0xFFFFAB91), place: 3),
        ],
      ),
    );
  }
}

class _PodiumSpot extends StatelessWidget {
  final RankingEntry entry;
  final double height;
  final Color color;
  final int place;

  const _PodiumSpot({required this.entry, required this.height, required this.color, required this.place});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              ZpAvatar(imagePath: entry.avatarPath, size: place == 1 ? 60 : 48, showVipRing: entry.isVip),
              Positioned(
                bottom: -6,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                  alignment: Alignment.center,
                  child: Text('$place', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Colors.black87)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(entry.userName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5)),
          const SizedBox(height: 2),
          Text('${entry.score}', style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
          const SizedBox(height: 8),
          Container(
            height: height,
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadius.md)),
            ),
          ),
        ],
      ),
    );
  }
}

/// صف واحد فباقي قائمة الترتيب (بعد البوديوم) — عام، مستعمل تاني فـ Event Details
class RankListTile extends StatelessWidget {
  final RankingEntry entry;
  const RankListTile({super.key, required this.entry});

  @override
  Widget build(BuildContext context) {
    final upOrDown = entry.levelChange;
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
      child: Row(
        children: [
          SizedBox(
            width: 26,
            child: Text('${entry.rank}', style: AppTextStyles.bodyBold.copyWith(color: AppColors.grey500)),
          ),
          const SizedBox(width: 8),
          ZpAvatar(imagePath: entry.avatarPath, size: 40, showVipRing: entry.isVip),
          const SizedBox(width: 10),
          Expanded(
            child: Text(entry.userName, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.bodyBold),
          ),
          if (upOrDown != 0)
            Icon(upOrDown > 0 ? Icons.arrow_drop_up_rounded : Icons.arrow_drop_down_rounded, color: upOrDown > 0 ? AppColors.success : AppColors.danger, size: 22),
          Text('${entry.score}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary, fontSize: 13)),
        ],
      ),
    );
  }
}
