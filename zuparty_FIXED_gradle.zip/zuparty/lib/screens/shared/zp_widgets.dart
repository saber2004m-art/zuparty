import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../l10n/app_strings.dart';

/// ============================================================
/// Phase 5 — Part 2: Widgets مشتركة بين Chat / Profile / Games /
/// Wallet / Gifts / VIP — كلها مبنية فوق Design System الموجود.
/// ============================================================

/// أفاتار دائري موحّد (صورة أو أيقونة) + بادج اختياري (أونلاين / VIP)
class ZpAvatar extends StatelessWidget {
  final String? imagePath;
  final IconData? icon;
  final double size;
  final bool showOnlineDot;
  final bool showVipRing;

  const ZpAvatar({
    super.key,
    this.imagePath,
    this.icon,
    this.size = 48,
    this.showOnlineDot = false,
    this.showVipRing = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.grey100,
              border: Border.all(
                color: showVipRing ? const Color(0xFFF9A825) : AppColors.border,
                width: showVipRing ? 2 : 1,
              ),
            ),
            child: imagePath != null
                ? Image.asset(imagePath!, fit: BoxFit.cover)
                : Icon(icon ?? Icons.person, size: size * 0.5, color: AppColors.grey500),
          ),
          if (showOnlineDot)
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                width: size * 0.26,
                height: size * 0.26,
                decoration: BoxDecoration(
                  color: AppColors.success,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// رأس قسم موحّد (عنوان + رابط "الكل" اختياري)
class ZpSectionHeader extends StatelessWidget {
  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  const ZpSectionHeader({super.key, required this.title, this.actionLabel, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
      child: Row(
        children: [
          Text(title, style: AppTextStyles.h3),
          const Spacer(),
          if (actionLabel != null)
            GestureDetector(
              onTap: onAction,
              child: Text(actionLabel!, style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 12.5)),
            ),
        ],
      ),
    );
  }
}

/// شارة صغيرة (مثال: عدد الرصيد، مستوى VIP...)
class ZpPill extends StatelessWidget {
  final String label;
  final Color color;
  final Color? textColor;
  final IconData? icon;

  const ZpPill({super.key, required this.label, this.color = AppColors.surface, this.textColor, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(AppRadius.pill)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 13, color: textColor ?? AppColors.textPrimary), const SizedBox(width: 4)],
          Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: textColor ?? AppColors.textPrimary)),
        ],
      ),
    );
  }
}

/// Snackbar موحّد لأي فعل محلي (Mock) — بديل موحّد لعرض تأكيد سريع
void zpToast(BuildContext context, String message, {IconData icon = Icons.check_circle_rounded, Color color = AppColors.success}) {
  ScaffoldMessenger.of(context).hideCurrentSnackBar();
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.textPrimary,
      duration: const Duration(seconds: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
      content: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(child: Text(message, style: const TextStyle(color: Colors.white, fontSize: 13))),
        ],
      ),
    ),
  );
}

/// Bottom Sheet تأكيد موحّد (حذف / حظر / إبلاغ...) — يرجع true إذا أكّد المستخدم
Future<bool> zpConfirmSheet(
  BuildContext context, {
  required String title,
  required String message,
  String? confirmLabel,
  IconData icon = Icons.warning_amber_rounded,
  Color color = AppColors.danger,
}) async {
  final result = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl))),
    builder: (ctx) {
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(AppSpacing.xl, AppSpacing.lg, AppSpacing.xl, AppSpacing.xl),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
              const SizedBox(height: AppSpacing.lg),
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
                child: Icon(icon, color: color, size: 28),
              ),
              const SizedBox(height: AppSpacing.md),
              Text(title, style: AppTextStyles.h3, textAlign: TextAlign.center),
              const SizedBox(height: AppSpacing.xs),
              Text(message, style: AppTextStyles.caption, textAlign: TextAlign.center),
              const SizedBox(height: AppSpacing.xl),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 13)),
                      child: Text(S.tr('cancel')),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 13),
                      ),
                      child: Text(confirmLabel ?? S.tr('confirm')),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
  return result ?? false;
}

/// عنوان AppBar موحّد بسيط (خلفية بيضاء + رجوع + عنوان فالوسط)
PreferredSizeWidget zpAppBar(String title, {List<Widget>? actions, Color? bg}) {
  return AppBar(
    backgroundColor: bg ?? Colors.white,
    elevation: 0,
    centerTitle: true,
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
    actions: actions,
  );
}
