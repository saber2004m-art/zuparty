import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../routing/app_page_route.dart';
import '../shared/zp_widgets.dart';
import 'conversation_screen.dart';

/// ============================================================
/// Phase 5 — Part 2: Chat — قائمة المحادثات
/// UI/UX + Local State + Mock Data فقط (بلا Backend)
/// ============================================================
class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key});

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

enum _ChatLoadState { loading, empty, error, ready }

class _ChatListScreenState extends State<ChatListScreen> {
  late List<ConversationPreview> _all;
  List<ConversationPreview> _filtered = [];
  final _searchController = TextEditingController();
  _ChatLoadState _state = _ChatLoadState.loading;

  @override
  void initState() {
    super.initState();
    _all = MockData.conversations;
    _load();
  }

  Future<void> _load() async {
    setState(() => _state = _ChatLoadState.loading);
    await Future.delayed(const Duration(milliseconds: 450));
    if (!mounted) return;
    setState(() {
      _filtered = List.of(_all);
      _state = _all.isEmpty ? _ChatLoadState.empty : _ChatLoadState.ready;
    });
  }

  void _onSearch(String q) {
    setState(() {
      _filtered = q.trim().isEmpty
          ? List.of(_all)
          : _all.where((c) => c.name.contains(q) || c.lastMessage.contains(q)).toList();
    });
  }

  Future<void> _onDelete(ConversationPreview c) async {
    final ok = await zpConfirmSheet(
      context,
      title: 'حذف المحادثة',
      message: 'غادي يتحذف سجل المحادثة مع ${c.name} من عندك فقط.',
      confirmLabel: 'حذف',
      icon: Icons.delete_outline_rounded,
    );
    if (!ok) return;
    setState(() {
      _all.remove(c);
      _filtered.remove(c);
      if (_all.isEmpty) _state = _ChatLoadState.empty;
    });
    if (mounted) zpToast(context, 'تم حذف المحادثة', icon: Icons.delete_outline_rounded, color: AppColors.danger);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar('الدردشة', actions: [
        IconButton(
          tooltip: 'تحديث',
          onPressed: _load,
          icon: const Icon(Icons.refresh_rounded, color: AppColors.textPrimary),
        ),
      ]),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.sm),
            child: TextField(
              controller: _searchController,
              onChanged: _onSearch,
              textAlign: TextAlign.right,
              decoration: InputDecoration(
                hintText: 'بحث فالمحادثات...',
                prefixIcon: const Icon(Icons.search_rounded, size: 20),
                filled: true,
                fillColor: AppColors.surface,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppRadius.pill), borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    switch (_state) {
      case _ChatLoadState.loading:
        return const AppSkeletonList(itemCount: 6, itemHeight: 60);
      case _ChatLoadState.error:
        return AppErrorState(message: 'تعذّر تحميل المحادثات', onRetry: _load);
      case _ChatLoadState.empty:
        return AppEmptyState(
          icon: Icons.chat_bubble_outline_rounded,
          title: 'ما عندكش محادثات بعد',
          subtitle: 'ابدأ محادثة من بروفيل أي مستخدم أو من غرفة صوتية',
        );
      case _ChatLoadState.ready:
        if (_filtered.isEmpty) {
          return const AppEmptyState(icon: Icons.search_off_rounded, title: 'ما لقيناش نتائج');
        }
        return ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
          itemCount: _filtered.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 78, color: AppColors.divider),
          itemBuilder: (context, i) => _ConversationTile(
            conversation: _filtered[i],
            onDelete: () => _onDelete(_filtered[i]),
            onOpen: () async {
              setState(() => _filtered[i].unreadCount = 0);
              await Navigator.push(context, appPageRoute(builder: (_) => ConversationScreen(conversation: _filtered[i])));
              if (mounted) setState(() {});
            },
          ),
        );
    }
  }
}

class _ConversationTile extends StatelessWidget {
  final ConversationPreview conversation;
  final VoidCallback onOpen;
  final VoidCallback onDelete;

  const _ConversationTile({required this.conversation, required this.onOpen, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: ValueKey(conversation.id),
      direction: DismissDirection.endToStart,
      confirmDismiss: (_) async {
        onDelete();
        return false; // الحذف الفعلي كيتصيّفط عبر setState فـ _onDelete
      },
      background: Container(
        color: AppColors.danger,
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.only(left: 20),
        child: const Icon(Icons.delete_outline_rounded, color: Colors.white),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: 4),
        leading: ZpAvatar(imagePath: conversation.avatarPath, size: 52, showOnlineDot: conversation.isOnline, showVipRing: conversation.isVip),
        title: Row(
          children: [
            Flexible(child: Text(conversation.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5), overflow: TextOverflow.ellipsis)),
            if (conversation.isVip) const Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.workspace_premium_rounded, size: 14, color: Color(0xFFF9A825))),
          ],
        ),
        subtitle: Text(
          conversation.lastMessage,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: conversation.unreadCount > 0 ? AppColors.textPrimary : AppColors.textSecondary,
            fontWeight: conversation.unreadCount > 0 ? FontWeight.w600 : FontWeight.w400,
            fontSize: 12.5,
          ),
        ),
        trailing: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(conversation.time, style: const TextStyle(color: AppColors.grey500, fontSize: 10.5)),
            const SizedBox(height: 6),
            if (conversation.unreadCount > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                constraints: const BoxConstraints(minWidth: 18),
                child: Text('${conversation.unreadCount}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
              )
            else
              const SizedBox(height: 18),
          ],
        ),
        onTap: onOpen,
      ),
    );
  }
}
