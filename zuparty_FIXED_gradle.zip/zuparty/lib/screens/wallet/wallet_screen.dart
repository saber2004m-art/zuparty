import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../l10n/app_strings.dart';
import '../../data/mock_data.dart';
import '../../routing/app_page_route.dart';
import '../shared/zp_widgets.dart';
import 'transactions_screen.dart';

/// ============================================================
/// Phase 5 — Part 2: Wallet / Coins — رصيد، باقات شحن، سجل معاملات
/// ============================================================
class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  Future<void> _openRecharge(CoinPackage pkg) async {
    final ok = await zpConfirmSheet(
      context,
      title: S.tr('p2a_ba4e0018'),
      message: S.trParams('p2a_recharge_message', {'coins': pkg.coins.toString(), 'price': pkg.priceLabel}),
      confirmLabel: S.tr('p2a_e2b43c7e'),
      icon: Icons.add_card_rounded,
      color: AppColors.primary,
    );
    if (!ok || !mounted) return;
    setState(() {
      MockData.userCoinBalance += pkg.coins;
      MockData.walletTransactions.insert(0, WalletTransaction(
        id: 'recharge_${DateTime.now().microsecondsSinceEpoch}',
        type: WalletTxType.recharge,
        title: 'إعادة شحن',
        amount: pkg.coins,
        time: DateTime.now(),
      ));
    });
    zpToast(context, S.trParams('p2a_recharge_done', {'coins': pkg.coins.toString()}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: zpAppBar(S.tr('p2a_1fe6b8e1'), actions: [
        IconButton(
          icon: const Icon(Icons.receipt_long_rounded, color: AppColors.textPrimary),
          tooltip: S.tr('p2a_c918004a'),
          onPressed: () => Navigator.push(context, appPageRoute(builder: (_) => const TransactionsScreen())),
        ),
      ]),
      body: _loading
          ? const AppSkeletonList(itemCount: 6, itemHeight: 60)
          : ListView(
              padding: const EdgeInsets.all(AppSpacing.lg),
              children: [
                _buildBalanceCard(),
                const SizedBox(height: AppSpacing.xl),
                ZpSectionHeader(title: S.tr('p2a_35f55861')),
                _buildPackagesGrid(),
                const SizedBox(height: AppSpacing.xl),
                ZpSectionHeader(
                  title: S.tr('p2a_4022bc9d'),
                  actionLabel: S.tr('see_all'),
                  onAction: () => Navigator.push(context, appPageRoute(builder: (_) => const TransactionsScreen())),
                ),
                ..._buildRecentTx(),
              ],
            ),
    );
  }

  Widget _buildBalanceCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl), boxShadow: AppShadows.card),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(S.tr('p2a_5b6b1858'), style: TextStyle(color: Colors.white70, fontSize: 12.5)),
          const SizedBox(height: 6),
          Row(
            children: [
              const Icon(Icons.monetization_on_rounded, color: Colors.white, size: 28),
              const SizedBox(width: 8),
              Text('${MockData.userCoinBalance}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 30)),
            ],
          ),
          const SizedBox(height: 4),
          Text('Coins', style: TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildPackagesGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.only(top: AppSpacing.sm),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.9),
      itemCount: MockData.coinPackages.length,
      itemBuilder: (context, i) {
        final pkg = MockData.coinPackages[i];
        return GestureDetector(
          onTap: () => _openRecharge(pkg),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: pkg.isBestValue ? AppColors.primary : AppColors.border),
              boxShadow: AppShadows.card,
            ),
            child: Stack(
              children: [
                if (pkg.isBestValue)
                  Positioned(
                    top: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: const BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.only(topRight: Radius.circular(AppRadius.md), bottomLeft: Radius.circular(AppRadius.md))),
                      child: Text(S.tr('p2a_768028e2'), style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800)),
                    ),
                  ),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.monetization_on_rounded, color: Color(0xFFF9A825), size: 26),
                      const SizedBox(height: 6),
                      Text('${pkg.coins}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                      const SizedBox(height: 4),
                      Text(pkg.priceLabel, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  List<Widget> _buildRecentTx() {
    final tx = MockData.walletTransactions.take(4).toList();
    if (tx.isEmpty) {
      return [AppEmptyState(icon: Icons.receipt_long_outlined, title: S.tr('p2a_e5313d30'))];
    }
    return tx.map((t) => TxTile(tx: t)).toList();
  }
}

class TxTile extends StatelessWidget {
  final WalletTransaction tx;
  const TxTile({super.key, required this.tx});

  IconData get _icon {
    switch (tx.type) {
      case WalletTxType.recharge:
        return Icons.add_card_rounded;
      case WalletTxType.giftSent:
        return Icons.card_giftcard_rounded;
      case WalletTxType.giftReceived:
        return Icons.redeem_rounded;
      case WalletTxType.gameWin:
        return Icons.emoji_events_rounded;
      case WalletTxType.gameLoss:
        return Icons.sports_esports_rounded;
      case WalletTxType.vipSub:
        return Icons.workspace_premium_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final positive = tx.amount >= 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.md), boxShadow: AppShadows.card),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: (positive ? AppColors.success : AppColors.danger).withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(_icon, size: 19, color: positive ? AppColors.success : AppColors.danger),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tx.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                Text('${tx.time.day}/${tx.time.month} — ${tx.time.hour.toString().padLeft(2, '0')}:${tx.time.minute.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 10.5, color: AppColors.grey500)),
              ],
            ),
          ),
          Text('${positive ? '+' : ''}${tx.amount}', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: positive ? AppColors.success : AppColors.danger)),
        ],
      ),
    );
  }
}
