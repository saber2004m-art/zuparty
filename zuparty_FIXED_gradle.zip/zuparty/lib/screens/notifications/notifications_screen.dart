import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../data/mock_data.dart';
import '../../data/models.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import '../../widgets/app_states.dart';

/// ============================================================
/// Phase 5 — Part 3/3: شاشة الإشعارات الكاملة
/// النظام / الهدايا / اجتماعي (متابعون، إعجابات، دعوات) / فعاليات / رسائل
/// Read/Unread محلي + تبويبات — Mock Data فقط.
/// ============================================================
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 4, vsync: this);
  late List<NotificationItem> _items = List.of(MockData.notificationsDetailed);

  List<NotificationItem> _filtered(int tabIndex) {
    switch (tabIndex) {
      case 1:
        return _items.where((n) => n.type == NotificationType.system).toList();
      case 2:
        return _items.where((n) => n.type == NotificationType.gift).toList();
      case 3:
        return _items.where((n) => n.type == NotificationType.follower || n.type == NotificationType.like || n.type == NotificationType.roomInvite || n.type == NotificationType.message).toList();
      default:
        return _items;
    }
  }

  void _markAllRead() {
    setState(() {
      _items = _items.map((n) => n.copyWith(isRead: true)).toList();
    });
  }

  void _markRead(NotificationItem n) {
    setState(() {
      final i = _items.indexWhere((x) => x.id == n.id);
      if (i != -1) _items[i] = _items[i].copyWith(isRead: true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: Text(S.tr('notifications_title'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        actions: [
          TextButton(onPressed: _markAllRead, child: Text(S.tr('notifications_mark_all_read'), style: const TextStyle(fontSize: 11.5))),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.grey500,
          indicatorColor: AppColors.primary,
          tabs: [
            Tab(text: S.tr('notifications_all')),
            Tab(text: S.tr('notifications_system')),
            Tab(text: S.tr('notifications_gifts')),
            Tab(text: S.tr('notifications_social')),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: List.generate(4, (i) => _buildList(_filtered(i))),
      ),
    );
  }

  Widget _buildList(List<NotificationItem> items) {
    if (items.isEmpty) {
      return AppEmptyState(icon: Icons.notifications_none_rounded, title: S.tr('notifications_empty'));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
      itemBuilder: (context, i) => _NotificationTile(item: items[i], onTap: () => _markRead(items[i])),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  final NotificationItem item;
  final VoidCallback onTap;
  const _NotificationTile({required this.item, required this.onTap});

  IconData get _icon {
    switch (item.type) {
      case NotificationType.gift:
        return Icons.card_giftcard_rounded;
      case NotificationType.follower:
        return Icons.person_add_alt_1_rounded;
      case NotificationType.like:
        return Icons.favorite_rounded;
      case NotificationType.roomInvite:
        return Icons.meeting_room_rounded;
      case NotificationType.event:
        return Icons.celebration_rounded;
      case NotificationType.message:
        return Icons.chat_bubble_rounded;
      case NotificationType.system:
        return Icons.campaign_rounded;
    }
  }

  Color get _iconColor {
    switch (item.type) {
      case NotificationType.gift:
        return AppColors.warning;
      case NotificationType.follower:
        return AppColors.info;
      case NotificationType.like:
        return AppColors.danger;
      case NotificationType.roomInvite:
        return AppColors.secondary;
      case NotificationType.event:
        return AppColors.primary;
      case NotificationType.message:
        return AppColors.success;
      case NotificationType.system:
        return AppColors.grey600;
    }
  }

  String _timeLabel() {
    final diff = DateTime.now().difference(item.time);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    return '${diff.inDays}d';
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: item.isRead ? Colors.white : AppColors.primaryLight.withOpacity(0.25),
          borderRadius: BorderRadius.circular(AppRadius.lg),
          boxShadow: AppShadows.card,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (item.avatarPath != null)
              ZpAvatar(imagePath: item.avatarPath, size: 42)
            else
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(color: _iconColor.withOpacity(0.12), shape: BoxShape.circle),
                child: Icon(_icon, color: _iconColor, size: 20),
              ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(item.title, style: AppTextStyles.bodyBold, maxLines: 1, overflow: TextOverflow.ellipsis)),
                      Text(_timeLabel(), style: AppTextStyles.caption),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(item.body, style: AppTextStyles.caption, maxLines: 2, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            if (!item.isRead) ...[
              const SizedBox(width: 6),
              Container(width: 8, height: 8, margin: const EdgeInsets.only(top: 4), decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle)),
            ],
          ],
        ),
      ),
    );
  }
}
