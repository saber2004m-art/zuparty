import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/mock_data.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';

/// ============================================================
/// Phase 5 — Part 2: سجل الهدايا (مُرسلة / مُستلمة)
/// ============================================================
class GiftHistoryScreen extends StatefulWidget {
  const GiftHistoryScreen({super.key});

  @override
  State<GiftHistoryScreen> createState() => _GiftHistoryScreenState();
}

class _GiftHistoryScreenState extends State<GiftHistoryScreen> with SingleTickerProviderStateMixin {
  late final TabController _tab = TabController(length: 2, vsync: this);

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sent = MockData.voiceRoomGiftHistory;
    final received = MockData.profileReceivedGifts;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: Text(S.tr('p7_gift_history'), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        bottom: TabBar(
          controller: _tab,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          indicatorColor: AppColors.primary,
          tabs: [Tab(text: S.tr('p7_sent_tab')), Tab(text: S.tr('p7_received_tab'))],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          sent.isEmpty
              ? AppEmptyState(icon: Icons.card_giftcard_outlined, title: S.tr('p7_no_sent'))
              : ListView.separated(
                  padding: const EdgeInsets.all(AppSpacing.lg),
                  itemCount: sent.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) => _GiftHistoryTile(name: sent[i].receiver.name, avatarPath: sent[i].receiver.avatarPath, emoji: sent[i].gift.emoji, giftName: sent[i].gift.name, quantity: sent[i].quantity, time: sent[i].time, isSent: true),
                ),
          received.isEmpty
              ? AppEmptyState(icon: Icons.card_giftcard_outlined, title: S.tr('p7_no_received'))
              : ListView.separated(
                  padding: const EdgeInsets.all(AppSpacing.lg),
                  itemCount: received.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) => _GiftHistoryTile(name: received[i].sender.name, avatarPath: received[i].sender.avatarPath, emoji: received[i].gift.emoji, giftName: received[i].gift.name, quantity: received[i].quantity, time: received[i].time, isSent: false),
                ),
        ],
      ),
    );
  }
}

class _GiftHistoryTile extends StatelessWidget {
  final String name;
  final String? avatarPath;
  final String emoji;
  final String giftName;
  final int quantity;
  final DateTime time;
  final bool isSent;

  const _GiftHistoryTile({required this.name, this.avatarPath, required this.emoji, required this.giftName, required this.quantity, required this.time, required this.isSent});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(AppRadius.md)),
      child: Row(
        children: [
          ZpAvatar(imagePath: avatarPath, size: 44),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(S.trParams(isSent ? 'p7_to' : 'p7_from', {'name': name}), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 2),
                Text('$giftName x$quantity', style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Text(emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 8),
          Text('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 10, color: AppColors.grey500)),
        ],
      ),
    );
  }
}
