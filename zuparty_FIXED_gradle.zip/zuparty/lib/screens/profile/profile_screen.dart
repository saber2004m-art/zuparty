import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../data/app_state.dart';
import '../../routing/app_page_route.dart';
import '../shared/zp_widgets.dart';
import '../wallet/wallet_screen.dart';
import '../gifts/gift_center_screen.dart';
import '../vip/vip_screen.dart';
import '../chat/conversation_screen.dart';
import '../friends/friends_screen.dart';
import '../settings/settings_screen.dart';

/// ============================================================
/// Phase 5 — Part 2: Profile — بروفيل شخصي/بروفيل مستخدم آخر
/// UI/UX + Local State + Mock Data فقط (بلا Backend)
/// ============================================================
class ProfileScreen extends StatefulWidget {
  /// إذا null: كنعرضو بروفيل المستخدم الحالي (مربوط بـ AppState + إمكانية التعديل).
  /// إذا مزود: كنعرضو بروفيل مستخدم آخر — بدون خيارات شخصية.
  final UserModel? user;
  const ProfileScreen({super.key, this.user});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late bool _isFollowing;

  bool get _isOwnProfile => widget.user == null;

  @override
  void initState() {
    super.initState();
    final u = widget.user;
    _isFollowing = u == null ? false : MockData.following.any((f) => f.id == u.id);
  }

  void _openMessage() {
    final u = widget.user;
    if (u == null) return;
    Navigator.push(
      context,
      appPageRoute(
        builder: (_) => ConversationScreen(
          conversation: ConversationPreview(
            id: u.id,
            name: u.name,
            avatarPath: u.avatarPath,
            lastMessage: '',
            time: 'الآن',
            isVip: u.isVip,
          ),
        ),
      ),
    );
  }

  Future<void> _sendGift() async {
    final u = widget.user;
    if (u == null) return;
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl))),
      builder: (_) => SendGiftSheet(receiverName: u.name),
    );
    if (result != null && mounted) {
      final gift = result['gift'] as GiftModel;
      zpToast(context, 'تم إرسال ${gift.name} إلى ${u.name} 🎉', icon: Icons.card_giftcard_rounded);
    }
  }

  void _toggleFollow() {
    setState(() => _isFollowing = !_isFollowing);
    zpToast(
      context,
      _isFollowing ? 'أصبحت تتابع ${widget.user!.name}' : 'ألغيت متابعة ${widget.user!.name}',
      icon: _isFollowing ? Icons.person_add_alt_1_rounded : Icons.person_remove_alt_1_rounded,
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.user;
    final displayName = user?.name ?? AppState.userName;
    final avatarPath = user?.avatarPath ?? 'assets/images/profile.png';
    final showNewBadge = user?.isNew ?? AppState.isNewAccount;
    final isVip = user?.isVip ?? false;
    final level = user?.level;

    return Scaffold(
      backgroundColor: AppColors.surface,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          children: [
            _buildHeaderCard(context, displayName, avatarPath, showNewBadge, isVip, level),
            const SizedBox(height: AppSpacing.md),
            if (_isOwnProfile) ...[
              _buildOwnStatsRow(context),
              const SizedBox(height: AppSpacing.lg),
              _buildServiceCardsRow(context),
              const SizedBox(height: AppSpacing.xl),
              const ZpSectionHeader(title: 'الشارات'),
              _buildBadgesRow(),
              const SizedBox(height: AppSpacing.lg),
              const ZpSectionHeader(title: 'آخر الهدايا المستلمة'),
              _buildReceivedGiftsRow(),
              const SizedBox(height: AppSpacing.xl),
              _ProfileMenuButton(
                icon: Icons.person_add_alt_1_rounded,
                label: 'دعوة الأصدقاء',
                onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const FriendsScreen())),
              ),
              _ProfileMenuButton(
                icon: Icons.workspace_premium_rounded,
                label: 'VIP Center',
                onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const VipScreen())),
              ),
              _ProfileMenuButton(
                icon: Icons.support_agent_rounded,
                label: 'خدمة العملاء',
                onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const SupportScreen())),
              ),
              _ProfileMenuButton(
                icon: Icons.settings_outlined,
                label: 'الإعدادات',
                onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const SettingsScreen())),
              ),
            ] else ...[
              const SizedBox(height: AppSpacing.sm),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _toggleFollow,
                      icon: Icon(_isFollowing ? Icons.check_rounded : Icons.person_add_alt_1_rounded, size: 17),
                      label: Text(_isFollowing ? 'متابَع' : 'متابعة'),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _openMessage,
                      icon: const Icon(Icons.chat_bubble_outline_rounded, size: 17),
                      label: const Text('رسالة'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _sendGift,
                  icon: const Icon(Icons.card_giftcard_rounded, size: 17, color: Color(0xFFF9A825)),
                  label: const Text('إرسال هدية'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderCard(BuildContext context, String displayName, String avatarPath, bool showNewBadge, bool isVip, int? level) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl), boxShadow: AppShadows.card),
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              ZpAvatar(imagePath: avatarPath, size: 72, showVipRing: isVip),
              if (showNewBadge)
                const Positioned(top: -6, right: -10, child: _NewBadge()),
            ],
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(child: Text(displayName, style: AppTextStyles.h2, overflow: TextOverflow.ellipsis)),
                    if (_isOwnProfile) ...[
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const EditProfileScreen())),
                        child: const Icon(Icons.edit_rounded, size: 17, color: AppColors.grey500),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  _isOwnProfile ? 'ID: 10000001' : 'ID: ${widget.user!.id}',
                  style: AppTextStyles.caption,
                ),
                const SizedBox(height: 8),
                if (_isOwnProfile)
                  GestureDetector(
                    onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const WalletScreen())),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.monetization_on_rounded, size: 16, color: Color(0xFFF9A825)),
                      const SizedBox(width: 4),
                      Text('${MockData.userCoinBalance} Coins', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 13)),
                    ]),
                  )
                else if (level != null)
                  ZpPill(label: 'المستوى $level', color: AppColors.primary.withOpacity(0.1), textColor: AppColors.primary),
              ],
            ),
          ),
          if (_isOwnProfile)
            IconButton(
              onPressed: () => Navigator.push(context, appPageRoute(builder: (_) => const SettingsScreen())),
              icon: const Icon(Icons.settings_outlined, color: AppColors.grey600),
            ),
        ],
      ),
    );
  }

  Widget _buildOwnStatsRow(BuildContext context) {
    Widget stat(String label, int count, List<UserModel> list) {
      return Expanded(
        child: GestureDetector(
          onTap: () => Navigator.push(context, appPageRoute(builder: (_) => _UserListScreen(title: label, users: list))),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
            child: Column(
              children: [
                Text('$count', style: AppTextStyles.h3),
                const SizedBox(height: 2),
                Text(label, style: AppTextStyles.caption),
              ],
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        stat('المتابَعون', MockData.followers.length, MockData.followers),
        const SizedBox(width: AppSpacing.sm),
        stat('يتابع', MockData.following.length, MockData.following),
        const SizedBox(width: AppSpacing.sm),
        Expanded(
          child: GestureDetector(
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const VipScreen())),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
              child: Column(
                children: [
                  Text('${MockData.userVipPoints}', style: AppTextStyles.h3.copyWith(color: const Color(0xFFF9A825))),
                  const SizedBox(height: 2),
                  const Text('نقاط VIP', style: AppTextStyles.caption),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildServiceCardsRow(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _ProfileServiceCard(
            icon: Icons.account_balance_wallet_rounded,
            iconColor: AppColors.primary,
            title: 'المحفظة',
            subtitle: 'الرصيد و Coins',
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const WalletScreen())),
          ),
        ),
        const SizedBox(width: AppSpacing.sm),
        Expanded(
          child: _ProfileServiceCard(
            icon: Icons.card_giftcard_rounded,
            iconColor: const Color(0xFFF9A825),
            title: 'الهدايا',
            subtitle: 'أرسل هدية / السجل',
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const GiftCenterScreen())),
          ),
        ),
      ],
    );
  }

  Widget _buildBadgesRow() {
    final badges = MockData.badges;
    return SizedBox(
      height: 88,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        itemCount: badges.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final b = badges[i];
          return SizedBox(
            width: 68,
            child: Column(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: b.isUnlocked ? b.color.withOpacity(0.12) : AppColors.grey100,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(b.icon, color: b.isUnlocked ? b.color : AppColors.grey400, size: 24),
                ),
                const SizedBox(height: 6),
                Text(
                  b.isUnlocked ? b.label : (b.progressLabel ?? b.label),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 10, color: b.isUnlocked ? AppColors.textPrimary : AppColors.grey500, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildReceivedGiftsRow() {
    final gifts = MockData.profileReceivedGifts;
    if (gifts.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        child: AppEmptyState(icon: Icons.card_giftcard_outlined, title: 'ما وصلوش هدايا بعد'),
      );
    }
    return SizedBox(
      height: 76,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
        itemCount: gifts.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final g = gifts[i];
          return Container(
            width: 88,
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.md), boxShadow: AppShadows.card),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(g.gift.emoji, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 3),
                Text('من ${g.sender.name}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9.5, color: AppColors.textSecondary)),
                Text('x${g.quantity}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _NewBadge extends StatelessWidget {
  const _NewBadge();
  @override
  Widget build(BuildContext context) {
    return Image.asset('assets/images/badge_new.webp', width: 32, errorBuilder: (_, __, ___) => const SizedBox.shrink());
  }
}

/// كرت خدمة (يُستعمل فصف المحفظة/الهدايا بالبروفيل الشخصي)
class _ProfileServiceCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ProfileServiceCard({required this.icon, required this.iconColor, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(color: iconColor.withOpacity(0.12), shape: BoxShape.circle),
              child: Icon(icon, color: iconColor, size: 19),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: AppTextStyles.bodyBold.copyWith(fontSize: 13)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: AppTextStyles.caption.copyWith(fontSize: 10), maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// زر قائمة كامل العرض (دعوة الأصدقاء، VIP، خدمة العملاء، الإعدادات...)
class _ProfileMenuButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ProfileMenuButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: 14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.md), boxShadow: AppShadows.card),
        child: Row(
          children: [
            Icon(icon, size: 19, color: AppColors.primary),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: AppTextStyles.bodyBold.copyWith(fontSize: 13.5))),
            Icon(Icons.chevron_left, color: AppColors.grey400, size: 20),
          ],
        ),
      ),
    );
  }
}

/// قائمة بسيطة (المتابَعون / يتابع) — Local/Mock فقط
class _UserListScreen extends StatelessWidget {
  final String title;
  final List<UserModel> users;
  const _UserListScreen({required this.title, required this.users});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(title),
      body: users.isEmpty
          ? const AppEmptyState(icon: Icons.people_outline_rounded, title: 'القائمة فارغة')
          : ListView.separated(
              padding: const EdgeInsets.all(AppSpacing.lg),
              itemCount: users.length,
              separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
              itemBuilder: (context, i) {
                final u = users[i];
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: ZpAvatar(imagePath: u.avatarPath, size: 46, showVipRing: u.isVip),
                  title: Text(u.name, style: AppTextStyles.bodyBold),
                  subtitle: Text('المستوى ${u.level}', style: AppTextStyles.caption),
                  onTap: () => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: u))),
                );
              },
            ),
    );
  }
}

/// ============================================================
/// شاشة تعديل البروفيل: تغيير الاسم والصورة
/// ============================================================
class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late final TextEditingController _nameController = TextEditingController(text: AppState.userName);

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar('تعديل البروفيل'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          children: [
            GestureDetector(
              onTap: () => zpToast(context, 'تغيير الصورة: متاح محليًا في النسخة التجريبية', icon: Icons.info_outline_rounded, color: AppColors.info),
              child: Stack(
                alignment: Alignment.bottomLeft,
                children: [
                  const ZpAvatar(imagePath: 'assets/images/profile.png', size: 88),
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                    child: const Icon(Icons.edit_rounded, size: 14, color: Colors.white),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.xxl),
            const Align(alignment: Alignment.centerRight, child: Text('الاسم', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
            const SizedBox(height: AppSpacing.sm),
            TextField(controller: _nameController, textAlign: TextAlign.right),
            const SizedBox(height: AppSpacing.xxl),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    AppState.userName = _nameController.text.trim().isEmpty ? AppState.userName : _nameController.text.trim();
                  });
                  Navigator.pop(context);
                },
                child: const Text('حفظ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

