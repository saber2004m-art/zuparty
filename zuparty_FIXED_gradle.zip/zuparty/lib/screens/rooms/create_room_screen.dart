import 'dart:math';

import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../theme/app_theme.dart';
import 'room_shared_widgets.dart';

/// ============================================================
/// شاشة "إنشاء غرفة" (Create Room) — Phase 3 Part 2
/// نموذج احترافي: اسم، معرّف Room ID تجريبي، غلاف، تصنيف، وصف،
/// إعلان، ثيم/خلفية، خاص/عام، تحقق محلي، وحالة نجاح — كل هادشي
/// UI/Local State/Mock Data فقط بلا أي Backend.
/// ============================================================
class CreateRoomScreen extends StatefulWidget {
  final String ownerName;
  final String? ownerAvatarPath;

  const CreateRoomScreen({super.key, required this.ownerName, this.ownerAvatarPath});

  @override
  State<CreateRoomScreen> createState() => _CreateRoomScreenState();
}

enum _CreateStep { form, submitting, success }

class _CreateRoomScreenState extends State<CreateRoomScreen> {
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _announcementController = TextEditingController();

  late final String _roomCode = _generateRoomCode();

  String _selectedCover = kRoomCoverOptions.first;
  String? _selectedCategory;
  int _selectedThemeIndex = 0;
  bool _isPrivate = false;

  String? _nameError;
  String? _categoryError;

  _CreateStep _step = _CreateStep.form;
  RoomModel? _createdRoom;

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _announcementController.dispose();
    super.dispose();
  }

  String _generateRoomCode() {
    final rnd = Random();
    return List.generate(6, (_) => rnd.nextInt(10)).join();
  }

  bool _validate() {
    setState(() {
      final name = _nameController.text.trim();
      _nameError = name.isEmpty
          ? 'اسم الروم مطلوب'
          : (name.length < 3 ? 'اسم الروم قصير بزاف (3 أحرف على الأقل)' : null);
      _categoryError = _selectedCategory == null ? 'اختر تصنيف الروم' : null;
    });
    return _nameError == null && _categoryError == null;
  }

  Future<void> _submit() async {
    if (!_validate()) {
      showRoomMockFeedback(context, 'كملي البيانات المطلوبة قبل الإنشاء');
      return;
    }

    setState(() => _step = _CreateStep.submitting);
    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;

    final room = RoomModel(
      id: 'room_${DateTime.now().millisecondsSinceEpoch}',
      name: _nameController.text.trim(),
      imagePath: _selectedCover,
      roomCode: _roomCode,
      ownerName: widget.ownerName,
      ownerAvatarPath: widget.ownerAvatarPath ?? 'assets/images/profile.png',
      onlineCount: 1,
      category: _selectedCategory,
      description: _descriptionController.text.trim(),
      announcement: _announcementController.text.trim(),
      isRoomLocked: _isPrivate,
      effectIndex: _selectedThemeIndex,
      isNew: true,
    );

    setState(() {
      _createdRoom = room;
      _step = _CreateStep.success;
    });

    await Future.delayed(const Duration(milliseconds: 1100));
    if (!mounted) return;
    Navigator.pop(context, _createdRoom);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('إنشاء غرفة جديدة'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_forward),
          onPressed: _step == _CreateStep.submitting ? null : () => Navigator.pop(context),
        ),
      ),
      body: AbsorbPointer(
        absorbing: _step != _CreateStep.form,
        child: Stack(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, AppSpacing.xxl),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCoverPicker(),
                  const SizedBox(height: AppSpacing.lg),

                  RoomInfoSection(
                    title: 'معلومات الروم',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text('معرّف الروم (Room ID)', style: AppTextStyles.caption),
                            ),
                            RoomTagChip(icon: Icons.tag, label: _roomCode, background: AppColors.surface),
                          ],
                        ),
                        const SizedBox(height: AppSpacing.md),
                        TextField(
                          controller: _nameController,
                          textAlign: TextAlign.right,
                          maxLength: 30,
                          decoration: InputDecoration(
                            hintText: 'اسم الروم',
                            errorText: _nameError,
                            counterText: '',
                          ),
                          onChanged: (_) {
                            if (_nameError != null) setState(() => _nameError = null);
                          },
                        ),
                        const SizedBox(height: AppSpacing.md),
                        TextField(
                          controller: _descriptionController,
                          textAlign: TextAlign.right,
                          maxLines: 3,
                          maxLength: 150,
                          decoration: const InputDecoration(
                            hintText: 'وصف الروم (اختياري)',
                            counterText: '',
                          ),
                        ),
                        const SizedBox(height: AppSpacing.md),
                        TextField(
                          controller: _announcementController,
                          textAlign: TextAlign.right,
                          maxLines: 2,
                          maxLength: 100,
                          decoration: const InputDecoration(
                            hintText: 'إعلان الروم (اختياري)',
                            counterText: '',
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppSpacing.md),
                  RoomInfoSection(
                    title: 'التصنيف',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: kRoomCategories.map((c) {
                            final selected = c == _selectedCategory;
                            return GestureDetector(
                              onTap: () => setState(() {
                                _selectedCategory = c;
                                _categoryError = null;
                              }),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 150),
                                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: 9),
                                decoration: BoxDecoration(
                                  color: selected ? AppColors.primary : AppColors.surface,
                                  borderRadius: BorderRadius.circular(AppRadius.pill),
                                  border: selected ? null : Border.all(color: AppColors.border),
                                ),
                                child: Text(
                                  c,
                                  style: AppTextStyles.bodyBold.copyWith(
                                    fontSize: 13,
                                    color: selected ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                        if (_categoryError != null) ...[
                          const SizedBox(height: 6),
                          Text(_categoryError!, style: const TextStyle(color: AppColors.danger, fontSize: 12)),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: AppSpacing.md),
                  RoomInfoSection(
                    title: 'ثيم / خلفية المقاعد',
                    child: Row(
                      children: List.generate(kRoomEffectColors.length, (i) {
                        final selected = i == _selectedThemeIndex;
                        return Padding(
                          padding: const EdgeInsets.only(left: AppSpacing.md),
                          child: GestureDetector(
                            onTap: () => setState(() => _selectedThemeIndex = i),
                            child: Column(
                              children: [
                                Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: kRoomEffectColors[i],
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: selected ? AppColors.textPrimary : Colors.transparent,
                                      width: 2.5,
                                    ),
                                  ),
                                  child: selected
                                      ? const Icon(Icons.check, color: Colors.white, size: 18)
                                      : null,
                                ),
                                const SizedBox(height: 4),
                                Text(kRoomEffectNames[i], style: AppTextStyles.caption.copyWith(fontSize: 10)),
                              ],
                            ),
                          ),
                        );
                      }),
                    ),
                  ),

                  const SizedBox(height: AppSpacing.md),
                  RoomInfoSection(
                    title: 'خصوصية الروم',
                    child: Row(
                      children: [
                        Icon(_isPrivate ? Icons.lock_outline : Icons.public, color: AppColors.textSecondary, size: 20),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_isPrivate ? 'روم خاص' : 'روم عام', style: AppTextStyles.bodyBold),
                              Text(
                                _isPrivate ? 'محتاج دعوة أو قفل للدخول' : 'يقدر أي مستخدم يدخل ليه',
                                style: AppTextStyles.caption,
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: _isPrivate,
                          onChanged: (v) => setState(() => _isPrivate = v),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppSpacing.xl),
                  SizedBox(
                    height: 52,
                    child: ElevatedButton(
                      onPressed: _step == _CreateStep.form ? _submit : null,
                      child: const Text('إنشاء الروم'),
                    ),
                  ),
                ],
              ),
            ),

            if (_step != _CreateStep.form) _buildOverlay(),
          ],
        ),
      ),
    );
  }

  Widget _buildCoverPicker() {
    return RoomInfoSection(
      title: 'غلاف الروم',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.md),
            child: AspectRatio(
              aspectRatio: 16 / 8,
              child: Image.asset(_selectedCover, fit: BoxFit.cover),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          SizedBox(
            height: 60,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: kRoomCoverOptions.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final cover = kRoomCoverOptions[i];
                final selected = cover == _selectedCover;
                return GestureDetector(
                  onTap: () => setState(() => _selectedCover = cover),
                  child: Container(
                    width: 60,
                    height: 60,
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(AppRadius.sm),
                      border: Border.all(color: selected ? AppColors.primary : Colors.transparent, width: 2.5),
                    ),
                    child: Image.asset(cover, fit: BoxFit.cover),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOverlay() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.35),
        child: Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: _step == _CreateStep.submitting
                ? Container(
                    key: const ValueKey('loading'),
                    padding: const EdgeInsets.all(AppSpacing.xl),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg)),
                    child: const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 32,
                          height: 32,
                          child: CircularProgressIndicator(strokeWidth: 3, color: AppColors.primary),
                        ),
                        SizedBox(height: AppSpacing.md),
                        Text('جارٍ إنشاء الروم...', style: AppTextStyles.bodyBold),
                      ],
                    ),
                  )
                : Container(
                    key: const ValueKey('success'),
                    padding: const EdgeInsets.all(AppSpacing.xl),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg)),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: const BoxDecoration(color: AppColors.success, shape: BoxShape.circle),
                          child: const Icon(Icons.check, color: Colors.white, size: 30),
                        ),
                        const SizedBox(height: AppSpacing.md),
                        const Text('تم إنشاء الروم بنجاح 🎉', style: AppTextStyles.bodyBold),
                        const SizedBox(height: 4),
                        Text('#$_roomCode', style: AppTextStyles.caption),
                      ],
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
