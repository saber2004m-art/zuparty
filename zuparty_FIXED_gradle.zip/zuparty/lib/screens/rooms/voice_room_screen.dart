import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData;
import '../../data/models.dart';
import '../../l10n/app_strings.dart';
import '../../data/mock_data.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../routing/app_page_route.dart';
import 'room_shared_widgets.dart';
import 'room_settings_screen.dart';
import 'room_ranking_screen.dart';

/// ============================================================
/// Zuparty — Phase 4 Part 1/3 + Part 2/3: Voice Room UI (احترافي)
/// ------------------------------------------------------------
/// UI/Local State + Mock Data فقط. لا Backend / لا API / لا صوت حقيقي.
/// كل شيء مبني فوق Design System الموجود (AppColors/AppSpacing/...)
/// وفوق الموديلات الموجودة (RoomModel / SeatModel / UserModel).
///
/// تعاقد التنقّل (باش ما نكسروش الشغل الموجود فـ main.dart._openRoom):
///   - زر الرجوع فالأعلى  -> Navigator.pop(context, 'minimize')
///   - "خروج نهائي" من قائمة "المزيد" -> Navigator.pop(context, 'exit')
///
/// Phase 4 — Part 2/3 (Interactions): دردشة الروم، الهدايا، الدعوة،
/// المشاركة، وتفاعلات الأعضاء (متابعة/كتم/طرد/حظر/إبلاغ). كل هادشي
/// Local State + Mock Data فقط — بلا Backend/Server/API/Firebase/Database.
/// ============================================================

/// رصيد Coins ابتدائي محلي (Mock) لصفحة الروم — بدل ربط مباشر بـ AppState
/// (main.dart) باش نتفادو أي دورة استيراد بين الملفين.
const int kVoiceRoomMockStartingCoins = 1280;

enum _RoomLoadState { loading, loaded }

/// حالة إغلاق الروم عند الضغط على "الخروج نهائيًا" — Overlay خفيف قبل pop فعلي
enum _RoomExitState { none, exiting }

class VoiceRoomScreen extends StatefulWidget {
  final RoomModel room;

  /// Callback اختياري لفتح بروفيل عضو (main.dart كيزوّدو باش يفتح ProfileScreen
  /// الحقيقي؛ إذا ماتزودش، كنعرضو Feedback محلي بدل ما نكسرو الشغل).
  final void Function(UserModel user)? onOpenProfile;

  const VoiceRoomScreen({super.key, required this.room, this.onOpenProfile});

  @override
  State<VoiceRoomScreen> createState() => _VoiceRoomScreenState();
}

class _VoiceRoomScreenState extends State<VoiceRoomScreen> {
  _RoomLoadState _state = _RoomLoadState.loading;

  late SeatModel ownerSeat;
  late List<SeatModel> otherSeats;
  late List<RoomMemberInfo> _members;
  final List<RoomMemberInfo> _bannedMembers = [];

  bool _selfMicMuted = true;
  bool _speakerOn = true;
  _RoomExitState _exitState = _RoomExitState.none;

  // ---- Phase 4 — Part 2/3: حالة محلية للدردشة/الهدايا/الرصيد ----
  late List<RoomChatMessage> _chatMessages;
  late List<GiftHistoryEntry> _giftHistory;
  int _coinBalance = kVoiceRoomMockStartingCoins;
  int _giftOverlaySeq = 0;
  final Map<int, Widget> _giftOverlays = {};

  @override
  void initState() {
    super.initState();
    _initSeats();
    _members = List<RoomMemberInfo>.from(MockData.voiceRoomMembers);
    _chatMessages = MockData.voiceRoomChatSeed();
    _giftHistory = List<GiftHistoryEntry>.from(MockData.voiceRoomGiftHistory);
    Future.delayed(const Duration(milliseconds: 450), () {
      if (!mounted) return;
      setState(() => _state = _RoomLoadState.loaded);
    });
  }

  void _initSeats() {
    final room = widget.room;
    if (room.ownerSeat != null && room.seatsData != null) {
      // الروم كانت مفتوحة قبل (Minimize) — نرجعو نستعملو نفس الحالة، ما نكرروش البيانات.
      ownerSeat = room.ownerSeat!;
      otherSeats = room.seatsData!;
      return;
    }
    ownerSeat = SeatModel(
      occupantName: room.ownerName ?? 'صاحب الروم',
      occupantImage: room.ownerAvatarPath ?? 'assets/images/profile.png',
      isSpeaking: true,
    );
    final seatCount = (room.micSeats - 1).clamp(0, 30);
    otherSeats = List.generate(seatCount, (_) => SeatModel());
    if (otherSeats.isNotEmpty) {
      otherSeats[0] = SeatModel(
        occupantName: 'ياسمين',
        occupantImage: 'assets/images/profile.png',
        isMuted: false,
      );
    }
    if (otherSeats.length > 2) {
      otherSeats[2] = SeatModel(
        occupantName: 'Sara',
        occupantImage: 'assets/images/profile.png',
        isSpeaking: true,
      );
    }
    if (otherSeats.length > 4) {
      otherSeats[4] = SeatModel(
        occupantName: 'Player_01',
        occupantImage: 'assets/images/profile.png',
        isMuted: true,
      );
    }
    room.ownerSeat = ownerSeat;
    room.seatsData = otherSeats;
  }

  int get _onlineCount => _members.where((m) => m.isOnline).length + 1;

  void _toggleSelfMic() {
    setState(() {
      _selfMicMuted = !_selfMicMuted;
      ownerSeat.isMuted = _selfMicMuted;
      ownerSeat.isSpeaking = !_selfMicMuted;
    });
  }

  void _toggleSpeaker() => setState(() => _speakerOn = !_speakerOn);

  /// فتح بروفيل عضو — كيستعمل الـ callback الحقيقي إذا موجود (مزوّد من main.dart)،
  /// وإلا كيرجع لـ Feedback محلي موحّد (بلا كسر الشغل الحالي).
  void _openProfile(UserModel user) {
    if (widget.onOpenProfile != null) {
      widget.onOpenProfile!(user);
    } else {
      showRoomMockFeedback(context, S.trParams('p2a_profile_open', {'name': user.name}));
    }
  }

  /// إضافة رسالة نصية محلية للدردشة (من التاب سفلي أو من شيت الدردشة)
  void _addChatTextMessage(String text) {
    setState(() {
      _chatMessages.add(RoomChatMessage(
        id: 'local_${DateTime.now().microsecondsSinceEpoch}',
        type: RoomChatMessageType.text,
        sender: const UserModel(id: 'me', name: 'أنت', avatarPath: 'assets/images/profile.png'),
        text: text,
        time: DateTime.now(),
        isMe: true,
      ));
    });
  }

  /// إرسال هدية محليًا: تحقق من الرصيد -> خصم -> سجل -> رسالة دردشة -> أنيميشن
  bool _sendGift({required GiftModel gift, required int quantity, required UserModel receiver}) {
    final totalPrice = gift.price * quantity;
    if (_coinBalance < totalPrice) return false;
    setState(() {
      _coinBalance -= totalPrice;
      _giftHistory.insert(
        0,
        GiftHistoryEntry(
          id: 'gh_${DateTime.now().microsecondsSinceEpoch}',
          sender: const UserModel(id: 'me', name: 'أنت', avatarPath: 'assets/images/profile.png'),
          receiver: receiver,
          gift: gift,
          quantity: quantity,
          time: DateTime.now(),
        ),
      );
      _chatMessages.add(RoomChatMessage(
        id: 'gift_${DateTime.now().microsecondsSinceEpoch}',
        type: RoomChatMessageType.gift,
        sender: const UserModel(id: 'me', name: 'أنت', avatarPath: 'assets/images/profile.png'),
        giftReceiver: receiver,
        gift: gift,
        giftQuantity: quantity,
        time: DateTime.now(),
        isMe: true,
      ));
    });
    _playGiftAnimation(gift);
    return true;
  }

  /// أنيميشن خفيف لطيران الهدية فوق المقاعد لمدة قصيرة ثم يختفي تلقائيًا
  void _playGiftAnimation(GiftModel gift) {
    final id = _giftOverlaySeq++;
    setState(() {
      _giftOverlays[id] = _GiftFlyAnimation(
        key: ValueKey('gift_fly_$id'),
        gift: gift,
        onDone: () {
          if (!mounted) return;
          setState(() => _giftOverlays.remove(id));
        },
      );
    });
  }

  void _onSeatTap(SeatModel seat, {required bool isOwnerSeat}) {
    if (seat.occupantName == null) {
      showRoomMockFeedback(context, S.tr('p2a_c29e1d55'));
      setState(() => seat.occupantName = 'أنت');
      return;
    }
    _showSeatSheet(seat, isOwnerSeat: isOwnerSeat);
  }

  void _showSeatSheet(SeatModel seat, {required bool isOwnerSeat}) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSpacing.lg, horizontal: AppSpacing.lg),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                RoomAvatarCircle(imagePath: seat.occupantImage, fallbackText: seat.occupantName ?? '?', size: 56),
                const SizedBox(height: AppSpacing.sm),
                Text(seat.occupantName ?? '', style: AppTextStyles.h3),
                const SizedBox(height: AppSpacing.lg),
                _SheetActionTile(
                  icon: seat.isMuted ? Icons.mic_off_rounded : Icons.mic_rounded,
                  label: seat.isMuted ? S.tr('p2a_e352a5f4') : S.tr('p2a_76a1d435'),
                  onTap: () {
                    Navigator.pop(ctx);
                    setState(() => seat.isMuted = !seat.isMuted);
                  },
                ),
                if (isOwnerSeat)
                  _SheetActionTile(
                    icon: Icons.logout_rounded,
                    label: S.tr('p2a_e58ff8e9'),
                    danger: true,
                    onTap: () {
                      Navigator.pop(ctx);
                      setState(() => seat.occupantName = null);
                    },
                  )
                else
                  _SheetActionTile(
                    icon: Icons.person_remove_alt_1_rounded,
                    label: S.tr('p2a_be5c17f3'),
                    danger: true,
                    onTap: () {
                      Navigator.pop(ctx);
                      setState(() {
                        seat.occupantName = null;
                        seat.occupantImage = null;
                        seat.isMuted = false;
                        seat.isSpeaking = false;
                      });
                    },
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _openMembersSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _MembersSheet(
        members: _members,
        bannedMembers: _bannedMembers,
        onOpenProfile: _openProfile,
        onChanged: () => setState(() {}),
      ),
    );
  }

  void _openChatSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _RoomChatSheet(
        roomName: widget.room.name,
        messages: _chatMessages,
        onSend: _addChatTextMessage,
      ),
    );
  }

  void _openGiftsSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _GiftsSheet(
        coinBalance: _coinBalance,
        giftHistory: _giftHistory,
        members: _members,
        defaultReceiver: RoomMemberInfo(user: UserModel(id: widget.room.id ?? 'owner', name: widget.room.ownerName ?? 'صاحب الروم', avatarPath: widget.room.ownerAvatarPath), role: RoomRole.owner),
        onSend: _sendGift,
      ),
    );
  }

  void _openInviteSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _InviteMembersSheet(),
    );
  }

  void _shareRoom() {
    final roomId = widget.room.roomCode ?? (widget.room.id ?? '000000');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _ShareRoomSheet(roomName: widget.room.name, roomId: roomId),
    );
  }

  void _openMoreSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: AppSpacing.sm),
              Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
              const SizedBox(height: AppSpacing.md),
              _SheetActionTile(
                icon: Icons.settings_outlined,
                label: S.tr('p2a_68bd04e7'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await Navigator.push(
                    context,
                    appPageRoute(
                      builder: (_) => VoiceRoomSettingsScreen(
                        room: widget.room,
                        members: _members,
                        bannedMembers: _bannedMembers,
                        onChanged: () => setState(() {}),
                      ),
                    ),
                  );
                  if (mounted) setState(() {});
                },
              ),
              _SheetActionTile(
                icon: Icons.emoji_events_outlined,
                label: S.tr('p2a_db246bbf'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.push(
                    context,
                    appPageRoute(builder: (_) => RoomRankingScreen(roomName: widget.room.name)),
                  );
                },
              ),
              _SheetActionTile(
                icon: Icons.campaign_outlined,
                label: S.tr('p2a_9127682c'),
                onTap: () {
                  Navigator.pop(ctx);
                  _openAnnouncementEditor();
                },
              ),
              _SheetActionTile(
                icon: widget.room.isRoomLocked ? Icons.lock_open_rounded : Icons.lock_outline_rounded,
                label: widget.room.isRoomLocked ? S.tr('p2a_adf4e427') : S.tr('p2a_e381367e'),
                onTap: () {
                  Navigator.pop(ctx);
                  setState(() => widget.room.isRoomLocked = !widget.room.isRoomLocked);
                },
              ),
              _SheetActionTile(
                icon: Icons.remove_circle_outline_rounded,
                label: S.tr('p2a_9cb97848'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pop(context, 'minimize');
                },
              ),
              _SheetActionTile(
                icon: Icons.exit_to_app_rounded,
                label: S.tr('p2a_a865b8cd'),
                danger: true,
                onTap: () async {
                  Navigator.pop(ctx);
                  setState(() => _exitState = _RoomExitState.exiting);
                  await Future.delayed(const Duration(milliseconds: 420));
                  if (!context.mounted) return;
                  Navigator.pop(context, 'exit');
                },
              ),
              const SizedBox(height: AppSpacing.sm),
            ],
          ),
        );
      },
    );
  }

  /// محرّر إعلان الروم — Local State فقط، بحالة فارغة إذا مفعّش إعلان
  void _openAnnouncementEditor() {
    final controller = TextEditingController(text: widget.room.announcement);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
                  const SizedBox(height: AppSpacing.md),
                  Text(S.tr('p2a_9127682c'), style: AppTextStyles.h3),
                  const SizedBox(height: AppSpacing.md),
                  TextField(
                    controller: controller,
                    maxLines: 3,
                    maxLength: 150,
                    decoration: InputDecoration(hintText: S.tr('p2a_609e2cab')),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Row(
                    children: [
                      if (widget.room.announcement.isNotEmpty)
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              Navigator.pop(ctx);
                              setState(() => widget.room.announcement = '');
                              showRoomMockFeedback(context, S.tr('p2a_f0c7de90'));
                            },
                            child: Text(S.tr('p2a_55dda407')),
                          ),
                        ),
                      if (widget.room.announcement.isNotEmpty) const SizedBox(width: AppSpacing.sm),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(ctx);
                            setState(() => widget.room.announcement = controller.text.trim());
                            showRoomMockFeedback(context, S.tr('p2a_dc8b1807'));
                          },
                          child: Text(S.tr('save')),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        Navigator.pop(context, 'minimize');
      },
      child: Scaffold(
        backgroundColor: AppColors.surfaceDark,
        body: Stack(
          fit: StackFit.expand,
          children: [
            _RoomBackground(imagePath: widget.room.imagePath),
            SafeArea(
              child: _state == _RoomLoadState.loading
                  ? AppLoading(message: S.tr('p2a_1b25526f'))
                  : Column(
                      children: [
                        _VoiceRoomHeader(
                          room: widget.room,
                          onlineCount: _onlineCount,
                          onBack: () => Navigator.pop(context, 'minimize'),
                          onShare: _shareRoom,
                          onMore: _openMoreSheet,
                        ),
                        _AnnouncementBanner(
                          announcement: widget.room.announcement,
                          onTap: _openAnnouncementEditor,
                        ),
                        Expanded(
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.md),
                            child: Column(
                              children: [
                                _VoiceSeatsGrid(
                                  ownerSeat: ownerSeat,
                                  otherSeats: otherSeats,
                                  onOwnerTap: () => _onSeatTap(ownerSeat, isOwnerSeat: true),
                                  onSeatTap: (s) => _onSeatTap(s, isOwnerSeat: false),
                                ),
                                const SizedBox(height: AppSpacing.lg),
                                _RoomUsersPreview(members: _members, onSeeAll: _openMembersSheet),
                              ],
                            ),
                          ),
                        ),
                        _BottomControlBar(
                          micMuted: _selfMicMuted,
                          speakerOn: _speakerOn,
                          onMic: _toggleSelfMic,
                          onSpeaker: _toggleSpeaker,
                          onChat: _openChatSheet,
                          onGifts: _openGiftsSheet,
                          onMembers: _openMembersSheet,
                          onInvite: _openInviteSheet,
                          onShare: _shareRoom,
                          onMore: _openMoreSheet,
                        ),
                      ],
                    ),
            ),
            // ---- أنيميشن الهدايا (خفيف، فوق كل شيء، بلا استقبال ضغطات) ----
            IgnorePointer(child: Stack(children: _giftOverlays.values.toList())),
            // ---- حالة "جارٍ الخروج..." (Exiting) — Overlay خفيف قبل pop فعلي ----
            if (_exitState == _RoomExitState.exiting) const AppExitingOverlay(),
          ],
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// خلفية الروم: صورة غلاف + Gradient overlay باش يبقى النص واضح
/// ------------------------------------------------------------
class _RoomBackground extends StatelessWidget {
  final String? imagePath;
  const _RoomBackground({this.imagePath});

  @override
  Widget build(BuildContext context) {
    final path = imagePath ?? 'assets/images/room_bg_official.webp';
    return Stack(
      fit: StackFit.expand,
      children: [
        Image.asset(
          path,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(color: AppColors.surfaceDark),
        ),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.55),
                Colors.black.withOpacity(0.25),
                Colors.black.withOpacity(0.75),
              ],
              stops: const [0, 0.45, 1],
            ),
          ),
        ),
      ],
    );
  }
}

/// ------------------------------------------------------------
/// 2. Voice Room Header
/// ------------------------------------------------------------
class _VoiceRoomHeader extends StatelessWidget {
  final RoomModel room;
  final int onlineCount;
  final VoidCallback onBack;
  final VoidCallback onShare;
  final VoidCallback onMore;

  const _VoiceRoomHeader({
    required this.room,
    required this.onlineCount,
    required this.onBack,
    required this.onShare,
    required this.onMore,
  });

  @override
  Widget build(BuildContext context) {
    final roomId = room.roomCode ?? (room.id ?? '000000');
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.md, AppSpacing.sm, AppSpacing.md, AppSpacing.sm),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _HeaderIconButton(icon: Icons.arrow_back_ios_new_rounded, onTap: onBack),
              const Spacer(),
              _HeaderIconButton(icon: Icons.ios_share_rounded, onTap: onShare),
              const SizedBox(width: AppSpacing.sm),
              _HeaderIconButton(icon: Icons.more_horiz_rounded, onTap: onMore),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Row(
            children: [
              RoomAvatarCircle(
                imagePath: room.ownerAvatarPath ?? 'assets/images/profile.png',
                fallbackText: room.ownerName ?? room.name,
                size: 44,
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      room.name,
                      style: AppTextStyles.h3.copyWith(color: Colors.white),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Wrap(
                      spacing: AppSpacing.sm,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        _RoomIdChip(roomId: roomId),
                        Text(
                          room.ownerName ?? 'صاحب الروم',
                          style: AppTextStyles.caption.copyWith(color: Colors.white70),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (room.category != null)
                          RoomTagChip(
                            label: room.category!,
                            background: Colors.white.withOpacity(0.15),
                            foreground: Colors.white,
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.headset_mic_rounded, size: 14, color: Colors.white70),
                      const SizedBox(width: 4),
                      Text('$onlineCount', style: AppTextStyles.caption.copyWith(color: Colors.white, fontWeight: FontWeight.w700)),
                    ],
                  ),
                  const SizedBox(height: 2),
                  if (room.isRoomLocked)
                    const Icon(Icons.lock_outline_rounded, size: 14, color: Colors.white70),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// ------------------------------------------------------------
/// شريط إعلان الروم — يظهر إعلان الروم الحالي، أو حالة فارغة
/// بسيطة إذا مفعّش إعلان بعد. الضغط عليه كيفتح محرّر الإعلان.
/// ------------------------------------------------------------
class _AnnouncementBanner extends StatelessWidget {
  final String announcement;
  final VoidCallback onTap;
  const _AnnouncementBanner({required this.announcement, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final hasAnnouncement = announcement.trim().isNotEmpty;
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.md, 0, AppSpacing.md, AppSpacing.sm),
      child: Material(
        color: Colors.white.withOpacity(hasAnnouncement ? 0.14 : 0.08),
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadius.md),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: 9),
            child: Row(
              children: [
                Icon(Icons.campaign_rounded, size: 16, color: hasAnnouncement ? Colors.white : Colors.white54),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    hasAnnouncement ? announcement : S.tr('p2a_f32e8b76'),
                    style: AppTextStyles.caption.copyWith(
                      color: hasAnnouncement ? Colors.white : Colors.white54,
                      fontWeight: hasAnnouncement ? FontWeight.w600 : FontWeight.w400,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Icon(Icons.chevron_left_rounded, size: 16, color: Colors.white.withOpacity(0.6)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RoomIdChip extends StatelessWidget {
  final String roomId;
  const _RoomIdChip({required this.roomId});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Text(
        'ID: $roomId',
        style: AppTextStyles.caption.copyWith(color: Colors.white70, fontSize: 10.5),
      ),
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _HeaderIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withOpacity(0.28),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 38,
          height: 38,
          child: Icon(icon, color: Colors.white, size: 18),
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// 4. Voice Seats — Grid احترافي responsive
/// ------------------------------------------------------------
class _VoiceSeatsGrid extends StatelessWidget {
  final SeatModel ownerSeat;
  final List<SeatModel> otherSeats;
  final VoidCallback onOwnerTap;
  final ValueChanged<SeatModel> onSeatTap;

  const _VoiceSeatsGrid({
    required this.ownerSeat,
    required this.otherSeats,
    required this.onOwnerTap,
    required this.onSeatTap,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final columns = width < 340 ? 4 : (width < 500 ? 5 : 6);
        final seatSize = ((width - (columns - 1) * AppSpacing.md) / columns).clamp(56.0, 84.0);

        return Column(
          children: [
            // مقعد صاحب الروم فالوسط فوق
            _VoiceSeatTile(
              seat: ownerSeat,
              size: seatSize + 8,
              role: RoomRole.owner,
              onTap: onOwnerTap,
            ),
            const SizedBox(height: AppSpacing.lg),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: AppSpacing.md,
              runSpacing: AppSpacing.md,
              children: [
                for (int i = 0; i < otherSeats.length; i++)
                  SizedBox(
                    width: seatSize,
                    child: _VoiceSeatTile(
                      seat: otherSeats[i],
                      size: seatSize,
                      role: i < 2 ? RoomRole.admin : (i < 5 ? RoomRole.speaker : null),
                      onTap: () => onSeatTap(otherSeats[i]),
                    ),
                  ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _VoiceSeatTile extends StatefulWidget {
  final SeatModel seat;
  final double size;
  final RoomRole? role;
  final VoidCallback onTap;

  const _VoiceSeatTile({required this.seat, required this.size, required this.onTap, this.role});

  @override
  State<_VoiceSeatTile> createState() => _VoiceSeatTileState();
}

class _VoiceSeatTileState extends State<_VoiceSeatTile> {
  double _scale = 1;

  @override
  Widget build(BuildContext context) {
    final seat = widget.seat;
    final isEmpty = seat.occupantName == null;
    final avatarSize = widget.size;

    return GestureDetector(
      onTapDown: (_) => setState(() => _scale = 0.92),
      onTapCancel: () => setState(() => _scale = 1),
      onTapUp: (_) => setState(() => _scale = 1),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 110),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: avatarSize,
              height: avatarSize,
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.center,
                children: [
                  if (seat.isSpeaking) _SpeakingRing(size: avatarSize + 10),
                  if (isEmpty)
                    Container(
                      width: avatarSize * 0.78,
                      height: avatarSize * 0.78,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.08),
                        border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.4, style: BorderStyle.solid),
                      ),
                      child: Icon(Icons.add_rounded, color: Colors.white.withOpacity(0.7), size: avatarSize * 0.32),
                    )
                  else
                    RoomAvatarCircle(
                      imagePath: seat.occupantImage,
                      fallbackText: seat.occupantName!,
                      size: avatarSize * 0.78,
                      borderColor: seat.isSpeaking ? AppColors.primary : Colors.white24,
                    ),
                  if (!isEmpty)
                    Positioned(
                      bottom: -2,
                      right: -2,
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 180),
                        child: Container(
                          key: ValueKey(seat.isMuted),
                          width: avatarSize * 0.3,
                          height: avatarSize * 0.3,
                          decoration: BoxDecoration(
                            color: seat.isMuted ? AppColors.grey600 : AppColors.success,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 1.2),
                          ),
                          child: Icon(
                            seat.isMuted ? Icons.mic_off_rounded : Icons.mic_rounded,
                            color: Colors.white,
                            size: avatarSize * 0.16,
                          ),
                        ),
                      ),
                    ),
                  if (widget.role != null && widget.role != RoomRole.member)
                    Positioned(
                      top: -4,
                      left: -6,
                      child: _RoleBadge(role: widget.role!),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 4),
            Text(
              isEmpty ? S.tr('p2a_31860c5a') : seat.occupantName!,
              style: AppTextStyles.caption.copyWith(
                color: isEmpty ? Colors.white54 : Colors.white,
                fontWeight: FontWeight.w600,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

/// حلقة متحركة (Pulse) حول المقعد وقت التحدث — Animation خفيفة فقط
class _SpeakingRing extends StatefulWidget {
  final double size;
  const _SpeakingRing({required this.size});

  @override
  State<_SpeakingRing> createState() => _SpeakingRingState();
}

class _SpeakingRingState extends State<_SpeakingRing> with SingleTickerProviderStateMixin {
  late final AnimationController _controller =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = _controller.value;
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: AppColors.primary.withOpacity(0.35 + 0.35 * t),
              width: 2 + t,
            ),
          ),
        );
      },
    );
  }
}

class _RoleBadge extends StatelessWidget {
  final RoomRole role;
  const _RoleBadge({required this.role});

  @override
  Widget build(BuildContext context) {
    IconData icon;
    Color color;
    switch (role) {
      case RoomRole.owner:
        icon = Icons.workspace_premium_rounded;
        color = const Color(0xFFFFC107);
        break;
      case RoomRole.admin:
        icon = Icons.shield_rounded;
        color = AppColors.info;
        break;
      case RoomRole.speaker:
        icon = Icons.campaign_rounded;
        color = AppColors.primary;
        break;
      case RoomRole.member:
        icon = Icons.person_rounded;
        color = AppColors.grey500;
        break;
    }
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1)),
      child: Icon(icon, size: 10, color: Colors.white),
    );
  }
}

/// ------------------------------------------------------------
/// 5. Room Users — معاينة سريعة فوق قسم المقاعد (Avatars + "See all")
/// ------------------------------------------------------------
class _RoomUsersPreview extends StatelessWidget {
  final List<RoomMemberInfo> members;
  final VoidCallback onSeeAll;

  const _RoomUsersPreview({required this.members, required this.onSeeAll});

  @override
  Widget build(BuildContext context) {
    final preview = members.take(8).toList();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(S.tr('p2a_14ccba9c'), style: AppTextStyles.bodyBold.copyWith(color: Colors.white)),
              const SizedBox(width: 6),
              Text('(${members.length})', style: AppTextStyles.caption.copyWith(color: Colors.white54)),
              const Spacer(),
              GestureDetector(
                onTap: onSeeAll,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(S.tr('see_all'), style: AppTextStyles.caption.copyWith(color: AppColors.primaryLight, fontWeight: FontWeight.w700)),
                    const Icon(Icons.chevron_left_rounded, size: 16, color: Colors.white70),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          SizedBox(
            height: 56,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: preview.length,
              separatorBuilder: (_, __) => const SizedBox(width: AppSpacing.sm),
              itemBuilder: (_, i) {
                final m = preview[i];
                return Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Opacity(
                      opacity: m.isOnline ? 1 : 0.4,
                      child: RoomAvatarCircle(imagePath: m.user.avatarPath, fallbackText: m.user.name, size: 44),
                    ),
                    if (m.isOnline)
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: AppColors.success,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 1.5),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// ------------------------------------------------------------
/// 8. Members Bottom Sheet — بحث محلي + قائمة أعضاء + حالة فارغة
/// ------------------------------------------------------------
class _MembersSheet extends StatefulWidget {
  final List<RoomMemberInfo> members;
  final List<RoomMemberInfo> bannedMembers;
  final void Function(UserModel user)? onOpenProfile;
  final VoidCallback? onChanged;
  const _MembersSheet({required this.members, required this.bannedMembers, this.onOpenProfile, this.onChanged});

  @override
  State<_MembersSheet> createState() => _MembersSheetState();
}

class _MembersSheetState extends State<_MembersSheet> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<RoomMemberInfo> get _filtered {
    if (_query.trim().isEmpty) return widget.members;
    final q = _query.trim().toLowerCase();
    return widget.members.where((m) => m.user.name.toLowerCase().contains(q)).toList();
  }

  void _removeMember(RoomMemberInfo member) {
    setState(() => widget.members.remove(member));
    widget.onChanged?.call();
  }

  void _banMember(RoomMemberInfo member) {
    setState(() {
      widget.members.remove(member);
      widget.bannedMembers.add(member);
    });
    widget.onChanged?.call();
  }

  void _notifyChanged() {
    setState(() {});
    widget.onChanged?.call();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    return DraggableScrollableSheet(
      initialChildSize: 0.68,
      minChildSize: 0.4,
      maxChildSize: 0.92,
      expand: false,
      builder: (context, scrollController) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                const SizedBox(height: 10),
                Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
                Padding(
                  padding: const EdgeInsets.all(AppSpacing.lg),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(S.trParams('p2a_members_count', {'count': widget.members.length.toString()}), style: AppTextStyles.h3),
                      const SizedBox(height: AppSpacing.md),
                      TextField(
                        controller: _searchController,
                        onChanged: (v) => setState(() => _query = v),
                        decoration: InputDecoration(
                          hintText: S.tr('p2a_8a6c16e7'),
                          prefixIcon: Icon(Icons.search_rounded, size: 20),
                          isDense: true,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: filtered.isEmpty
                      ? AppEmptyState(
                          icon: Icons.person_search_rounded,
                          title: S.tr('p2a_035110e9'),
                          subtitle: S.tr('p2a_3718b1d2'),
                        )
                      : ListView.separated(
                          controller: scrollController,
                          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                          itemCount: filtered.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (_, i) => _MemberRow(
                            member: filtered[i],
                            onOpenProfile: widget.onOpenProfile,
                            onChanged: _notifyChanged,
                            onRemove: () => _removeMember(filtered[i]),
                            onBan: () => _banMember(filtered[i]),
                          ),
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MemberRow extends StatelessWidget {
  final RoomMemberInfo member;
  final void Function(UserModel user)? onOpenProfile;
  final VoidCallback? onChanged;
  final VoidCallback? onRemove;
  final VoidCallback? onBan;
  const _MemberRow({required this.member, this.onOpenProfile, this.onChanged, this.onRemove, this.onBan});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      onTap: () {
        // الضغط على الصف كيفتح بروفيل العضو (Phase 4 — Part 1/3، طلب 8 + Part 2/3، طلب 5).
        if (onOpenProfile != null) {
          onOpenProfile!(member.user);
        } else {
          showRoomMockFeedback(context, S.trParams('p2a_profile_open', {'name': member.user.name}));
        }
      },
      leading: Stack(
        clipBehavior: Clip.none,
        children: [
          Opacity(
            opacity: member.isOnline ? 1 : 0.45,
            child: RoomAvatarCircle(imagePath: member.user.avatarPath, fallbackText: member.user.name, size: 44, borderColor: AppColors.border),
          ),
          if (member.isOnline)
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 11,
                height: 11,
                decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1.5)),
              ),
            ),
        ],
      ),
      title: Row(
        children: [
          Flexible(child: Text(member.user.name, style: AppTextStyles.bodyBold, maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (member.role != RoomRole.member) ...[
            const SizedBox(width: 6),
            RoomTagChip(
              label: member.role.label,
              background: member.role == RoomRole.owner
                  ? const Color(0xFFFFF3CD)
                  : (member.role == RoomRole.admin ? AppColors.primaryLight : AppColors.surface),
              foreground: member.role == RoomRole.owner ? const Color(0xFF8A6D00) : AppColors.textPrimary,
            ),
          ],
        ],
      ),
      subtitle: Text(
        [
          member.isOnline ? S.tr('p2a_905f6d89') : S.tr('p2a_38be7336'),
          if (member.isFollowing) S.tr('p2a_dedece62'),
          if (member.isModMuted) S.tr('p2a_ac155df0'),
        ].join(' • '),
        style: AppTextStyles.caption,
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            member.isMicMuted ? Icons.mic_off_rounded : Icons.mic_rounded,
            size: 18,
            color: member.isMicMuted ? AppColors.grey400 : AppColors.success,
          ),
          const SizedBox(width: 2),
          IconButton(
            icon: const Icon(Icons.more_vert_rounded, size: 20, color: AppColors.textSecondary),
            onPressed: () => _showMemberActionsSheet(context, member, onChanged: onChanged, onRemove: onRemove, onBan: onBan),
          ),
        ],
      ),
    );
  }
}

/// ------------------------------------------------------------
/// شيت إجراءات العضو: متابعة / كتم / طرد / حظر / إبلاغ (Local فقط)
/// كل إجراء "خطير" (طرد/حظر) كيمر عبر Dialog تأكيد قبل التنفيذ.
/// ------------------------------------------------------------
void _showMemberActionsSheet(
  BuildContext context,
  RoomMemberInfo member, {
  VoidCallback? onChanged,
  VoidCallback? onRemove,
  VoidCallback? onBan,
}) {
  final isOwner = member.role == RoomRole.owner;
  showModalBottomSheet(
    context: context,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (ctx) {
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.lg, horizontal: AppSpacing.lg),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
              const SizedBox(height: AppSpacing.md),
              RoomAvatarCircle(imagePath: member.user.avatarPath, fallbackText: member.user.name, size: 52, borderColor: AppColors.border),
              const SizedBox(height: AppSpacing.sm),
              Text(member.user.name, style: AppTextStyles.h3),
              const SizedBox(height: AppSpacing.md),
              _SheetActionTile(
                icon: member.isFollowing ? Icons.person_remove_rounded : Icons.person_add_alt_1_rounded,
                label: member.isFollowing ? S.tr('p2a_9dbbe001') : S.tr('p2a_650a37e7'),
                onTap: () {
                  Navigator.pop(ctx);
                  member.isFollowing = !member.isFollowing;
                  onChanged?.call();
                },
              ),
              if (!isOwner) ...[
                _SheetActionTile(
                  icon: member.isModMuted ? Icons.mic_rounded : Icons.mic_off_rounded,
                  label: member.isModMuted ? S.tr('p2a_ff9a26ad') : S.tr('p2a_58a4cfa5'),
                  onTap: () {
                    Navigator.pop(ctx);
                    member.isModMuted = !member.isModMuted;
                    onChanged?.call();
                  },
                ),
                _SheetActionTile(
                  icon: Icons.person_remove_alt_1_rounded,
                  label: S.tr('p2a_86c15514'),
                  danger: true,
                  onTap: () async {
                    Navigator.pop(ctx);
                    if (!context.mounted) return;
                    final confirmed = await showRoomConfirmDialog(
                      context,
                      title: S.trParams('p2a_kick_confirm', {'name': member.user.name}),
                      message: S.tr('p2a_7f69a132'),
                      confirmLabel: S.tr('p2a_de25be6a'),
                      danger: true,
                    );
                    if (confirmed == true) {
                      onRemove?.call();
                      if (context.mounted) showRoomMockFeedback(context, S.trParams('p2a_kick_done', {'name': member.user.name}));
                    }
                  },
                ),
                _SheetActionTile(
                  icon: Icons.block_rounded,
                  label: S.tr('p2a_7e542cf5'),
                  danger: true,
                  onTap: () async {
                    Navigator.pop(ctx);
                    if (!context.mounted) return;
                    final confirmed = await showRoomConfirmDialog(
                      context,
                      title: S.trParams('p2a_ban_confirm', {'name': member.user.name}),
                      message: S.tr('p2a_67154e5d'),
                      confirmLabel: S.tr('p2a_7fe2d6c4'),
                      danger: true,
                    );
                    if (confirmed == true) {
                      onBan?.call();
                      if (context.mounted) showRoomMockFeedback(context, S.trParams('p2a_ban_done', {'name': member.user.name}));
                    }
                  },
                ),
              ],
              _SheetActionTile(
                icon: Icons.flag_outlined,
                label: S.tr('p2a_33968c7d'),
                danger: true,
                onTap: () async {
                  Navigator.pop(ctx);
                  if (!context.mounted) return;
                  final confirmed = await showRoomConfirmDialog(
                    context,
                    title: S.trParams('p2a_report_confirm', {'name': member.user.name}),
                    message: S.tr('p2a_a23fca22'),
                    confirmLabel: S.tr('p2a_1aeed439'),
                    danger: true,
                  );
                  if (confirmed == true && context.mounted) {
                    showRoomMockFeedback(context, S.tr('p2a_48883a18'));
                  }
                },
              ),
            ],
          ),
        ),
      );
    },
  );
}

/// Dialog تأكيد عام (يُستعمل فطرد/حظر/إبلاغ) — Mock فقط
Future<bool?> showRoomConfirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmLabel,
  bool danger = false,
}) {
  return showDialog<bool>(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.lg)),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title, style: AppTextStyles.bodyBold, textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(message, style: AppTextStyles.caption, textAlign: TextAlign.center),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: Text(S.tr('cancel')),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: ElevatedButton(
                    style: danger
                        ? ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white)
                        : null,
                    onPressed: () => Navigator.pop(ctx, true),
                    child: Text(confirmLabel),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

/// ------------------------------------------------------------
/// 6. Bottom Controls
/// ------------------------------------------------------------
class _BottomControlBar extends StatelessWidget {
  final bool micMuted;
  final bool speakerOn;
  final VoidCallback onMic;
  final VoidCallback onSpeaker;
  final VoidCallback onChat;
  final VoidCallback onGifts;
  final VoidCallback onMembers;
  final VoidCallback onInvite;
  final VoidCallback onShare;
  final VoidCallback onMore;

  const _BottomControlBar({
    required this.micMuted,
    required this.speakerOn,
    required this.onMic,
    required this.onSpeaker,
    required this.onChat,
    required this.onGifts,
    required this.onMembers,
    required this.onInvite,
    required this.onShare,
    required this.onMore,
  });

  @override
  Widget build(BuildContext context) {
    final buttons = [
      _ControlButton(
        icon: micMuted ? Icons.mic_off_rounded : Icons.mic_rounded,
        active: !micMuted,
        onTap: onMic,
        tooltip: micMuted ? S.tr('p2a_ac28b436') : S.tr('p2a_2a8c486a'),
      ),
      _ControlButton(
        icon: speakerOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
        active: speakerOn,
        onTap: onSpeaker,
        tooltip: S.tr('p2a_050784a6'),
      ),
      _ControlButton(icon: Icons.chat_bubble_rounded, onTap: onChat, tooltip: S.tr('p2a_4447dd0d')),
      _ControlButton(icon: Icons.card_giftcard_rounded, onTap: onGifts, tooltip: S.tr('p2a_c7b318a4')),
      _ControlButton(icon: Icons.people_alt_rounded, onTap: onMembers, tooltip: S.tr('p2a_bb89a35f')),
      _ControlButton(icon: Icons.person_add_alt_1_rounded, onTap: onInvite, tooltip: S.tr('invite')),
      _ControlButton(icon: Icons.ios_share_rounded, onTap: onShare, tooltip: S.tr('share')),
      _ControlButton(icon: Icons.more_horiz_rounded, onTap: onMore, tooltip: S.tr('p2a_407bdba7')),
    ];

    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(AppSpacing.md, 0, AppSpacing.md, AppSpacing.sm),
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.sm),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.38),
          borderRadius: BorderRadius.circular(AppRadius.xl),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            // مقاس ديناميكي باش الأزرار الثمانية ما يفيضوش فالشاشات الضيقة
            final buttonSize = (constraints.maxWidth / buttons.length).clamp(30.0, 42.0);
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [for (final b in buttons) b.copyWith(size: buttonSize)],
            );
          },
        ),
      ),
    );
  }
}

class _ControlButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool active;
  final String tooltip;
  final double size;

  const _ControlButton({required this.icon, required this.onTap, required this.tooltip, this.active = false, this.size = 42});

  _ControlButton copyWith({double? size}) => _ControlButton(
        icon: icon,
        onTap: onTap,
        tooltip: tooltip,
        active: active,
        size: size ?? this.size,
      );

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: active ? AppColors.primary : Colors.white.withOpacity(0.1),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(
            width: size,
            height: size,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 150),
              child: Icon(icon, key: ValueKey(icon), color: Colors.white, size: size * 0.46),
            ),
          ),
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// Chat Panel محلي داخل الروم (Local فقط — بلا Real-time)
/// (Phase 4 — Part 2/3): يدعم رسائل نصية + نظام + انضمام + هدية،
/// أفاتار + اسم + وقت، شريط إيموجي سريع، حالة فارغة، تخطيط آمن مع الكيبورد.
/// ------------------------------------------------------------
const List<String> kQuickEmojis = ['😂', '❤️', '🔥', '👏', '😍', '👍', '🎉', '😮'];

class _RoomChatSheet extends StatefulWidget {
  final String roomName;
  final List<RoomChatMessage> messages;
  final ValueChanged<String> onSend;
  const _RoomChatSheet({required this.roomName, required this.messages, required this.onSend});

  @override
  State<_RoomChatSheet> createState() => _RoomChatSheetState();
}

class _RoomChatSheetState extends State<_RoomChatSheet> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _listController = ScrollController();
  bool _showEmojiRow = false;

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() => widget.onSend(text));
    _controller.clear();
    _scrollToBottom();
  }

  void _insertEmoji(String emoji) {
    _controller.text += emoji;
    _controller.selection = TextSelection.fromPosition(TextPosition(offset: _controller.text.length));
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_listController.hasClients) return;
      _listController.animateTo(
        _listController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: DraggableScrollableSheet(
        initialChildSize: 0.62,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) {
          return ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: Container(
              color: Colors.white,
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
                  Padding(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    child: Row(
                      children: [
                        Text(S.tr('p2a_4c704f83'), style: AppTextStyles.h3),
                        const SizedBox(width: 6),
                        Text('(${widget.messages.length})', style: AppTextStyles.caption),
                      ],
                    ),
                  ),
                  Expanded(
                    child: widget.messages.isEmpty
                        ? AppEmptyState(icon: Icons.chat_bubble_outline_rounded, title: S.tr('p2a_4981cd14'), subtitle: S.tr('p2a_43f15d93'))
                        : ListView.builder(
                            controller: _listController,
                            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
                            itemCount: widget.messages.length,
                            itemBuilder: (_, i) => _ChatMessageBubble(message: widget.messages[i]),
                          ),
                  ),
                  AnimatedCrossFade(
                    duration: const Duration(milliseconds: 180),
                    crossFadeState: _showEmojiRow ? CrossFadeState.showFirst : CrossFadeState.showSecond,
                    firstChild: SizedBox(
                      height: 44,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
                        itemCount: kQuickEmojis.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 6),
                        itemBuilder: (_, i) => InkWell(
                          borderRadius: BorderRadius.circular(AppRadius.pill),
                          onTap: () => _insertEmoji(kQuickEmojis[i]),
                          child: Padding(
                            padding: const EdgeInsets.all(6),
                            child: Text(kQuickEmojis[i], style: const TextStyle(fontSize: 22)),
                          ),
                        ),
                      ),
                    ),
                    secondChild: const SizedBox(height: 0, width: double.infinity),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(AppSpacing.md, AppSpacing.xs, AppSpacing.md, AppSpacing.md),
                    child: Row(
                      children: [
                        InkWell(
                          borderRadius: BorderRadius.circular(AppRadius.pill),
                          onTap: () => setState(() => _showEmojiRow = !_showEmojiRow),
                          child: Padding(
                            padding: const EdgeInsets.all(8),
                            child: Icon(
                              Icons.emoji_emotions_outlined,
                              color: _showEmojiRow ? AppColors.primary : AppColors.textSecondary,
                            ),
                          ),
                        ),
                        Expanded(
                          child: TextField(
                            controller: _controller,
                            onSubmitted: (_) => _send(),
                            onTap: () {
                              if (_showEmojiRow) setState(() => _showEmojiRow = false);
                            },
                            decoration: InputDecoration(hintText: S.tr('p2a_dcc82f73'), isDense: true),
                          ),
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Material(
                          color: AppColors.primary,
                          shape: const CircleBorder(),
                          child: InkWell(
                            customBorder: const CircleBorder(),
                            onTap: _send,
                            child: const SizedBox(width: 42, height: 42, child: Icon(Icons.send_rounded, color: Colors.white, size: 18)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// فقاعة رسالة واحدة داخل دردشة الروم — تدعم الأنواع الأربعة
class _ChatMessageBubble extends StatelessWidget {
  final RoomChatMessage message;
  const _ChatMessageBubble({required this.message});

  String get _timeLabel => '${message.time.hour.toString().padLeft(2, '0')}:${message.time.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    // رسائل النظام / الانضمام: شريحة موحّدة فالوسط
    if (message.type == RoomChatMessageType.system) {
      return _CenterPill(
        icon: Icons.campaign_rounded,
        text: message.text ?? '',
        background: AppColors.surface,
        foreground: AppColors.textSecondary,
      );
    }
    if (message.type == RoomChatMessageType.join) {
      return _CenterPill(
        icon: Icons.login_rounded,
        text: '${message.sender?.name ?? ''} ${message.text ?? S.tr('p2a_join_room')}',
        background: AppColors.surface,
        foreground: AppColors.info,
      );
    }
    if (message.type == RoomChatMessageType.gift) {
      final gift = message.gift;
      return _CenterPill(
        icon: Icons.card_giftcard_rounded,
        text: S.trParams('p2a_gift_system', {
          'sender': message.sender?.name ?? '',
          'receiver': message.giftReceiver?.name ?? '',
          'gift': gift != null ? '${gift.emoji} ${gift.name}' : S.tr('p2a_gift'),
        }) + (message.giftQuantity > 1 ? ' × ${message.giftQuantity}' : ''),
        background: const Color(0xFFFFF3E0),
        foreground: AppColors.primaryDark,
      );
    }

    // رسالة نصية عادية
    final isMe = message.isMe;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isMe) ...[
            RoomAvatarCircle(imagePath: message.sender?.avatarPath, fallbackText: message.sender?.name ?? '?', size: 32),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (!isMe)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 2, right: 2),
                    child: Text(message.sender?.name ?? '', style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w700)),
                  ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: isMe ? AppColors.primary : AppColors.surface,
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                  child: Text(
                    message.text ?? '',
                    style: AppTextStyles.body.copyWith(color: isMe ? Colors.white : AppColors.textPrimary),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(_timeLabel, style: AppTextStyles.caption.copyWith(fontSize: 10)),
                ),
              ],
            ),
          ),
          if (isMe) ...[
            const SizedBox(width: 8),
            RoomAvatarCircle(imagePath: message.sender?.avatarPath, fallbackText: message.sender?.name ?? '?', size: 32),
          ],
        ],
      ),
    );
  }
}

class _CenterPill extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color background;
  final Color foreground;
  const _CenterPill({required this.icon, required this.text, required this.background, required this.foreground});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(AppRadius.pill)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 13, color: foreground),
              const SizedBox(width: 6),
              Flexible(child: Text(text, style: AppTextStyles.caption.copyWith(color: foreground, fontWeight: FontWeight.w600), textAlign: TextAlign.center)),
            ],
          ),
        ),
      ),
    );
  }
}

/// عنصر إجراء بسيط داخل Bottom Sheets (المزيد / خيارات المقعد)
class _SheetActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool danger;

  const _SheetActionTile({required this.icon, required this.label, required this.onTap, this.danger = false});

  @override
  Widget build(BuildContext context) {
    final color = danger ? AppColors.danger : AppColors.textPrimary;
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(label, style: AppTextStyles.body.copyWith(color: color, fontWeight: FontWeight.w600)),
      onTap: onTap,
    );
  }
}

/// ------------------------------------------------------------
/// 2. Gifts (Phase 4 — Part 2/3): لوحة الهدايا داخل الروم
/// تصنيفات + شبكة هدايا + اختيار مستلم + كمية + إرسال محلي
/// (خصم من رصيد Coins محلي) + سجل هدايا. كل شيء Local/Mock فقط.
/// ------------------------------------------------------------
class _GiftsSheet extends StatefulWidget {
  final int coinBalance;
  final List<GiftHistoryEntry> giftHistory;
  final List<RoomMemberInfo> members;
  final RoomMemberInfo defaultReceiver;
  final bool Function({required GiftModel gift, required int quantity, required UserModel receiver}) onSend;

  const _GiftsSheet({
    required this.coinBalance,
    required this.giftHistory,
    required this.members,
    required this.defaultReceiver,
    required this.onSend,
  });

  @override
  State<_GiftsSheet> createState() => _GiftsSheetState();
}

class _GiftsSheetState extends State<_GiftsSheet> with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 2, vsync: this);
  late int _coinBalance = widget.coinBalance;
  late RoomMemberInfo _receiver = widget.defaultReceiver;
  late GiftCategoryModel _activeCategory = MockData.giftCategories.first;
  GiftModel? _selectedGift;
  int _quantity = 1;

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /// قائمة المستلمين الممكنين (المستلم الافتراضي + كل الأعضاء بلا تكرار)
  List<RoomMemberInfo> get _receivers {
    final seen = <String>{};
    return [
      for (final m in [widget.defaultReceiver, ...widget.members])
        if (seen.add(m.user.id)) m,
    ];
  }

  void _pickReceiver() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSpacing.lg),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
                const SizedBox(height: AppSpacing.md),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                  child: Text(S.tr('p2a_6b97a9da'), style: AppTextStyles.h3),
                ),
                const SizedBox(height: AppSpacing.sm),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 320),
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      for (final m in _receivers)
                        ListTile(
                          leading: RoomAvatarCircle(imagePath: m.user.avatarPath, fallbackText: m.user.name, size: 40),
                          title: Text(m.user.name, style: AppTextStyles.bodyBold),
                          subtitle: m.role != RoomRole.member ? Text(m.role.label, style: AppTextStyles.caption) : null,
                          trailing: m.user.id == _receiver.user.id ? const Icon(Icons.check_circle_rounded, color: AppColors.primary) : null,
                          onTap: () {
                            setState(() => _receiver = m);
                            Navigator.pop(ctx);
                          },
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _selectGift(GiftModel gift) {
    setState(() {
      _selectedGift = gift;
      _quantity = 1;
    });
  }

  void _changeQuantity(int delta) {
    setState(() => _quantity = (_quantity + delta).clamp(1, 99));
  }

  void _confirmSend() {
    final gift = _selectedGift;
    if (gift == null) return;
    final total = gift.price * _quantity;
    if (_coinBalance < total) {
      showRoomMockFeedback(context, S.tr('p2a_2430664d'));
      return;
    }
    final ok = widget.onSend(gift: gift, quantity: _quantity, receiver: _receiver.user);
    if (!ok) {
      showRoomMockFeedback(context, S.tr('p2a_2430664d'));
      return;
    }
    setState(() {
      _coinBalance -= total;
      _selectedGift = null;
      _quantity = 1;
    });
    showRoomMockFeedback(context, S.trParams('p2a_gift_message', {'gift': '${gift.emoji} ${gift.name}', 'name': _receiver.user.name}));
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.66,
      minChildSize: 0.45,
      maxChildSize: 0.92,
      expand: false,
      builder: (context, scrollController) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                const SizedBox(height: 10),
                Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
                Padding(
                  padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.lg, 0),
                  child: Row(
                    children: [
                      Text(S.tr('p2a_c7b318a4'), style: AppTextStyles.h3),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(AppRadius.pill)),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.monetization_on_rounded, size: 16, color: AppColors.warning),
                            const SizedBox(width: 4),
                            Text('$_coinBalance', style: AppTextStyles.bodyBold.copyWith(fontSize: 13)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, 0),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    onTap: _pickReceiver,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
                      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(AppRadius.md)),
                      child: Row(
                        children: [
                          RoomAvatarCircle(imagePath: _receiver.user.avatarPath, fallbackText: _receiver.user.name, size: 28),
                          const SizedBox(width: AppSpacing.sm),
                          Expanded(child: Text(S.trParams('p2a_gift_to', {'name': _receiver.user.name}), style: AppTextStyles.bodyBold.copyWith(fontSize: 13))),
                          const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
                        ],
                      ),
                    ),
                  ),
                ),
                TabBar(
                  controller: _tabController,
                  labelColor: AppColors.primary,
                  unselectedLabelColor: AppColors.textSecondary,
                  indicatorColor: AppColors.primary,
                  labelStyle: AppTextStyles.bodyBold.copyWith(fontSize: 13),
                  tabs: [Tab(text: S.tr('p2a_c7b318a4')), Tab(text: S.tr('p2a_ec4337ed'))],
                ),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildGiftsTab(),
                      _buildHistoryTab(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildGiftsTab() {
    return Column(
      children: [
        SizedBox(
          height: 44,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.xs),
            itemCount: MockData.giftCategories.length,
            separatorBuilder: (_, __) => const SizedBox(width: AppSpacing.sm),
            itemBuilder: (_, i) {
              final cat = MockData.giftCategories[i];
              final active = cat.id == _activeCategory.id;
              return ChoiceChip(
                selected: active,
                label: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(cat.icon, size: 15, color: active ? Colors.white : AppColors.textSecondary),
                    const SizedBox(width: 4),
                    Text(cat.label),
                  ],
                ),
                labelStyle: AppTextStyles.caption.copyWith(color: active ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.w700),
                selectedColor: AppColors.primary,
                backgroundColor: AppColors.surface,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.pill), side: BorderSide.none),
                onSelected: (_) => setState(() => _activeCategory = cat),
              );
            },
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(AppSpacing.lg),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: AppSpacing.md,
              crossAxisSpacing: AppSpacing.md,
              childAspectRatio: 0.78,
            ),
            itemCount: _activeCategory.gifts.length,
            itemBuilder: (_, i) {
              final gift = _activeCategory.gifts[i];
              final selected = _selectedGift?.id == gift.id;
              return InkWell(
                borderRadius: BorderRadius.circular(AppRadius.md),
                onTap: () => _selectGift(gift),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
                  decoration: BoxDecoration(
                    color: selected ? AppColors.primaryLight.withOpacity(0.4) : AppColors.surface,
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    border: Border.all(color: selected ? AppColors.primary : Colors.transparent, width: 1.5),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(gift.emoji, style: const TextStyle(fontSize: 26)),
                      const SizedBox(height: 4),
                      Text(gift.name, style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 2),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.monetization_on_rounded, size: 11, color: AppColors.warning),
                          const SizedBox(width: 2),
                          Text('${gift.price}', style: AppTextStyles.caption.copyWith(fontSize: 10)),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        AnimatedCrossFade(
          duration: const Duration(milliseconds: 180),
          crossFadeState: _selectedGift != null ? CrossFadeState.showFirst : CrossFadeState.showSecond,
          firstChild: Container(
            padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.lg),
            decoration: const BoxDecoration(
              color: AppColors.surface,
              border: Border(top: BorderSide(color: AppColors.divider)),
            ),
            child: _selectedGift == null
                ? const SizedBox.shrink()
                : Row(
                    children: [
                      Text(_selectedGift!.emoji, style: const TextStyle(fontSize: 22)),
                      const SizedBox(width: 6),
                      Expanded(child: Text(_selectedGift!.name, style: AppTextStyles.bodyBold, overflow: TextOverflow.ellipsis)),
                      _QuantityStepper(quantity: _quantity, onChanged: _changeQuantity),
                      const SizedBox(width: AppSpacing.sm),
                      ElevatedButton(
                        onPressed: _confirmSend,
                        child: Text(S.tr('p2a_6dbd36c3')),
                      ),
                    ],
                  ),
          ),
          secondChild: const SizedBox(height: 0, width: double.infinity),
        ),
      ],
    );
  }

  Widget _buildHistoryTab() {
    if (widget.giftHistory.isEmpty) {
      return AppEmptyState(icon: Icons.card_giftcard_outlined, title: S.tr('p2a_fa05658f'), subtitle: S.tr('p2a_d9457e86'));
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
      itemCount: widget.giftHistory.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) {
        final entry = widget.giftHistory[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Text(entry.gift.emoji, style: const TextStyle(fontSize: 26)),
          title: Text('${entry.sender.name} → ${entry.receiver.name}', style: AppTextStyles.bodyBold.copyWith(fontSize: 13)),
          subtitle: Text(
            '${entry.gift.name}${entry.quantity > 1 ? ' × ${entry.quantity}' : ''} • ${entry.time.hour.toString().padLeft(2, '0')}:${entry.time.minute.toString().padLeft(2, '0')}',
            style: AppTextStyles.caption,
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.monetization_on_rounded, size: 13, color: AppColors.warning),
              const SizedBox(width: 2),
              Text('${entry.gift.price * entry.quantity}', style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w700)),
            ],
          ),
        );
      },
    );
  }
}

/// عدّاد كمية بسيط (+/-) مستعمل عند اختيار هدية
class _QuantityStepper extends StatelessWidget {
  final int quantity;
  final ValueChanged<int> onChanged;
  const _QuantityStepper({required this.quantity, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.pill), border: Border.all(color: AppColors.border)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(AppRadius.pill),
            onTap: () => onChanged(-1),
            child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.remove_rounded, size: 16)),
          ),
          SizedBox(width: 22, child: Text('$quantity', textAlign: TextAlign.center, style: AppTextStyles.bodyBold.copyWith(fontSize: 13))),
          InkWell(
            borderRadius: BorderRadius.circular(AppRadius.pill),
            onTap: () => onChanged(1),
            child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.add_rounded, size: 16)),
          ),
        ],
      ),
    );
  }
}

/// أنيميشن خفيف لطيران الهدية فوق المقاعد (يظهر وسط الشاشة ثم يختفي تلقائيًا)
class _GiftFlyAnimation extends StatefulWidget {
  final GiftModel gift;
  final VoidCallback onDone;
  const _GiftFlyAnimation({super.key, required this.gift, required this.onDone});

  @override
  State<_GiftFlyAnimation> createState() => _GiftFlyAnimationState();
}

class _GiftFlyAnimationState extends State<_GiftFlyAnimation> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
  late final Animation<double> _rise = Tween<double>(begin: 0, end: -130).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  late final Animation<double> _opacity = TweenSequence<double>([
    TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 15),
    TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.0), weight: 55),
    TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 30),
  ]).animate(_controller);
  late final Animation<double> _scale = TweenSequence<double>([
    TweenSequenceItem(tween: Tween(begin: 0.5, end: 1.15), weight: 25),
    TweenSequenceItem(tween: Tween(begin: 1.15, end: 1.0), weight: 15),
    TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.0), weight: 60),
  ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

  @override
  void initState() {
    super.initState();
    _controller.forward().whenComplete(widget.onDone);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Align(
        alignment: const Alignment(0, 0.3),
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Opacity(
              opacity: _opacity.value.clamp(0.0, 1.0),
              child: Transform.translate(
                offset: Offset(0, _rise.value),
                child: Transform.scale(scale: _scale.value, child: child),
              ),
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(AppRadius.pill)),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(widget.gift.emoji, style: const TextStyle(fontSize: 28)),
                const SizedBox(width: 6),
                Text(widget.gift.name, style: AppTextStyles.bodyBold.copyWith(color: Colors.white)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// 3. Invite (Phase 4 — Part 2/3): دعوة أعضاء للروم — Mock فقط
/// بحث محلي + مقترحون + حالة "تمت الدعوة" لكل مستخدم
/// ------------------------------------------------------------
class _InviteMembersSheet extends StatefulWidget {
  const _InviteMembersSheet();

  @override
  State<_InviteMembersSheet> createState() => _InviteMembersSheetState();
}

class _InviteMembersSheetState extends State<_InviteMembersSheet> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  final Set<String> _invited = {};

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<UserModel> get _filtered {
    if (_query.trim().isEmpty) return MockData.inviteCandidates;
    final q = _query.trim().toLowerCase();
    return MockData.inviteCandidates.where((u) => u.name.toLowerCase().contains(q)).toList();
  }

  void _invite(UserModel user) {
    setState(() => _invited.add(user.id));
    showRoomMockFeedback(context, S.trParams('p2a_invite_sent', {'name': user.name}));
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    final showRecommended = _query.trim().isEmpty;
    return DraggableScrollableSheet(
      initialChildSize: 0.66,
      minChildSize: 0.4,
      maxChildSize: 0.92,
      expand: false,
      builder: (context, scrollController) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                const SizedBox(height: 10),
                Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
                Padding(
                  padding: const EdgeInsets.all(AppSpacing.lg),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(S.tr('p2a_90b4690c'), style: AppTextStyles.h3),
                      const SizedBox(height: AppSpacing.md),
                      TextField(
                        controller: _searchController,
                        onChanged: (v) => setState(() => _query = v),
                        decoration: InputDecoration(
                          hintText: S.tr('p2a_ffd94062'),
                          prefixIcon: Icon(Icons.search_rounded, size: 20),
                          isDense: true,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: filtered.isEmpty
                      ? AppEmptyState(icon: Icons.person_search_rounded, title: S.tr('p2a_252bf7ff'), subtitle: S.tr('p2a_3718b1d2'))
                      : ListView(
                          controller: scrollController,
                          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                          children: [
                            if (showRecommended) ...[
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
                                child: Text(S.tr('p2a_63397fa3'), style: AppTextStyles.bodyBold.copyWith(fontSize: 13, color: AppColors.textSecondary)),
                              ),
                              SizedBox(
                                height: 96,
                                child: ListView.separated(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: MockData.inviteRecommended.length,
                                  separatorBuilder: (_, __) => const SizedBox(width: AppSpacing.md),
                                  itemBuilder: (_, i) {
                                    final user = MockData.inviteRecommended[i];
                                    final invited = _invited.contains(user.id);
                                    return SizedBox(
                                      width: 68,
                                      child: Column(
                                        children: [
                                          RoomAvatarCircle(imagePath: user.avatarPath, fallbackText: user.name, size: 48, borderColor: AppColors.border),
                                          const SizedBox(height: 4),
                                          Text(user.name, style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
                                          const SizedBox(height: 4),
                                          InkWell(
                                            borderRadius: BorderRadius.circular(AppRadius.pill),
                                            onTap: invited ? null : () => _invite(user),
                                            child: Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                              decoration: BoxDecoration(
                                                color: invited ? AppColors.grey200 : AppColors.primary,
                                                borderRadius: BorderRadius.circular(AppRadius.pill),
                                              ),
                                              child: Text(
                                                invited ? S.tr('p2a_b0c8e882') : S.tr('invite'),
                                                style: AppTextStyles.caption.copyWith(color: invited ? AppColors.textSecondary : Colors.white, fontSize: 10, fontWeight: FontWeight.w700),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                              const Divider(height: AppSpacing.xl),
                            ],
                            for (final user in filtered)
                              ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: RoomAvatarCircle(imagePath: user.avatarPath, fallbackText: user.name, size: 44, borderColor: AppColors.border),
                                title: Text(user.name, style: AppTextStyles.bodyBold),
                                subtitle: user.isVip ? const Text('VIP', style: AppTextStyles.caption) : null,
                                trailing: _invited.contains(user.id)
                                    ? OutlinedButton.icon(
                                        onPressed: null,
                                        icon: const Icon(Icons.check_rounded, size: 16),
                                        label: Text(S.tr('p2a_b0c8e882')),
                                      )
                                    : ElevatedButton(
                                        onPressed: () => _invite(user),
                                        child: Text(S.tr('invite')),
                                      ),
                              ),
                          ],
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// ------------------------------------------------------------
/// 4. Share (Phase 4 — Part 2/3): مشاركة الروم — Mock فقط
/// معرّف الروم + نسخ + خيارات مشاركة محلية (بلا Backend/Share API حقيقي)
/// ------------------------------------------------------------
class _ShareRoomSheet extends StatelessWidget {
  final String roomName;
  final String roomId;
  const _ShareRoomSheet({required this.roomName, required this.roomId});

  void _copyId(BuildContext context) {
    Clipboard.setData(ClipboardData(text: roomId));
    showRoomMockFeedback(context, S.tr('p2a_36c75b81'));
  }

  void _shareVia(BuildContext context, String channel) {
    showRoomMockFeedback(context, S.trParams('p2a_shared_via', {'channel': channel}));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
            const SizedBox(height: AppSpacing.md),
            Text(S.tr('p2a_25c0dc32'), style: AppTextStyles.h3),
            const SizedBox(height: 2),
            Text(roomName, style: AppTextStyles.caption, textAlign: TextAlign.center),
            const SizedBox(height: AppSpacing.lg),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(AppRadius.md)),
              child: Row(
                children: [
                  const Icon(Icons.tag_rounded, size: 18, color: AppColors.textSecondary),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(S.trParams('p2a_room_id', {'id': roomId}), style: AppTextStyles.bodyBold.copyWith(fontSize: 13)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.copy_rounded, size: 18, color: AppColors.primary),
                    onPressed: () => _copyId(context),
                    tooltip: S.tr('p2a_eb32f766'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                Expanded(child: RoomActionButton(icon: Icons.chat_rounded, label: 'واتساب', onTap: () => _shareVia(context, 'واتساب'), background: const Color(0xFFE7F7EE), foreground: const Color(0xFF25A15C))),
                const SizedBox(width: AppSpacing.sm),
                Expanded(child: RoomActionButton(icon: Icons.send_rounded, label: 'تيليجرام', onTap: () => _shareVia(context, 'تيليجرام'), background: const Color(0xFFE7F1FB), foreground: const Color(0xFF1E88C7))),
                const SizedBox(width: AppSpacing.sm),
                Expanded(child: RoomActionButton(icon: Icons.link_rounded, label: S.tr('p2a_0d8af0ab'), onTap: () => _copyId(context))),
                const SizedBox(width: AppSpacing.sm),
                Expanded(child: RoomActionButton(icon: Icons.more_horiz_rounded, label: S.tr('p2a_407bdba7'), onTap: () => _shareVia(context, S.tr('p2a_3d9e0103')))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
