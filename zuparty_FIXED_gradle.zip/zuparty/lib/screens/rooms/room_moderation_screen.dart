import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import 'room_shared_widgets.dart';
import 'voice_room_screen.dart' show showRoomConfirmDialog;

/// ============================================================
/// Zuparty — Phase 4 Part 3/3: Moderation (إدارة الأعضاء)
/// ------------------------------------------------------------
/// شاشة موحّدة لعرض الأعضاء المكتومين (من طرف الإدارة) والمحظورين،
/// مع إمكانية "إلغاء الكتم" و"إلغاء الحظر". Local State + Mock فقط.
/// ============================================================
class RoomModerationScreen extends StatefulWidget {
  final List<RoomMemberInfo> members;
  final List<RoomMemberInfo> bannedMembers;
  final VoidCallback? onChanged;

  const RoomModerationScreen({
    super.key,
    required this.members,
    required this.bannedMembers,
    this.onChanged,
  });

  @override
  State<RoomModerationScreen> createState() => _RoomModerationScreenState();
}

class _RoomModerationScreenState extends State<RoomModerationScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<RoomMemberInfo> get _mutedMembers => widget.members.where((m) => m.isModMuted).toList();

  void _unmute(RoomMemberInfo member) {
    setState(() => member.isModMuted = false);
    widget.onChanged?.call();
    showRoomMockFeedback(context, 'تم إلغاء كتم ${member.user.name} (Mock)');
  }

  Future<void> _unban(RoomMemberInfo member) async {
    final confirmed = await showRoomConfirmDialog(
      context,
      title: 'إلغاء حظر ${member.user.name}؟',
      message: 'غادي يقدر يدخل لهاد الروم من جديد.',
      confirmLabel: 'إلغاء الحظر',
    );
    if (confirmed != true || !mounted) return;
    setState(() {
      widget.bannedMembers.remove(member);
      widget.members.add(member);
    });
    widget.onChanged?.call();
    if (mounted) showRoomMockFeedback(context, 'تم إلغاء حظر ${member.user.name} (Mock)');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('إدارة الأعضاء'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          indicatorColor: AppColors.primary,
          tabs: [
            Tab(text: 'المكتومون (${_mutedMembers.length})'),
            Tab(text: 'المحظورون (${widget.bannedMembers.length})'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildList(
            items: _mutedMembers,
            emptyIcon: Icons.mic_rounded,
            emptyTitle: 'لا يوجد أعضاء مكتومون',
            emptySubtitle: 'الأعضاء اللي تكتموا من طرف الإدارة غيبانو هنا',
            actionLabel: 'إلغاء الكتم',
            actionIcon: Icons.mic_rounded,
            onAction: _unmute,
          ),
          _buildList(
            items: widget.bannedMembers,
            emptyIcon: Icons.block_rounded,
            emptyTitle: 'لا يوجد أعضاء محظورون',
            emptySubtitle: 'الأعضاء اللي تحظاو غيبانو هنا وتقدر تلغي الحظر ديالهم',
            actionLabel: 'إلغاء الحظر',
            actionIcon: Icons.lock_open_rounded,
            onAction: _unban,
          ),
        ],
      ),
    );
  }

  Widget _buildList({
    required List<RoomMemberInfo> items,
    required IconData emptyIcon,
    required String emptyTitle,
    required String emptySubtitle,
    required String actionLabel,
    required IconData actionIcon,
    required void Function(RoomMemberInfo member) onAction,
  }) {
    if (items.isEmpty) {
      return AppEmptyState(icon: emptyIcon, title: emptyTitle, subtitle: emptySubtitle);
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
      itemBuilder: (context, i) {
        final member = items[i];
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppRadius.md),
            boxShadow: AppShadows.card,
          ),
          child: Row(
            children: [
              RoomAvatarCircle(imagePath: member.user.avatarPath, fallbackText: member.user.name, size: 42, borderColor: AppColors.border),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(member.user.name, style: AppTextStyles.bodyBold),
                    Text(member.role.label, style: AppTextStyles.caption),
                  ],
                ),
              ),
              OutlinedButton.icon(
                onPressed: () => onAction(member),
                icon: Icon(actionIcon, size: 16),
                label: Text(actionLabel),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  visualDensity: VisualDensity.compact,
                  textStyle: const TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
