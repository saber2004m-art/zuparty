import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../theme/app_theme.dart';
import '../../routing/app_page_route.dart';
import 'room_shared_widgets.dart';
import 'room_theme_screen.dart';
import 'room_moderation_screen.dart';

/// ============================================================
/// Zuparty — Phase 4 Part 3/3: Room Settings (إعدادات الروم)
/// ------------------------------------------------------------
/// UI/Local State + Mock Data فقط. لا Backend / لا API.
/// كل التغييرات كتتخزّن مباشرة فـ RoomModel (نفس النمط المستعمل
/// فـ CreateRoomScreen)، مع دعم "حفظ محليًا" و"إعادة تعيين".
/// ============================================================
class VoiceRoomSettingsScreen extends StatefulWidget {
  final RoomModel room;
  final List<RoomMemberInfo> members;
  final List<RoomMemberInfo> bannedMembers;
  final VoidCallback? onChanged;

  const VoiceRoomSettingsScreen({
    super.key,
    required this.room,
    required this.members,
    required this.bannedMembers,
    this.onChanged,
  });

  @override
  State<VoiceRoomSettingsScreen> createState() => _VoiceRoomSettingsScreenState();
}

class _VoiceRoomSettingsScreenState extends State<VoiceRoomSettingsScreen> {
  late TextEditingController _nameController;
  late TextEditingController _descController;

  late String _whoCanSpeak;
  late String _whoCanChat;
  late bool _allowGuestGifts;
  late bool _superMicEnabled;
  late bool _showGiftEffects;
  late bool _showVoiceWave;
  late bool _isRoomLocked;

  // نسخة أصلية باش نقدرو نرجعو ليها بـ "إعادة تعيين"
  late final Map<String, dynamic> _initialSnapshot;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    final room = widget.room;
    _nameController = TextEditingController(text: room.name);
    _descController = TextEditingController(text: room.description);
    _whoCanSpeak = room.whoCanSpeak;
    _whoCanChat = room.whoCanChat;
    _allowGuestGifts = room.allowGuestGifts;
    _superMicEnabled = room.superMicEnabled;
    _showGiftEffects = room.showGiftEffects;
    _showVoiceWave = room.showVoiceWave;
    _isRoomLocked = room.isRoomLocked;

    _initialSnapshot = {
      'name': room.name,
      'description': room.description,
      'whoCanSpeak': room.whoCanSpeak,
      'whoCanChat': room.whoCanChat,
      'allowGuestGifts': room.allowGuestGifts,
      'superMicEnabled': room.superMicEnabled,
      'showGiftEffects': room.showGiftEffects,
      'showVoiceWave': room.showVoiceWave,
      'isRoomLocked': room.isRoomLocked,
    };
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descController.dispose();
    super.dispose();
  }

  void _markDirty() {
    if (!_dirty) setState(() => _dirty = true);
  }

  void _save() {
    final room = widget.room;
    setState(() {
      room.name = _nameController.text.trim().isEmpty ? room.name : _nameController.text.trim();
      room.description = _descController.text.trim();
      room.whoCanSpeak = _whoCanSpeak;
      room.whoCanChat = _whoCanChat;
      room.allowGuestGifts = _allowGuestGifts;
      room.superMicEnabled = _superMicEnabled;
      room.showGiftEffects = _showGiftEffects;
      room.showVoiceWave = _showVoiceWave;
      room.isRoomLocked = _isRoomLocked;
      _dirty = false;
    });
    widget.onChanged?.call();
    showRoomMockFeedback(context, 'تم حفظ إعدادات الروم محليًا (Mock)');
  }

  void _reset() {
    setState(() {
      _nameController.text = _initialSnapshot['name'] as String;
      _descController.text = _initialSnapshot['description'] as String;
      _whoCanSpeak = _initialSnapshot['whoCanSpeak'] as String;
      _whoCanChat = _initialSnapshot['whoCanChat'] as String;
      _allowGuestGifts = _initialSnapshot['allowGuestGifts'] as bool;
      _superMicEnabled = _initialSnapshot['superMicEnabled'] as bool;
      _showGiftEffects = _initialSnapshot['showGiftEffects'] as bool;
      _showVoiceWave = _initialSnapshot['showVoiceWave'] as bool;
      _isRoomLocked = _initialSnapshot['isRoomLocked'] as bool;
      _dirty = false;
    });
    showRoomMockFeedback(context, 'تمت إعادة التعيين لآخر حفظ');
  }

  @override
  Widget build(BuildContext context) {
    final room = widget.room;
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('إعدادات الروم'),
        actions: [
          TextButton(
            onPressed: _dirty ? _reset : null,
            child: const Text('إعادة تعيين'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          _SectionCard(
            title: 'معلومات الروم',
            children: [
              _FieldLabel('اسم الروم'),
              TextField(
                controller: _nameController,
                onChanged: (_) => _markDirty(),
                maxLength: 30,
                decoration: const InputDecoration(hintText: 'اسم الروم', counterText: ''),
              ),
              const SizedBox(height: AppSpacing.md),
              _FieldLabel('الوصف'),
              TextField(
                controller: _descController,
                onChanged: (_) => _markDirty(),
                maxLines: 3,
                maxLength: 120,
                decoration: const InputDecoration(hintText: 'اكتب وصف قصير للروم...'),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          _SectionCard(
            title: 'صلاحيات الروم',
            children: [
              _FieldLabel('من يقدر يتكلم؟'),
              _PermissionSelector(
                value: _whoCanSpeak,
                onChanged: (v) {
                  setState(() => _whoCanSpeak = v);
                  _markDirty();
                },
              ),
              const SizedBox(height: AppSpacing.md),
              _FieldLabel('من يقدر يدردش؟'),
              _PermissionSelector(
                value: _whoCanChat,
                onChanged: (v) {
                  setState(() => _whoCanChat = v);
                  _markDirty();
                },
              ),
              const Divider(height: AppSpacing.xl),
              _SwitchRow(
                icon: Icons.lock_outline_rounded,
                label: 'روم خاص (يحتاج دعوة)',
                value: _isRoomLocked,
                onChanged: (v) {
                  setState(() => _isRoomLocked = v);
                  _markDirty();
                },
              ),
              _SwitchRow(
                icon: Icons.mic_external_on_rounded,
                label: 'تفعيل Super Mic',
                value: _superMicEnabled,
                onChanged: (v) {
                  setState(() => _superMicEnabled = v);
                  _markDirty();
                },
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          _SectionCard(
            title: 'إعدادات الهدايا',
            children: [
              _SwitchRow(
                icon: Icons.card_giftcard_rounded,
                label: 'السماح للزوار بإرسال الهدايا',
                value: _allowGuestGifts,
                onChanged: (v) {
                  setState(() => _allowGuestGifts = v);
                  _markDirty();
                },
              ),
              _SwitchRow(
                icon: Icons.auto_awesome_rounded,
                label: 'إظهار تأثيرات الهدايا',
                value: _showGiftEffects,
                onChanged: (v) {
                  setState(() => _showGiftEffects = v);
                  _markDirty();
                },
              ),
              _SwitchRow(
                icon: Icons.graphic_eq_rounded,
                label: 'إظهار موجة الصوت',
                value: _showVoiceWave,
                onChanged: (v) {
                  setState(() => _showVoiceWave = v);
                  _markDirty();
                },
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          _SectionCard(
            title: 'المزيد',
            padding: EdgeInsets.zero,
            children: [
              _NavTile(
                icon: Icons.palette_outlined,
                label: 'ثيم الروم',
                subtitle: 'الخلفية ولون تأثير التحدث',
                onTap: () async {
                  await Navigator.push(
                    context,
                    appPageRoute(builder: (_) => RoomThemeScreen(room: room, onChanged: widget.onChanged)),
                  );
                  if (mounted) setState(() {});
                },
              ),
              const Divider(height: 1, indent: 56),
              _NavTile(
                icon: Icons.shield_outlined,
                label: 'إدارة الأعضاء',
                subtitle: 'المكتومين والمحظورين (${widget.bannedMembers.length} محظور)',
                onTap: () {
                  Navigator.push(
                    context,
                    appPageRoute(
                      builder: (_) => RoomModerationScreen(
                        members: widget.members,
                        bannedMembers: widget.bannedMembers,
                        onChanged: widget.onChanged,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.xxl),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _dirty ? _save : null,
              child: const Text('حفظ الإعدادات'),
            ),
          ),
          const SizedBox(height: AppSpacing.xxxl),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final EdgeInsetsGeometry? padding;
  const _SectionCard({required this.title, required this.children, this.padding});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        boxShadow: AppShadows.card,
      ),
      child: Padding(
        padding: padding ?? const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (padding == EdgeInsets.zero)
              Padding(
                padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, AppSpacing.sm),
                child: Text(title, style: AppTextStyles.h3),
              )
            else ...[
              Text(title, style: AppTextStyles.h3),
              const SizedBox(height: AppSpacing.md),
            ],
            ...children,
          ],
        ),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(text, style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w700)),
    );
  }
}

class _SwitchRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchRow({required this.icon, required this.label, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      value: value,
      onChanged: onChanged,
      activeColor: AppColors.primary,
      secondary: Icon(icon, color: AppColors.textSecondary),
      title: Text(label, style: AppTextStyles.body),
    );
  }
}

class _NavTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? subtitle;
  final VoidCallback onTap;
  const _NavTile({required this.icon, required this.label, this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.textSecondary),
      title: Text(label, style: AppTextStyles.bodyBold),
      subtitle: subtitle != null ? Text(subtitle!, style: AppTextStyles.caption) : null,
      trailing: const Icon(Icons.chevron_left_rounded, color: AppColors.grey400),
      onTap: onTap,
    );
  }
}

/// اختيار صلاحية عبر أزرار مقسّمة (Segmented) — استعمال بسيط بلا حزمة خارجية
class _PermissionSelector extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  const _PermissionSelector({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: AppSpacing.sm,
      runSpacing: AppSpacing.sm,
      children: kRoomPermissionOptions.map((opt) {
        final selected = opt == value;
        return ChoiceChip(
          label: Text(opt),
          selected: selected,
          onSelected: (_) => onChanged(opt),
          selectedColor: AppColors.primaryLight,
          labelStyle: TextStyle(
            color: selected ? AppColors.primaryDark : AppColors.textSecondary,
            fontWeight: FontWeight.w700,
            fontSize: 12.5,
          ),
          backgroundColor: AppColors.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.pill), side: BorderSide.none),
        );
      }).toList(),
    );
  }
}
