import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../theme/app_theme.dart';
import '../../l10n/app_strings.dart';

/// ============================================================
/// Zuparty — Phase 3 Part 2/3 (Rooms: Create / Details / Preview)
/// عناصر UI صغيرة مشتركة بين شاشات الغرف، مبنية بالكامل على
/// Design System الموجود (بلا ألوان/مقاسات جديدة).
/// ============================================================

/// دائرة أفاتار موحّدة (صورة أو حرف أول من الاسم)
class RoomAvatarCircle extends StatelessWidget {
  final String? imagePath;
  final String fallbackText;
  final double size;
  final Color borderColor;

  const RoomAvatarCircle({
    super.key,
    this.imagePath,
    required this.fallbackText,
    this.size = 40,
    this.borderColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.grey200,
        border: Border.all(color: borderColor, width: 2),
      ),
      child: imagePath != null
          ? Image.asset(imagePath!, fit: BoxFit.cover)
          : Center(
              child: Text(
                fallbackText.isNotEmpty ? fallbackText.substring(0, 1) : '?',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: size * 0.4, color: AppColors.textSecondary),
              ),
            ),
    );
  }
}

/// شارة/شريحة معلومة صغيرة (تصنيف، شائع، جديد...)
class RoomTagChip extends StatelessWidget {
  final String label;
  final IconData? icon;
  final Color background;
  final Color foreground;

  const RoomTagChip({
    super.key,
    required this.label,
    this.icon,
    this.background = AppColors.surface,
    this.foreground = AppColors.textSecondary,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(AppRadius.pill)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: foreground),
            const SizedBox(width: 4),
          ],
          Text(label, style: AppTextStyles.caption.copyWith(color: foreground, fontWeight: FontWeight.w700, fontSize: 11)),
        ],
      ),
    );
  }
}

/// نقطة حالة (نشطة الآن / غير نشطة) مبنية على onlineCount
class RoomStatusBadge extends StatelessWidget {
  final int onlineCount;
  const RoomStatusBadge({super.key, required this.onlineCount});

  @override
  Widget build(BuildContext context) {
    final active = onlineCount > 0;
    final color = active ? AppColors.success : AppColors.grey500;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(
          active ? S.tr('room_status_active') : S.tr('room_status_inactive'),
          style: AppTextStyles.caption.copyWith(color: color, fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}

/// بطاقة قسم موحّدة (عنوان + محتوى) تُستعمل فـ Room Details
class RoomInfoSection extends StatelessWidget {
  final String title;
  final Widget child;
  const RoomInfoSection({super.key, required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: AppTextStyles.h3),
          const SizedBox(height: AppSpacing.sm),
          child,
        ],
      ),
    );
  }
}

/// زر دائري لأكشن ثانوي (مشاركة / دعوة) — يُستعمل فوق الغلاف وفـ الأسفل
class RoomActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? background;
  final Color? foreground;

  const RoomActionButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.background,
    this.foreground,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: background ?? AppColors.surface,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.md),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: foreground ?? AppColors.textPrimary, size: 20),
              const SizedBox(height: 4),
              Text(label, style: AppTextStyles.caption.copyWith(color: foreground ?? AppColors.textPrimary, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Snackbar موحّد لملاحظات محلية (مشاركة / دعوة / نسخ) — Mock فقط بلا خدمة حقيقية
void showRoomMockFeedback(BuildContext context, String message) {
  ScaffoldMessenger.of(context).hideCurrentSnackBar();
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(message), duration: const Duration(seconds: 2)),
  );
}

/// ============================================================
/// تدفّق "الانضمام للروم" (Join Room) — Phase 3 Part 3
/// تأكيد → تحميل → نجاح → دخول الروم الفعلي (onOpenRoom)
/// أو تأكيد → حالة خطأ محلية (روم خاص) — كل هادشي Local State فقط.
/// ============================================================
Future<void> showJoinRoomFlow(
  BuildContext context, {
  required RoomModel room,
  required void Function(RoomModel room) onOpenRoom,
}) async {
  // الروم غير متاح حاليًا (مثلاً تحت الصيانة/انتهى) — نوقفو قبل حتى شيت التأكيد.
  if (room.isUnavailable) {
    await _showJoinResultDialog(
      context,
      icon: Icons.error_outline_rounded,
      iconBackground: AppColors.grey500,
      title: S.tr('room_join_unavailable_title'),
      message: S.tr('room_join_unavailable_message'),
    );
    return;
  }

  // الروم وصل لأقصى سعة (Full) — نوقفو قبل شيت التأكيد بحالة واضحة.
  if (room.isFull) {
    await _showJoinResultDialog(
      context,
      icon: Icons.groups_rounded,
      iconBackground: AppColors.warning,
      title: S.tr('room_join_full_title'),
      message: S.tr('room_join_full_message'),
    );
    return;
  }

  final confirmed = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (_) => _JoinConfirmSheet(room: room),
  );
  if (confirmed != true) return;
  if (!context.mounted) return;

  // روم خاص: نوقفو هنا بحالة خطأ محلية واضحة (بلا محاولة دخول فعلية)
  if (room.isRoomLocked) {
    await _showJoinResultDialog(
      context,
      icon: Icons.lock_outline_rounded,
      iconBackground: AppColors.warning,
      title: S.tr('room_join_private_title'),
      message: S.trParams('room_join_private_message_template', {'owner': room.ownerName ?? S.tr('room_owner_title')}),
      primaryLabel: S.tr('room_join_request_invite_btn'),
      onPrimary: () => showRoomMockFeedback(context, S.tr('room_join_invite_request_sent_toast')),
    );
    return;
  }

  final success = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const _JoinProgressDialog(),
  );

  if (success != true || !context.mounted) return;
  Navigator.of(context).pop(); // يقفل شاشة المعاينة/التفاصيل
  onOpenRoom(room);
}

class _JoinConfirmSheet extends StatelessWidget {
  final RoomModel room;
  const _JoinConfirmSheet({required this.room});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        margin: const EdgeInsets.all(AppSpacing.md),
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.xl),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4)),
            ),
            const SizedBox(height: AppSpacing.lg),
            RoomAvatarCircle(
              imagePath: room.imagePath,
              fallbackText: room.name,
              size: 60,
              borderColor: AppColors.border,
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              S.trParams('room_join_confirm_title_template', {'name': room.name}),
              style: AppTextStyles.h3,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 6),
            Text(
              S.trParams('room_join_confirm_subtitle_template', {
                'owner': room.ownerName ?? S.tr('unknown_owner'),
                'count': '${room.onlineCount}',
              }),
              style: AppTextStyles.caption,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.xl),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: Text(S.tr('cancel')),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: Text(S.tr('room_join_confirm_btn')),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// نافذة "جارٍ الانضمام..." ثم "تم بنجاح ✓" (Auto) — بلا تفاعل من المستخدم
class _JoinProgressDialog extends StatefulWidget {
  const _JoinProgressDialog();

  @override
  State<_JoinProgressDialog> createState() => _JoinProgressDialogState();
}

class _JoinProgressDialogState extends State<_JoinProgressDialog> {
  bool _success = false;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    await Future.delayed(const Duration(milliseconds: 650));
    if (!mounted) return;
    setState(() => _success = true);
    await Future.delayed(const Duration(milliseconds: 550));
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.lg)),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: _success
              ? Column(
                  key: const ValueKey('success'),
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: const BoxDecoration(color: AppColors.success, shape: BoxShape.circle),
                      child: const Icon(Icons.check, color: Colors.white, size: 28),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(S.tr('room_join_success_text'), style: AppTextStyles.bodyBold),
                  ],
                )
              : Column(
                  key: const ValueKey('loading'),
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      width: 30,
                      height: 30,
                      child: CircularProgressIndicator(strokeWidth: 3, color: AppColors.primary),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(S.tr('room_join_loading_text'), style: AppTextStyles.bodyBold),
                  ],
                ),
        ),
      ),
    );
  }
}

/// نافذة نتيجة عامة (تُستعمل لحالة الخطأ: روم خاص) — زر أساسي اختياري + إغلاق
Future<void> _showJoinResultDialog(
  BuildContext context, {
  required IconData icon,
  required Color iconBackground,
  required String title,
  required String message,
  String? primaryLabel,
  VoidCallback? onPrimary,
}) {
  return showDialog(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.lg)),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(color: iconBackground, shape: BoxShape.circle),
              child: Icon(icon, color: Colors.white, size: 26),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(title, style: AppTextStyles.bodyBold, textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(message, style: AppTextStyles.caption, textAlign: TextAlign.center),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: Text(S.tr('ok')),
                  ),
                ),
                if (primaryLabel != null) ...[
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(ctx);
                        onPrimary?.call();
                      },
                      child: Text(primaryLabel),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
