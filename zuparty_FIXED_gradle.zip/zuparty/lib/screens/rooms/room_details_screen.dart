import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../routing/app_page_route.dart';
import '../../theme/app_theme.dart';
import '../../l10n/app_strings.dart';
import 'room_preview_screen.dart';
import 'room_shared_widgets.dart';

/// ============================================================
/// شاشة "تفاصيل الغرفة" (Room Details) — Phase 3 Part 2
/// معلومات كاملة عن الروم قبل الدخول: الغلاف، الاسم، المعرّف،
/// صاحب الروم، عدد المتصلين، التصنيف، الوصف، الإعلان، الوسوم،
/// وحالة الروم. زر "معاينة ودخول" كيودّي لـ Room Preview، ومن تما
/// للدخول الفعلي للروم (LiveRoomScreen الموجودة فعليًا).
/// ============================================================
class RoomDetailsScreen extends StatelessWidget {
  final RoomModel room;
  final void Function(RoomModel room) onOpenRoom;

  const RoomDetailsScreen({super.key, required this.room, required this.onOpenRoom});

  List<String> get _tags {
    final tags = <String>[];
    if (room.isPopular) tags.add(S.tr('room_details_tag_popular'));
    if (room.isRecommended) tags.add(S.tr('room_details_tag_recommended'));
    if (room.isNew) tags.add(S.tr('room_details_tag_new'));
    if (room.category != null) tags.add(room.category!);
    tags.add(room.isRoomLocked ? S.tr('room_details_tag_private') : S.tr('room_details_tag_public'));
    return tags;
  }

  void _openPreview(BuildContext context) {
    Navigator.push(
      context,
      appPageRoute(builder: (_) => RoomPreviewScreen(room: room, onOpenRoom: onOpenRoom)),
    );
  }

  void _openOptionsMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return SafeArea(
          child: Container(
            margin: const EdgeInsets.all(AppSpacing.md),
            padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.link, color: AppColors.textSecondary),
                  title: Text(S.tr('room_details_menu_copy_link')),
                  onTap: () {
                    Navigator.pop(ctx);
                    showRoomMockFeedback(context, S.tr('copy_room_link_toast'));
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.flag_outlined, color: AppColors.textSecondary),
                  title: Text(S.tr('room_details_menu_report')),
                  onTap: () {
                    Navigator.pop(ctx);
                    showRoomMockFeedback(context, S.tr('room_details_report_toast'));
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.block_outlined, color: AppColors.danger),
                  title: Text(S.tr('room_details_menu_block'), style: const TextStyle(color: AppColors.danger)),
                  onTap: () {
                    Navigator.pop(ctx);
                    showRoomMockFeedback(context, S.tr('room_details_block_toast'));
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 220,
            backgroundColor: AppColors.surface,
            leading: Padding(
              padding: const EdgeInsets.all(8),
              child: _AppBarCircleButton(
                icon: Icons.arrow_forward,
                onTap: () => Navigator.pop(context),
              ),
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.only(left: AppSpacing.sm),
                child: _AppBarCircleButton(
                  icon: Icons.more_vert,
                  onTap: () => _openOptionsMenu(context),
                ),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: GestureDetector(
                onTap: () => _openPreview(context),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      room.imagePath ?? 'assets/images/room_bg_official.webp',
                      fit: BoxFit.cover,
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.black.withOpacity(0.05), Colors.black.withOpacity(0.65)],
                        ),
                      ),
                    ),
                    Positioned(
                      left: AppSpacing.lg,
                      right: AppSpacing.lg,
                      bottom: AppSpacing.lg,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  room.name,
                                  style: AppTextStyles.h1.copyWith(color: Colors.white),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (room.isRoomLocked)
                                const Padding(
                                  padding: EdgeInsets.only(right: 6),
                                  child: Icon(Icons.lock_outline, color: Colors.white, size: 20),
                                ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text('ID: ${room.roomCode ?? room.id ?? '—'}', style: AppTextStyles.body.copyWith(color: Colors.white70)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, 120),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      RoomStatusBadge(onlineCount: room.onlineCount),
                      const Spacer(),
                      RoomTagChip(
                        icon: Icons.people_alt_outlined,
                        label: S.trParams('room_online_count_template', {'count': '${room.onlineCount}'}),
                        background: AppColors.primaryLight,
                        foreground: AppColors.primary,
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Wrap(spacing: 8, runSpacing: 8, children: _tags.map((t) => RoomTagChip(label: t)).toList()),

                  const SizedBox(height: AppSpacing.lg),
                  RoomInfoSection(
                    title: S.tr('room_owner_title'),
                    child: Row(
                      children: [
                        RoomAvatarCircle(
                          imagePath: room.ownerAvatarPath ?? 'assets/images/profile.png',
                          fallbackText: room.ownerName ?? '?',
                          size: 46,
                          borderColor: AppColors.border,
                        ),
                        const SizedBox(width: AppSpacing.md),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(room.ownerName ?? S.tr('unknown_owner'), style: AppTextStyles.bodyBold),
                              const SizedBox(height: 2),
                              Text(S.tr('room_owner_label'), style: AppTextStyles.caption),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppSpacing.md),
                  RoomInfoSection(
                    title: S.tr('room_details_description_title'),
                    child: Text(
                      room.description.trim().isNotEmpty ? room.description : S.tr('room_details_no_description'),
                      style: AppTextStyles.body,
                    ),
                  ),

                  if (room.announcement.trim().isNotEmpty) ...[
                    const SizedBox(height: AppSpacing.md),
                    RoomInfoSection(
                      title: S.tr('room_announcement_title'),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.campaign_outlined, size: 18, color: AppColors.primary),
                          const SizedBox(width: 8),
                          Expanded(child: Text(room.announcement, style: AppTextStyles.body)),
                        ],
                      ),
                    ),
                  ],

                  const SizedBox(height: AppSpacing.md),
                  RoomInfoSection(
                    title: S.tr('room_details_quick_actions_title'),
                    child: Row(
                      children: [
                        Expanded(
                          child: RoomActionButton(
                            icon: Icons.share_outlined,
                            label: S.tr('share'),
                            onTap: () => showRoomMockFeedback(context, S.tr('copy_room_link_toast')),
                          ),
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: RoomActionButton(
                            icon: Icons.person_add_alt_1_outlined,
                            label: S.tr('invite'),
                            onTap: () => showRoomMockFeedback(context, S.tr('invite_sent_toast')),
                          ),
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: RoomActionButton(
                            icon: Icons.visibility_outlined,
                            label: S.tr('preview'),
                            onTap: () => _openPreview(context),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.md),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, -3))],
          ),
          child: SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: () => _openPreview(context),
              icon: const Icon(Icons.login_rounded, size: 20),
              label: Text(S.tr('room_details_join_button')),
            ),
          ),
        ),
      ),
    );
  }
}

/// زر دائري بخلفية داكنة شفافة — يبقى واضح فوق الغلاف وفوق شريط العنوان
/// المصغّر بعد التمرير (بلا مشاكل تباين ألوان)
class _AppBarCircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _AppBarCircleButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withOpacity(0.35),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(9),
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }
}
