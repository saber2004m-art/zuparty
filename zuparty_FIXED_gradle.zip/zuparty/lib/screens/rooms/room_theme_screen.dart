import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../theme/app_theme.dart';
import '../../l10n/app_strings.dart';
import 'room_shared_widgets.dart';

/// ============================================================
/// Zuparty — Phase 4 Part 3/3: Room Theme (ثيم الروم)
/// ------------------------------------------------------------
/// اختيار خلفية الروم + لون تأثير التحدث حول المقاعد، مع معاينة
/// حيّة قبل "تطبيق" فعلي. UI/Local State + Mock Data فقط.
/// كيستعمل نفس الـ Assets الموجودة (kRoomCoverOptions) ونفس
/// ألوان التأثير الموجودة (kRoomEffectColors) — بلا أي إضافة جديدة.
/// ============================================================
class RoomThemeScreen extends StatefulWidget {
  final RoomModel room;
  final VoidCallback? onChanged;
  const RoomThemeScreen({super.key, required this.room, this.onChanged});

  @override
  State<RoomThemeScreen> createState() => _RoomThemeScreenState();
}

class _RoomThemeScreenState extends State<RoomThemeScreen> {
  late String? _selectedCover;
  late int _selectedEffectIndex;
  late final String? _initialCover;
  late final int _initialEffectIndex;

  @override
  void initState() {
    super.initState();
    _selectedCover = widget.room.imagePath ?? kRoomCoverOptions.first;
    _selectedEffectIndex = widget.room.effectIndex;
    _initialCover = widget.room.imagePath;
    _initialEffectIndex = widget.room.effectIndex;
  }

  bool get _dirty => _selectedCover != (_initialCover ?? kRoomCoverOptions.first) || _selectedEffectIndex != _initialEffectIndex;

  void _apply() {
    setState(() {
      widget.room.imagePath = _selectedCover;
      widget.room.effectIndex = _selectedEffectIndex;
    });
    widget.onChanged?.call();
    showRoomMockFeedback(context, S.tr('room_theme_applied_toast'));
  }

  void _reset() {
    setState(() {
      _selectedCover = _initialCover ?? kRoomCoverOptions.first;
      _selectedEffectIndex = _initialEffectIndex;
    });
    showRoomMockFeedback(context, S.tr('room_theme_reset_toast'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: Text(S.tr('room_theme_title')),
        actions: [
          TextButton(onPressed: _dirty ? _reset : null, child: Text(S.tr('reset'))),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          // ---- معاينة حيّة ----
          ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.lg),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(_selectedCover ?? kRoomCoverOptions.first, fit: BoxFit.cover),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.black.withOpacity(0.05), Colors.black.withOpacity(0.55)],
                      ),
                    ),
                  ),
                  Center(
                    child: Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: kRoomEffectColors[_selectedEffectIndex], width: 3),
                        boxShadow: [BoxShadow(color: kRoomEffectColors[_selectedEffectIndex].withOpacity(0.6), blurRadius: 14, spreadRadius: 1)],
                      ),
                      child: const Icon(Icons.person_rounded, color: Colors.white, size: 30),
                    ),
                  ),
                  Positioned(
                    bottom: 8,
                    right: 10,
                    child: Text(S.tr('preview'), style: AppTextStyles.caption.copyWith(color: Colors.white70)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.xl),
          Text(S.tr('room_theme_background'), style: AppTextStyles.h3),
          const SizedBox(height: AppSpacing.md),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: kRoomCoverOptions.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: AppSpacing.md,
              mainAxisSpacing: AppSpacing.md,
              childAspectRatio: 1.5,
            ),
            itemBuilder: (context, i) {
              final cover = kRoomCoverOptions[i];
              final selected = cover == _selectedCover;
              return GestureDetector(
                onTap: () => setState(() => _selectedCover = cover),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(AppRadius.md),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(cover, fit: BoxFit.cover),
                      if (selected)
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.primary, width: 3),
                            borderRadius: BorderRadius.circular(AppRadius.md),
                            color: Colors.black.withOpacity(0.15),
                          ),
                          child: const Center(
                            child: Icon(Icons.check_circle_rounded, color: Colors.white, size: 26),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: AppSpacing.xl),
          Text(S.tr('room_theme_speaking_color'), style: AppTextStyles.h3),
          const SizedBox(height: AppSpacing.md),
          Wrap(
            spacing: AppSpacing.md,
            runSpacing: AppSpacing.md,
            children: List.generate(kRoomEffectColors.length, (i) {
              final selected = i == _selectedEffectIndex;
              return GestureDetector(
                onTap: () => setState(() => _selectedEffectIndex = i),
                child: Column(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kRoomEffectColors[i],
                        border: selected ? Border.all(color: AppColors.textPrimary, width: 2.5) : null,
                        boxShadow: selected ? [BoxShadow(color: kRoomEffectColors[i].withOpacity(0.5), blurRadius: 8)] : null,
                      ),
                      child: selected ? const Icon(Icons.check_rounded, color: Colors.white) : null,
                    ),
                    const SizedBox(height: 4),
                    Text(kRoomEffectNames[i], style: AppTextStyles.caption),
                  ],
                ),
              );
            }),
          ),
          const SizedBox(height: AppSpacing.xxxl),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _dirty ? _apply : null,
              child: Text(S.tr('room_theme_apply')),
            ),
          ),
          const SizedBox(height: AppSpacing.xxl),
        ],
      ),
    );
  }
}
