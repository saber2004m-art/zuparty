import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../l10n/app_strings.dart';
import 'room_shared_widgets.dart';

/// ============================================================
/// Zuparty — Phase 4 Part 3/3: Room Ranking (ترتيب الروم)
/// ------------------------------------------------------------
/// ترتيب أسبوعي + أفضل المساهمين بالهدايا. Mock Data فقط
/// (MockData.roomWeeklyRanking / MockData.roomTopContributors).
/// ============================================================
class RoomRankingScreen extends StatefulWidget {
  final String roomName;
  const RoomRankingScreen({super.key, required this.roomName});

  @override
  State<RoomRankingScreen> createState() => _RoomRankingScreenState();
}

enum _RankLoadState { loading, loaded, empty }

class _RoomRankingScreenState extends State<RoomRankingScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  _RankLoadState _state = _RankLoadState.loading;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    Future.delayed(const Duration(milliseconds: 500), () {
      if (!mounted) return;
      setState(() => _state = _RankLoadState.loaded);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: Text('${S.tr('room_ranking_title')} "${widget.roomName}"'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          indicatorColor: AppColors.primary,
          tabs: [
            Tab(text: S.tr('room_ranking_weekly')),
            Tab(text: S.tr('room_ranking_top_contributors')),
          ],
        ),
      ),
      body: _state == _RankLoadState.loading
          ? AppLoading(message: S.tr('room_ranking_loading'))
          : TabBarView(
              controller: _tabController,
              children: [
                _RankingList(entries: MockData.roomWeeklyRanking, unit: S.tr('room_ranking_unit_point')),
                _RankingList(entries: MockData.roomTopContributors, unit: S.tr('room_ranking_unit_coins')),
              ],
            ),
    );
  }
}

class _RankingList extends StatelessWidget {
  final List<RankingEntry> entries;
  final String unit;
  const _RankingList({required this.entries, required this.unit});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return AppEmptyState(
        icon: Icons.emoji_events_outlined,
        title: S.tr('room_ranking_empty_title'),
        subtitle: S.tr('room_ranking_empty_subtitle'),
      );
    }
    final top3 = entries.take(3).toList();
    final rest = entries.length > 3 ? entries.sublist(3) : <RankingEntry>[];

    return ListView(
      padding: const EdgeInsets.all(AppSpacing.lg),
      children: [
        _Podium(top3: top3, unit: unit),
        const SizedBox(height: AppSpacing.xl),
        ...rest.map((e) => _RankRow(entry: e, unit: unit)),
      ],
    );
  }
}

class _Podium extends StatelessWidget {
  final List<RankingEntry> top3;
  final String unit;
  const _Podium({required this.top3, required this.unit});

  RankingEntry? _at(int rank) {
    for (final e in top3) {
      if (e.rank == rank) return e;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final first = _at(1);
    final second = _at(2);
    final third = _at(3);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(child: second != null ? _PodiumSlot(entry: second, height: 88, color: AppColors.grey400, unit: unit) : const SizedBox()),
        const SizedBox(width: AppSpacing.sm),
        Expanded(child: first != null ? _PodiumSlot(entry: first, height: 112, color: const Color(0xFFFFC107), unit: unit, crown: true) : const SizedBox()),
        const SizedBox(width: AppSpacing.sm),
        Expanded(child: third != null ? _PodiumSlot(entry: third, height: 72, color: const Color(0xFFCD7F32), unit: unit) : const SizedBox()),
      ],
    );
  }
}

class _PodiumSlot extends StatelessWidget {
  final RankingEntry entry;
  final double height;
  final Color color;
  final String unit;
  final bool crown;
  const _PodiumSlot({required this.entry, required this.height, required this.color, required this.unit, this.crown = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (crown) const Icon(Icons.emoji_events_rounded, color: Color(0xFFFFC107), size: 22),
        Stack(
          clipBehavior: Clip.none,
          children: [
            RoomAvatarCircle(imagePath: entry.avatarPath, fallbackText: entry.userName, size: 52, borderColor: color),
            Positioned(
              bottom: -4,
              right: 0,
              left: 0,
              child: Center(
                child: Container(
                  width: 20,
                  height: 20,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1.5)),
                  child: Text('${entry.rank}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.sm),
        Text(entry.userName, style: AppTextStyles.bodyBold, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center),
        Text('${entry.score} $unit', style: AppTextStyles.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
        const SizedBox(height: AppSpacing.sm),
        Container(
          height: height,
          decoration: BoxDecoration(
            color: color.withOpacity(0.18),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadius.sm)),
            border: Border.all(color: color.withOpacity(0.4)),
          ),
        ),
      ],
    );
  }
}

class _RankRow extends StatelessWidget {
  final RankingEntry entry;
  final String unit;
  const _RankRow({required this.entry, required this.unit});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadius.md),
        boxShadow: AppShadows.card,
      ),
      child: Row(
        children: [
          SizedBox(
            width: 24,
            child: Text('${entry.rank}', style: AppTextStyles.bodyBold.copyWith(color: AppColors.textSecondary), textAlign: TextAlign.center),
          ),
          const SizedBox(width: AppSpacing.sm),
          RoomAvatarCircle(imagePath: entry.avatarPath, fallbackText: entry.userName, size: 38, borderColor: AppColors.border),
          const SizedBox(width: AppSpacing.sm),
          Expanded(child: Text(entry.userName, style: AppTextStyles.bodyBold, maxLines: 1, overflow: TextOverflow.ellipsis)),
          Text('${entry.score} $unit', style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
