import 'dart:async';
import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../data/mock_data.dart';
import '../../data/models.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import '../../widgets/app_states.dart';
import '../../routing/app_page_route.dart';
import '../rankings/rankings_screen.dart' show RankListTile;

/// ============================================================
/// Phase 5 — Part 3/3: مركز الفعاليات (Events Center)
/// بانرات + تفاصيل + مهام + جوائز + ترتيب + Countdown + مشاركة
/// كلها Local State / Mock Data.
/// ============================================================
class EventsCenterScreen extends StatefulWidget {
  const EventsCenterScreen({super.key});

  @override
  State<EventsCenterScreen> createState() => _EventsCenterScreenState();
}

class _EventsCenterScreenState extends State<EventsCenterScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 2, vsync: this);
  late List<EventItem> _events = List.of(MockData.eventsDetailed);

  List<EventItem> get _ongoing => _events.where((e) => e.startDate.isBefore(DateTime.now())).toList();
  List<EventItem> get _upcoming => _events.where((e) => e.startDate.isAfter(DateTime.now())).toList();

  void _openDetails(EventItem e) async {
    final updated = await Navigator.push<EventItem>(context, appPageRoute(builder: (_) => EventDetailsScreen(event: e)));
    if (updated != null) {
      setState(() {
        final idx = _events.indexWhere((x) => x.id == updated.id);
        if (idx != -1) _events[idx] = updated;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: Text(S.tr('events_title'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.grey500,
          indicatorColor: AppColors.primary,
          tabs: [Tab(text: S.tr('events_ongoing')), Tab(text: S.tr('events_upcoming'))],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _EventList(events: _ongoing, onTap: _openDetails),
          _EventList(events: _upcoming, onTap: _openDetails),
        ],
      ),
    );
  }
}

class _EventList extends StatelessWidget {
  final List<EventItem> events;
  final ValueChanged<EventItem> onTap;
  const _EventList({required this.events, required this.onTap});

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) {
      return AppEmptyState(icon: Icons.celebration_outlined, title: S.tr('events_empty'));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: events.length,
      separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.md),
      itemBuilder: (context, i) => _EventBanner(event: events[i], onTap: () => onTap(events[i])),
    );
  }
}

/// كرت/بانر فعالية مع Countdown حي
class _EventBanner extends StatefulWidget {
  final EventItem event;
  final VoidCallback onTap;
  const _EventBanner({required this.event, required this.onTap});

  @override
  State<_EventBanner> createState() => _EventBannerState();
}

class _EventBannerState extends State<_EventBanner> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _countdownLabel() {
    final d = widget.event.remaining;
    if (d.isNegative) return '--';
    if (d.inDays > 0) return '${d.inDays}${S.tr('events_ends_in') == 'Ends in' ? 'd' : 'ي'}';
    if (d.inHours > 0) return '${d.inHours}${S.tr('events_ends_in') == 'Ends in' ? 'h' : 'س'}';
    return '${d.inMinutes}${S.tr('events_ends_in') == 'Ends in' ? 'm' : 'د'}';
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.event;
    final completedTasks = e.tasks.where((t) => t.status == EventTaskStatus.completed || t.status == EventTaskStatus.claimed).length;
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [AppColors.primary, AppColors.primaryDark]),
          borderRadius: BorderRadius.circular(AppRadius.xl),
          boxShadow: AppShadows.card,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(e.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15.5)),
                ),
                if (e.badgeLabel.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(AppRadius.pill)),
                    child: Text(e.badgeLabel, style: const TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700)),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(e.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                Icon(Icons.timer_outlined, size: 14, color: Colors.white.withOpacity(0.85)),
                const SizedBox(width: 4),
                Text('${S.tr('events_ends_in')} ${_countdownLabel()}', style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w600)),
                const Spacer(),
                if (e.tasks.isNotEmpty)
                  Text('$completedTasks/${e.tasks.length} ${S.tr('events_tasks')}', style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.16), borderRadius: BorderRadius.circular(AppRadius.md)),
              alignment: Alignment.center,
              child: Text(
                e.isJoined ? S.tr('events_joined') : S.tr('events_join'),
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// شاشة تفاصيل فعالية: مهام + جوائز + ترتيب + مشاركة
class EventDetailsScreen extends StatefulWidget {
  final EventItem event;
  const EventDetailsScreen({super.key, required this.event});

  @override
  State<EventDetailsScreen> createState() => _EventDetailsScreenState();
}

class _EventDetailsScreenState extends State<EventDetailsScreen> {
  late EventItem _event = widget.event;

  void _toggleJoin() {
    setState(() {
      _event = EventItem(
        id: _event.id,
        title: _event.title,
        description: _event.description,
        imagePath: _event.imagePath,
        startDate: _event.startDate,
        endDate: _event.endDate,
        tasks: _event.tasks,
        ranking: _event.ranking,
        isJoined: !_event.isJoined,
        badgeLabel: _event.badgeLabel,
      );
    });
    zpToast(context, _event.isJoined ? S.tr('events_joined') : S.tr('events_title'));
  }

  void _claimTask(EventTask task) {
    if (task.status != EventTaskStatus.completed) return;
    setState(() {
      final newTasks = _event.tasks.map((t) => t.id == task.id
          ? EventTask(id: t.id, title: t.title, targetValue: t.targetValue, currentValue: t.currentValue, rewardLabel: t.rewardLabel, status: EventTaskStatus.claimed)
          : t).toList();
      _event = EventItem(
        id: _event.id, title: _event.title, description: _event.description, imagePath: _event.imagePath,
        startDate: _event.startDate, endDate: _event.endDate, tasks: newTasks, ranking: _event.ranking,
        isJoined: _event.isJoined, badgeLabel: _event.badgeLabel,
      );
    });
    zpToast(context, '${S.tr('events_claim')}: ${task.rewardLabel}', icon: Icons.card_giftcard_rounded);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, _event);
        return false;
      },
      child: Scaffold(
        backgroundColor: AppColors.surface,
        appBar: zpAppBar(_event.title),
        body: ListView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          children: [
            Container(
              padding: const EdgeInsets.all(AppSpacing.lg),
              decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_event.description, style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.5)),
                  const SizedBox(height: AppSpacing.md),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _toggleJoin,
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppColors.primaryDark),
                      child: Text(_event.isJoined ? S.tr('events_joined') : S.tr('events_join')),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(S.tr('events_tasks'), style: AppTextStyles.h3),
            const SizedBox(height: AppSpacing.sm),
            if (_event.tasks.isEmpty)
              AppEmptyState(icon: Icons.checklist_rounded, title: S.tr('events_empty'))
            else
              ..._event.tasks.map((t) => _TaskRow(task: t, onClaim: () => _claimTask(t))),
            const SizedBox(height: AppSpacing.xl),
            Text(S.tr('events_ranking'), style: AppTextStyles.h3),
            const SizedBox(height: AppSpacing.sm),
            if (_event.ranking.isEmpty)
              AppEmptyState(icon: Icons.emoji_events_outlined, title: S.tr('rankings_empty'))
            else
              ..._event.ranking.take(10).map((r) => RankListTile(entry: r)),
          ],
        ),
      ),
    );
  }
}

class _TaskRow extends StatelessWidget {
  final EventTask task;
  final VoidCallback onClaim;
  const _TaskRow({required this.task, required this.onClaim});

  @override
  Widget build(BuildContext context) {
    final progress = task.targetValue == 0 ? 0.0 : (task.currentValue / task.targetValue).clamp(0.0, 1.0);
    final isLocked = task.status == EventTaskStatus.locked;
    final isClaimed = task.status == EventTaskStatus.claimed;
    final isCompleted = task.status == EventTaskStatus.completed;

    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
      child: Opacity(
        opacity: isLocked ? 0.5 : 1,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(task.title, style: AppTextStyles.bodyBold)),
                Text(task.rewardLabel, style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.pill),
              child: LinearProgressIndicator(value: progress, minHeight: 6, backgroundColor: AppColors.grey200, color: AppColors.primary),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text('${task.currentValue}/${task.targetValue}', style: AppTextStyles.caption),
                const Spacer(),
                if (isLocked)
                  Text(S.tr('events_locked'), style: AppTextStyles.caption)
                else if (isClaimed)
                  Text(S.tr('events_claimed'), style: const TextStyle(color: AppColors.success, fontSize: 12, fontWeight: FontWeight.w700))
                else
                  GestureDetector(
                    onTap: isCompleted ? onClaim : null,
                    child: ZpPill(
                      label: S.tr('events_claim'),
                      color: isCompleted ? AppColors.primary : AppColors.grey200,
                      textColor: isCompleted ? Colors.white : AppColors.grey500,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
