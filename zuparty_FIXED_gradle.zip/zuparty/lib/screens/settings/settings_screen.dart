import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../data/locale_controller.dart';
import '../../routing/app_page_route.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';

/// ============================================================
/// Phase 5 — Part 3/3: مجموعة شاشات الإعدادات الكاملة
/// حساب / خصوصية / أمان / إشعارات / صوت / لغة / مظهر /
/// محظورون / خدمة عملاء / حول التطبيق / تسجيل خروج.
/// Local State + Mock Data فقط — بلا Backend.
/// ============================================================

// ================= SETTINGS HUB =================
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _confirmLogout(BuildContext context) async {
    final ok = await zpConfirmSheet(
      context,
      title: S.tr('settings_logout'),
      message: S.tr('settings_logout_confirm'),
      confirmLabel: S.tr('settings_logout'),
      icon: Icons.logout_rounded,
      color: AppColors.danger,
    );
    if (ok && context.mounted) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: zpAppBar(S.tr('settings_title')),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          _SettingsGroup(children: [
            _SettingsTile(
              icon: Icons.person_outline_rounded,
              label: S.tr('settings_account'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const AccountSettingsScreen())),
            ),
            _SettingsTile(
              icon: Icons.lock_outline_rounded,
              label: S.tr('settings_privacy'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const PrivacyScreen())),
            ),
            _SettingsTile(
              icon: Icons.security_rounded,
              label: S.tr('settings_security'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const SecurityScreen())),
            ),
          ]),
          const SizedBox(height: AppSpacing.lg),
          _SettingsGroup(children: [
            _SettingsTile(
              icon: Icons.notifications_none_rounded,
              label: S.tr('settings_notifications'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const NotificationSettingsScreen())),
            ),
            _SettingsTile(
              icon: Icons.volume_up_outlined,
              label: S.tr('settings_sound'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const SoundScreen())),
            ),
            _SettingsTile(
              icon: Icons.language_rounded,
              label: S.tr('settings_language'),
              trailingValue: LocaleController.supportedLanguages[LocaleController.languageCode.value],
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const LanguageScreen())),
            ),
            _SettingsTile(
              icon: Icons.dark_mode_outlined,
              label: S.tr('settings_appearance'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const AppearanceScreen())),
            ),
          ]),
          const SizedBox(height: AppSpacing.lg),
          _SettingsGroup(children: [
            _SettingsTile(
              icon: Icons.block_rounded,
              label: S.tr('settings_blocked'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const BlockedUsersScreen())),
            ),
            _SettingsTile(
              icon: Icons.support_agent_rounded,
              label: S.tr('settings_support'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const SupportScreen())),
            ),
            _SettingsTile(
              icon: Icons.info_outline_rounded,
              label: S.tr('settings_about'),
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const AboutScreen())),
            ),
          ]),
          const SizedBox(height: AppSpacing.xl),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => _confirmLogout(context),
              style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger, side: const BorderSide(color: AppColors.danger), padding: const EdgeInsets.symmetric(vertical: 13)),
              icon: const Icon(Icons.logout_rounded, size: 18),
              label: Text(S.tr('settings_logout')),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          Center(child: Text('${S.tr('settings_version')} 1.0.0', style: AppTextStyles.caption)),
        ],
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  final List<Widget> children;
  const _SettingsGroup({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
      child: Column(
        children: List.generate(children.length, (i) {
          return Column(children: [
            children[i],
            if (i != children.length - 1) const Divider(height: 1, indent: 56, color: AppColors.divider),
          ]);
        }),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? trailingValue;
  final VoidCallback onTap;
  const _SettingsTile({required this.icon, required this.label, this.trailingValue, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: AppColors.primary, size: 21),
      title: Text(label, style: AppTextStyles.body),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailingValue != null) ...[
            Text(trailingValue!, style: AppTextStyles.caption),
            const SizedBox(width: 4),
          ],
          const Icon(Icons.chevron_left, color: AppColors.grey400, size: 20),
        ],
      ),
    );
  }
}

/// صف بسيط بمفتاح تبديل (Switch) — لاستعمال موحّد فكل شاشات الإعدادات
class _SwitchRow extends StatelessWidget {
  final String label;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchRow({required this.label, this.subtitle, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      value: value,
      onChanged: onChanged,
      activeColor: AppColors.primary,
      contentPadding: EdgeInsets.zero,
      title: Text(label, style: AppTextStyles.body),
      subtitle: subtitle != null ? Text(subtitle!, style: AppTextStyles.caption) : null,
    );
  }
}

// ================= ACCOUNT =================
class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({super.key});

  void _showLinkAccountOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl))),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: AppSpacing.md),
              Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
              const SizedBox(height: AppSpacing.sm),
              ListTile(
                leading: const Icon(Icons.email_outlined),
                title: const Text('ربط بالبريد الإلكتروني', textAlign: TextAlign.right),
                onTap: () {
                  Navigator.pop(ctx);
                  zpToast(context, 'ربط بالبريد الإلكتروني: ${S.tr('coming_soon')}', icon: Icons.info_outline_rounded, color: AppColors.info);
                },
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.phone_outlined),
                title: const Text('ربط برقم الهاتف', textAlign: TextAlign.right),
                onTap: () {
                  Navigator.pop(ctx);
                  zpToast(context, 'ربط برقم الهاتف: ${S.tr('coming_soon')}', icon: Icons.info_outline_rounded, color: AppColors.info);
                },
              ),
              const SizedBox(height: AppSpacing.md),
            ],
          ),
        );
      },
    );
  }

  Future<void> _confirmDeleteAccount(BuildContext context) async {
    final ok = await zpConfirmSheet(
      context,
      title: 'حذف الحساب',
      message: 'هل أنت متأكد؟ بعد حذف الحساب سيتم إتلاف جميع البيانات ولا يمكن التراجع، يرجى العمل بحذر.',
      confirmLabel: 'تأكيد الحذف',
      icon: Icons.person_remove_alt_1_rounded,
      color: AppColors.danger,
    );
    if (ok && context.mounted) {
      zpToast(context, 'تم حذف الحساب (محاكاة محلية فقط)', icon: Icons.check_circle_rounded, color: AppColors.success);
    }
  }

  Widget _row(BuildContext context, {required IconData icon, required String label, String? trailingValue, VoidCallback? onTap}) {
    return InkWell(
      onTap: onTap ?? () => zpToast(context, '$label: ${S.tr('coming_soon')}', icon: Icons.info_outline_rounded, color: AppColors.info),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Row(
          children: [
            Icon(icon, size: 21, color: AppColors.grey700),
            const SizedBox(width: 14),
            if (trailingValue != null) ...[
              Text(trailingValue, style: AppTextStyles.caption.copyWith(color: AppColors.grey400)),
              const SizedBox(width: 8),
            ],
            Text(label, style: AppTextStyles.body),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_account')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: AppSpacing.sm),
            _row(context, icon: Icons.verified_user_outlined, label: 'ربط الحساب', onTap: () => _showLinkAccountOptions(context)),
            _row(context, icon: Icons.checkroom_outlined, label: 'جلد APP'),
            _row(context, icon: Icons.delete_sweep_outlined, label: 'مسح ذاكرة التخزين المؤقت', trailingValue: '0M'),
            _row(
              context,
              icon: Icons.article_outlined,
              label: 'سياسة البرنامج',
              onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const PolicyScreen())),
            ),
            _row(context, icon: Icons.error_outline, label: 'النسخة الحالية', trailingValue: '1.0.0'),
            _row(context, icon: Icons.person_remove_outlined, label: 'حذف الحساب', onTap: () => _confirmDeleteAccount(context)),
            _row(context, icon: Icons.ios_share_outlined, label: 'تحميل السجل'),
            const SizedBox(height: AppSpacing.sm),
            const Divider(color: AppColors.divider),
            const SizedBox(height: AppSpacing.lg),
          ],
        ),
      ),
    );
  }
}

// ================= PRIVACY =================
class PrivacyScreen extends StatefulWidget {
  const PrivacyScreen({super.key});
  @override
  State<PrivacyScreen> createState() => _PrivacyScreenState();
}

class _PrivacyScreenState extends State<PrivacyScreen> {
  bool _privateAccount = false;
  bool _showOnline = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_privacy')),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        children: [
          _SwitchRow(label: S.tr('settings_private_account'), value: _privateAccount, onChanged: (v) => setState(() => _privateAccount = v)),
          const Divider(height: 1, color: AppColors.divider),
          _SwitchRow(label: S.tr('settings_show_online'), value: _showOnline, onChanged: (v) => setState(() => _showOnline = v)),
          const Divider(height: 1, color: AppColors.divider),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.block_rounded, color: AppColors.grey700),
            title: Text(S.tr('settings_blocked'), style: AppTextStyles.body),
            trailing: const Icon(Icons.chevron_left, color: AppColors.grey400),
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const BlockedUsersScreen())),
          ),
        ],
      ),
    );
  }
}

// ================= SECURITY =================
class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});
  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> {
  bool _twoFactor = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_security')),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.password_rounded, color: AppColors.grey700),
            title: Text(S.tr('settings_change_password'), style: AppTextStyles.body),
            trailing: const Icon(Icons.chevron_left, color: AppColors.grey400),
            onTap: () => zpToast(context, S.tr('coming_soon'), icon: Icons.info_outline_rounded, color: AppColors.info),
          ),
          const Divider(height: 1, color: AppColors.divider),
          _SwitchRow(label: S.tr('settings_two_factor'), value: _twoFactor, onChanged: (v) => setState(() => _twoFactor = v)),
        ],
      ),
    );
  }
}

// ================= NOTIFICATION SETTINGS =================
class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});
  @override
  State<NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  bool _push = true;
  bool _muted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_notifications')),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        children: [
          _SwitchRow(label: S.tr('settings_push'), value: _push, onChanged: (v) => setState(() => _push = v)),
          const Divider(height: 1, color: AppColors.divider),
          _SwitchRow(label: S.tr('settings_muted'), value: _muted, onChanged: (v) => setState(() => _muted = v)),
        ],
      ),
    );
  }
}

// ================= SOUND =================
class SoundScreen extends StatefulWidget {
  const SoundScreen({super.key});
  @override
  State<SoundScreen> createState() => _SoundScreenState();
}

class _SoundScreenState extends State<SoundScreen> {
  double _effectsVolume = 0.7;
  double _giftVolume = 0.8;
  bool _vibration = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_sound')),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        children: [
          const SizedBox(height: AppSpacing.sm),
          Text('أصوات المؤثرات', style: AppTextStyles.caption),
          Slider(value: _effectsVolume, activeColor: AppColors.primary, onChanged: (v) => setState(() => _effectsVolume = v)),
          Text('أصوات الهدايا', style: AppTextStyles.caption),
          Slider(value: _giftVolume, activeColor: AppColors.primary, onChanged: (v) => setState(() => _giftVolume = v)),
          const Divider(height: 1, color: AppColors.divider),
          _SwitchRow(label: 'الاهتزاز', value: _vibration, onChanged: (v) => setState(() => _vibration = v)),
        ],
      ),
    );
  }
}

// ================= LANGUAGE =================
class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_language')),
      body: ValueListenableBuilder<String>(
        valueListenable: LocaleController.languageCode,
        builder: (context, current, _) {
          return ListView(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
            children: LocaleController.supportedLanguages.entries.map((e) {
              final selected = e.key == current;
              return ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(e.value, style: AppTextStyles.body),
                trailing: selected ? const Icon(Icons.check_circle_rounded, color: AppColors.primary) : null,
                onTap: () => LocaleController.setLanguage(e.key),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

// ================= APPEARANCE =================
class AppearanceScreen extends StatefulWidget {
  const AppearanceScreen({super.key});
  @override
  State<AppearanceScreen> createState() => _AppearanceScreenState();
}

class _AppearanceScreenState extends State<AppearanceScreen> {
  bool _darkMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_appearance')),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        children: [
          _SwitchRow(
            label: S.tr('settings_dark_mode'),
            subtitle: S.tr('coming_soon'),
            value: _darkMode,
            onChanged: (v) => setState(() => _darkMode = v),
          ),
        ],
      ),
    );
  }
}

// ================= BLOCKED USERS =================
class BlockedUsersScreen extends StatefulWidget {
  const BlockedUsersScreen({super.key});
  @override
  State<BlockedUsersScreen> createState() => _BlockedUsersScreenState();
}

class _BlockedUsersScreenState extends State<BlockedUsersScreen> {
  late List<UserModel> _blocked = List.of(MockData.blockedUsers);

  Future<void> _unblock(UserModel u) async {
    final ok = await zpConfirmSheet(
      context,
      title: S.tr('friends_unblock'),
      message: u.name,
      confirmLabel: S.tr('friends_unblock'),
      icon: Icons.person_off_outlined,
      color: AppColors.primary,
    );
    if (ok) setState(() => _blocked.removeWhere((x) => x.id == u.id));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_blocked')),
      body: _blocked.isEmpty
          ? AppEmptyState(icon: Icons.block_rounded, title: S.tr('friends_empty_blocked'))
          : ListView.separated(
              padding: const EdgeInsets.all(AppSpacing.lg),
              itemCount: _blocked.length,
              separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
              itemBuilder: (context, i) {
                final u = _blocked[i];
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: ZpAvatar(imagePath: u.avatarPath, size: 46),
                  title: Text(u.name, style: AppTextStyles.bodyBold),
                  trailing: OutlinedButton(onPressed: () => _unblock(u), child: Text(S.tr('friends_unblock'))),
                );
              },
            ),
    );
  }
}

// ================= SUPPORT =================
class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  static const _topics = ['المشاكل التقنية', 'الحساب والخصوصية', 'المدفوعات', 'الإبلاغ عن مستخدم'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_support')),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          const Text('كيف يمكننا مساعدتك؟', style: AppTextStyles.h3),
          const SizedBox(height: AppSpacing.md),
          ..._topics.map((t) => ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(t),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => zpToast(context, '$t: ${S.tr('coming_soon')}', icon: Icons.info_outline_rounded, color: AppColors.info),
              )),
        ],
      ),
    );
  }
}

// ================= ABOUT =================
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar(S.tr('settings_about')),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.xl),
        children: [
          const Center(child: FlutterLogo(size: 56)),
          const SizedBox(height: AppSpacing.md),
          const Center(child: Text('Zuparty', style: AppTextStyles.h2)),
          const SizedBox(height: 4),
          Center(child: Text('${S.tr('settings_version')} 1.0.0', style: AppTextStyles.caption)),
          const SizedBox(height: AppSpacing.xl),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('السياسات', style: AppTextStyles.bodyBold),
            trailing: const Icon(Icons.chevron_left, color: AppColors.grey400),
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => const PolicyScreen())),
          ),
        ],
      ),
    );
  }
}

// ================= POLICY =================
class PolicyScreen extends StatelessWidget {
  const PolicyScreen({super.key});

  static const _items = ['سياسة الخصوصية', 'شروط الخدمة', 'سياسة معايير سلامة الأطفال'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: zpAppBar('السياسات'),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: AppSpacing.sm),
            ..._items.map((label) => InkWell(
                  onTap: () => zpToast(context, '$label - متوفر قريبًا', icon: Icons.info_outline_rounded, color: AppColors.info),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Row(
                      children: [
                        Text(label, style: AppTextStyles.body),
                        const Spacer(),
                        const Icon(Icons.chevron_left, color: AppColors.grey400, size: 20),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
