import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';

/// ============================================================
/// Phase 5 — Part 2: VIP Center — مستويات، تقدّم، مزايا، خطط اشتراك
/// ============================================================
class VipScreen extends StatefulWidget {
  const VipScreen({super.key});

  @override
  State<VipScreen> createState() => _VipScreenState();
}

class _VipScreenState extends State<VipScreen> {
  bool _loading = true;
  bool _subscribed = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  VipTier get _currentTier {
    final tiers = MockData.vipTiers;
    VipTier current = tiers.first;
    for (final t in tiers) {
      if (MockData.userVipPoints >= t.minPoints) current = t;
    }
    return current;
  }

  VipTier? get _nextTier {
    final tiers = MockData.vipTiers;
    final idx = tiers.indexOf(_currentTier);
    return idx + 1 < tiers.length ? tiers[idx + 1] : null;
  }

  Future<void> _subscribe(VipTier tier) async {
    final ok = await zpConfirmSheet(
      context,
      title: S.trParams('p7_subscribe_confirm', {'tier': tier.title}),
      message: S.trParams('p7_subscribe_message', {'cost': tier.priceCoinsPerMonth.toString()}),
      confirmLabel: S.tr('p7_subscribe_now'),
      icon: Icons.workspace_premium_rounded,
      color: tier.color,
    );
    if (!ok || !mounted) return;
    if (MockData.userCoinBalance < tier.priceCoinsPerMonth) {
      zpToast(context, S.tr('p7_vip_insufficient'), icon: Icons.error_outline_rounded, color: AppColors.danger);
      return;
    }
    setState(() {
      MockData.userCoinBalance -= tier.priceCoinsPerMonth;
      MockData.userVipPoints += tier.priceCoinsPerMonth;
      MockData.walletTransactions.insert(0, WalletTransaction(
        id: 'vip_${DateTime.now().microsecondsSinceEpoch}', type: WalletTxType.vipSub,
        title: 'اشتراك ${tier.title}', amount: -tier.priceCoinsPerMonth, time: DateTime.now(),
      ));
      _subscribed = true;
    });
    zpToast(context, S.trParams('p7_vip_success', {'tier': tier.title}));
  }

  @override
  Widget build(BuildContext context) {
    final tiers = MockData.vipTiers;
    final current = _currentTier;
    final next = _nextTier;
    final progress = next == null ? 1.0 : ((MockData.userVipPoints - current.minPoints) / (next.minPoints - current.minPoints)).clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: const Color(0xFF160604),
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, centerTitle: true, title: Text(S.tr('p7_vip_title'), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : ListView(
              padding: const EdgeInsets.fromLTRB(AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xxl),
              children: [
                _buildStatusCard(current, next, progress),
                const SizedBox(height: AppSpacing.xl),
                Text(S.tr('p7_my_levels'), style: AppTextStyles.h3.copyWith(color: Colors.white)),
                const SizedBox(height: AppSpacing.md),
                SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: tiers.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, i) => _TierBadge(tier: tiers[i], isCurrent: tiers[i].level == current.level, isUnlocked: MockData.userVipPoints >= tiers[i].minPoints),
                  ),
                ),
                const SizedBox(height: AppSpacing.xl),
                Text(S.tr('p7_perks'), style: AppTextStyles.h3.copyWith(color: Colors.white)),
                const SizedBox(height: AppSpacing.md),
                ...current.perks.map((p) => _PerkRow(label: p)),
                const SizedBox(height: AppSpacing.xl),
                Text(S.tr('p7_plans'), style: AppTextStyles.h3.copyWith(color: Colors.white)),
                const SizedBox(height: AppSpacing.md),
                ...tiers.map((t) => _PlanCard(tier: t, isSubscribed: _subscribed && t.level == current.level, onSubscribe: () => _subscribe(t))),
              ],
            ),
    );
  }

  Widget _buildStatusCard(VipTier current, VipTier? next, double progress) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [current.color, current.color.withOpacity(0.7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(AppRadius.xl),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 30),
              const SizedBox(width: 10),
              Text(current.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
              const Spacer(),
              ZpPill(label: '${MockData.userVipPoints} نقطة', color: Colors.white.withOpacity(0.2), textColor: Colors.white),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.pill),
            child: LinearProgressIndicator(value: progress, minHeight: 8, backgroundColor: Colors.white.withOpacity(0.25), valueColor: const AlwaysStoppedAnimation(Colors.white)),
          ),
          const SizedBox(height: 6),
          Text(
            next == null ? S.tr('p7_vip_max') : S.trParams('p7_vip_next', {'points': (next.minPoints - MockData.userVipPoints).toString(), 'tier': next.title}),
            style: const TextStyle(color: Colors.white70, fontSize: 11.5),
          ),
        ],
      ),
    );
  }
}

class _TierBadge extends StatelessWidget {
  final VipTier tier;
  final bool isCurrent;
  final bool isUnlocked;
  const _TierBadge({required this.tier, required this.isCurrent, required this.isUnlocked});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 84,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: isCurrent ? tier.color.withOpacity(0.25) : Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: isCurrent ? tier.color : Colors.transparent, width: 1.5),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(isUnlocked ? Icons.workspace_premium_rounded : Icons.lock_outline_rounded, color: isUnlocked ? tier.color : Colors.white38, size: 26),
          const SizedBox(height: 6),
          Text(tier.title, style: TextStyle(color: isUnlocked ? Colors.white : Colors.white38, fontWeight: FontWeight.w700, fontSize: 12)),
        ],
      ),
    );
  }
}

class _PerkRow extends StatelessWidget {
  final String label;
  const _PerkRow({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          const Icon(Icons.check_circle_rounded, color: Color(0xFFF9A825), size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 13))),
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final VipTier tier;
  final bool isSubscribed;
  final VoidCallback onSubscribe;
  const _PlanCard({required this.tier, required this.isSubscribed, required this.onSubscribe});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(AppRadius.lg), border: Border.all(color: tier.color.withOpacity(0.4))),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: tier.color.withOpacity(0.2), shape: BoxShape.circle),
            child: Icon(Icons.workspace_premium_rounded, color: tier.color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tier.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
                Text(S.trParams('p7_coin_month', {'cost': tier.priceCoinsPerMonth.toString()}), style: const TextStyle(color: Colors.white60, fontSize: 11.5)),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: isSubscribed ? null : onSubscribe,
            style: ElevatedButton.styleFrom(backgroundColor: tier.color, disabledBackgroundColor: AppColors.grey700, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)),
            child: Text(isSubscribed ? S.tr('p7_subscribed') : S.tr('p7_subscribe'), style: const TextStyle(fontSize: 12.5)),
          ),
        ],
      ),
    );
  }
}
