ZUPARTY Android preparation
This package contains the Flutter project plus a minimal Android platform scaffold.
Android only. iOS is intentionally not included.
The project still needs a real Flutter/Android build environment to run:
flutter pub get
flutter analyze
flutter build apk --release
