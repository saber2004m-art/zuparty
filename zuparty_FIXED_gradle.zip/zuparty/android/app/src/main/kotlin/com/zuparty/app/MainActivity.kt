package com.zuparty.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
