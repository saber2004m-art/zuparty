# Zuparty — نشر نسخة Web ووظيفة دعوة الحساب

## Web
المشروع يحتوي الآن على مجلد `web/`. على جهاز فيه Flutter SDK:

```bash
flutter pub get
flutter build web --release
```

الناتج يكون في `build/web` ويمكن نشره على Vercel/Netlify/Firebase Hosting أو أي static host.

## دعوة الشركة بدون localhost
الأبسط حالياً هو نشر Edge Function `invite` داخل Supabase:

```bash
supabase functions deploy invite --no-verify-jwt
```

ثم استعمال رابط:
`https://kwlcvnyznahfkyfvmymw.supabase.co/functions/v1/invite`

كـ Site URL وRedirect URL في Authentication > URL Configuration.

الصفحة تتحقق من رابط الدعوة، تسمح للمستخدم بتعيين كلمة المرور، ثم تسجّله خارج جلسة المتصفح. بعد ذلك يسجل الدخول من APK بالبريد وكلمة المرور.

## ملاحظة
لا نضع service-role key داخل Flutter أو داخل الصفحة. الصفحة تستعمل فقط `SUPABASE_ANON_KEY`، وصلاحية Admin تُمنح من SQL/قاعدة البيانات.
