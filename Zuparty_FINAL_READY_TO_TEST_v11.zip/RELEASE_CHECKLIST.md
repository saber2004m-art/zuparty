# Final release checklist

- [ ] Apply `supabase/migrations/*.sql` in timestamp order.
- [ ] Confirm the company account exists in Supabase Auth.
- [ ] Run the company-admin setup from the protected/admin environment (never expose service-role credentials in the APK).
- [ ] Confirm `zp_my_staff_role()` returns `admin`, `shipping_agency=true`, `active` for the company.
- [ ] Create a normal user and confirm recharge UI says agent-only.
- [ ] Approve a real shipping-agent account and confirm the badge appears.
- [ ] Recharge a test user and verify one ledger entry and one balance increment.
- [ ] Send a gift twice with the same idempotency key and verify only one debit.
- [ ] Place a game bet and verify wallet debit; resolve and verify reward credit.
- [ ] Upgrade VIP/SVIP and verify wallet debit + tier change.
- [ ] Test level XP/level 1..10 progression.
- [ ] Test room chat and direct chat on two devices.
- [ ] Test Agora voice on two devices.
- [ ] Build release APK and test on a physical Android device.
