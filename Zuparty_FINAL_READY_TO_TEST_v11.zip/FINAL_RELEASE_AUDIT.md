# Zuparty — Final Release Candidate Audit

## Verified statically
- Supabase URL/publishable client configuration present.
- Agora voice service requests a server-issued token and uses the room channel.
- Agent recharge RPC requires an active shipping agency and agent/admin role.
- Direct recharge/payment intent path is blocked for ordinary authenticated users.
- Gift sending uses the server RPC and an idempotency key.
- Game betting uses server RPCs; the client does not directly mutate the wallet balance.
- VIP/SVIP status and subscription use server RPCs.
- Account level/XP is server-derived.
- Profile no longer exposes a "طلب صفة وكيل شحن" action.
- Public execution of `zp_apply_agent` is revoked; agents are intended to be verified by admin/server process.
- Support email is configured as `didin2004m@gmail.com`.
- Project contains 1,104 packaged assets.

## Runtime validation still required on the user's machine
This environment does not contain Flutter/Dart SDK and cannot log into the user's Supabase project or run Agora on real devices. Therefore the following cannot honestly be marked runtime-tested here:
1. `flutter analyze` / `flutter test`.
2. `flutter build apk --release`.
3. Two-device Agora audio test.
4. Live Supabase migration execution against the production project.
5. End-to-end gift/coin race-condition test on a real database.

## Important remaining UI audit
Some legacy screens still reference `MockData` (social feeds, rankings, parts of rooms/gift history/settings). Those references were not silently claimed as live. They must be replaced or deliberately retained as UI fallback before a true production 100% claim.
