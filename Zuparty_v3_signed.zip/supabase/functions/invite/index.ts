const headers = {
  'Content-Type': 'text/html; charset=utf-8',
  'Cache-Control': 'no-store',
};

const html = (supabaseUrl: string, anonKey: string) => `<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Zuparty — تفعيل حساب الشركة</title>
<style>body{font-family:system-ui,-apple-system,sans-serif;background:#f7f7f7;margin:0;color:#222}.wrap{max-width:520px;margin:7vh auto;padding:20px}.card{background:#fff;border-radius:22px;padding:24px;box-shadow:0 8px 30px #0001}h1{margin-top:0}input,button{width:100%;box-sizing:border-box;padding:13px;border-radius:12px;border:1px solid #ddd;margin-top:10px;font:inherit}button{background:#f4511e;color:#fff;border:0;font-weight:800;cursor:pointer}.muted{color:#777}.ok{color:#15803d}.err{color:#b91c1c}.hidden{display:none}</style></head>
<body><div class="wrap"><div class="card"><h1>تفعيل حساب Zuparty</h1><p id="status" class="muted">جارٍ التحقق من دعوة الحساب...</p>
<form id="form" class="hidden"><label>كلمة المرور الجديدة</label><input id="password" type="password" minlength="6" autocomplete="new-password" required><label>تأكيد كلمة المرور</label><input id="confirm" type="password" minlength="6" autocomplete="new-password" required><button type="submit">تفعيل الحساب</button></form>
<div id="done" class="hidden"><p class="ok">تم تفعيل الحساب بنجاح.</p><p>يمكنك الآن فتح تطبيق Zuparty وتسجيل الدخول بنفس البريد وكلمة المرور الجديدة.</p></div></div></div>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script><script>
const sb=supabase.createClient(${JSON.stringify(supabaseUrl)},${JSON.stringify(anonKey)});
const statusEl=document.getElementById('status'), form=document.getElementById('form'), done=document.getElementById('done');
function fail(m){statusEl.textContent=m;statusEl.className='err'}
async function boot(){
 try{
  const u=new URL(location.href); const p=u.searchParams;
  const code=p.get('code'); const token=p.get('token_hash'); const type=p.get('type') || 'invite';
  if(code){ const r=await sb.auth.exchangeCodeForSession(code); if(r.error) throw r.error; }
  else if(token){ const r=await sb.auth.verifyOtp({token_hash:token,type}); if(r.error) throw r.error; }
  const {data:{session}}=await sb.auth.getSession();
  if(!session) throw new Error('انتهت صلاحية الدعوة أو الرابط غير صحيح. اطلب دعوة جديدة.');
  statusEl.textContent='تم التحقق. اختر كلمة مرور لحساب الشركة.'; form.classList.remove('hidden');
 }catch(e){fail(e.message || 'تعذر التحقق من الدعوة.');}
}
form.addEventListener('submit',async e=>{e.preventDefault(); const a=document.getElementById('password').value,b=document.getElementById('confirm').value; if(a.length<6)return fail('كلمة المرور يجب أن تكون 6 أحرف على الأقل.'); if(a!==b)return fail('كلمتا المرور غير متطابقتين.'); try{const {error}=await sb.auth.updateUser({password:a}); if(error)throw error; await sb.auth.signOut(); form.classList.add('hidden'); statusEl.classList.add('hidden'); done.classList.remove('hidden');}catch(e){fail(e.message||'تعذر تحديث كلمة المرور.');}});
boot();
</script></body></html>`;

Deno.serve((_req) => new Response(html(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_ANON_KEY') ?? ''), {headers}));
