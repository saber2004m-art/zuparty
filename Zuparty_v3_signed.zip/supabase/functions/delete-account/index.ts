import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

// Deleting an auth user (and therefore the linked zp_profiles row and every
// row that references it with `on delete cascade`) can only be done with the
// service-role key. It must never be callable from the client with the
// user's own JWT alone — this function re-authenticates the caller first and
// only ever deletes the caller's own account, never an arbitrary id passed
// in the request body.
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'method_not_allowed' }), {
      status: 405,
      headers: { ...cors, 'Content-Type': 'application/json' },
    });
  }

  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('missing_authorization');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    // Step 1: identify the caller using their own JWT (never trust a
    // user id sent in the request body).
    const callerClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: auth } },
    });
    const { data: { user }, error: userError } = await callerClient.auth.getUser();
    if (userError || !user) throw new Error('not_authenticated');

    // Step 2: perform the deletion with the service-role client.
    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    // Revoke any staff/agent role explicitly first — belt and suspenders in
    // case a future migration changes zp_staff_roles to `on delete set null`
    // instead of cascade.
    await adminClient.from('zp_staff_roles').delete().eq('user_id', user.id);

    // Deleting the auth user cascades (per the existing schema's
    // `on delete cascade` foreign keys) to zp_profiles and everything that
    // references it: room membership, owned rooms, messages, wallet
    // transactions, game history, gifts, follows, direct messages.
    // Note: if this user owns a voice room, that room (and its other
    // members' membership/chat rows in it) is deleted too — this is the
    // existing schema's intended cascade behavior, not something new
    // introduced here.
    const { error: deleteError } = await adminClient.auth.admin.deleteUser(user.id);
    if (deleteError) throw deleteError;

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { ...cors, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown_error';
    const status = message === 'not_authenticated' ? 401 : message === 'missing_authorization' ? 401 : 400;
    return new Response(JSON.stringify({ error: message }), {
      status,
      headers: { ...cors, 'Content-Type': 'application/json' },
    });
  }
});
