-- Security hardening: enforce room membership for seats/messages and derive Agora publish privilege server-side.

create or replace function public.zp_take_seat(p_room_id uuid, p_seat_index integer)
returns public.zp_room_members
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_mic_seats integer;
  v_owner_id uuid;
  v_row public.zp_room_members;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if p_seat_index is null or p_seat_index < 1 then raise exception 'invalid_seat'; end if;

  select mic_seats, owner_id into v_mic_seats, v_owner_id
  from public.zp_rooms where id = p_room_id;
  if v_mic_seats is null then raise exception 'room_not_found'; end if;
  if p_seat_index >= v_mic_seats then raise exception 'seat_out_of_range'; end if;

  if v_uid <> v_owner_id and not exists (
    select 1 from public.zp_room_members
    where room_id = p_room_id and user_id = v_uid
  ) then
    raise exception 'not_room_member';
  end if;

  perform pg_advisory_xact_lock(hashtext('zp_seat_' || p_room_id::text));

  if exists (
    select 1 from public.zp_room_members
    where room_id = p_room_id and seat_index = p_seat_index and user_id <> v_uid
  ) then raise exception 'seat_taken'; end if;

  insert into public.zp_room_members(room_id, user_id, role, seat_index)
  values (p_room_id, v_uid, case when v_uid = v_owner_id then 'owner' else 'member' end, p_seat_index)
  on conflict (room_id, user_id) do update
    set seat_index = excluded.seat_index,
        role = case when v_uid = v_owner_id then 'owner' else public.zp_room_members.role end
  returning * into v_row;

  return v_row;
exception when unique_violation then
  raise exception 'seat_taken';
end;
$$;

revoke all on function public.zp_take_seat(uuid, integer) from public;
grant execute on function public.zp_take_seat(uuid, integer) to authenticated;

-- Only room members can post room messages.
drop policy if exists room_messages_insert_self on public.zp_room_messages;
create policy room_messages_insert_member on public.zp_room_messages
for insert to authenticated
with check (
  sender_id = auth.uid()
  and exists (
    select 1 from public.zp_room_members m
    where m.room_id = zp_room_messages.room_id and m.user_id = auth.uid()
  )
);

-- Agora token privilege is derived from server-side room membership/seat state.
-- The client cannot request Publisher privilege by changing a request parameter.
