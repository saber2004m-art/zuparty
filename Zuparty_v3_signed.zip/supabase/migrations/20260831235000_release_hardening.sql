-- Release hardening: users cannot submit a shipping-agent application from the client.
-- Shipping agents are created/verified only by an administrator/server-side process.
revoke execute on function public.zp_apply_agent(text) from authenticated;
revoke execute on function public.zp_apply_agent(text) from anon;

-- Keep direct recharge locked to verified active agents/admins only.
-- The function itself performs the authorization check; this comment documents the invariant.
comment on function public.zp_agent_recharge_user(uuid,bigint,text)
is 'Recharge is agent-only: active shipping_agency=true and role agent/admin. Balance mutation is server-side.';

-- Keep the public client from creating payment intents; only verified agent/admin can use the legacy order RPC.
comment on function public.zp_create_recharge_order(text,integer,bigint,text)
is 'Legacy recharge order path is restricted to active shipping agents/admins; regular users must use agent recharge.';
