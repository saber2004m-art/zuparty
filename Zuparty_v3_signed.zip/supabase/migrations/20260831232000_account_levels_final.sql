-- Zuparty account progression: 10 account levels, server-authoritative XP.
-- Rule: 1 credited Coin = 1 XP. XP never decreases when Coins are spent.
-- Level thresholds: Level 1 starts at 0 XP; reaching 10,000 XP advances to Level 2,
-- then 20,000 -> Level 3 ... 90,000 -> Level 10. Level 10 is the cap.

alter table public.zp_profiles
  add column if not exists account_xp bigint not null default 0 check (account_xp >= 0),
  add column if not exists account_level integer not null default 1 check (account_level between 1 and 10);

-- Backfill existing profiles conservatively from current balance.
update public.zp_profiles
set account_xp = greatest(coalesce(account_xp,0), coins),
    account_level = least(10, greatest(1, floor(greatest(coalesce(account_xp,0), coins)::numeric / 10000)::integer + 1))
where account_xp = 0;

create or replace function public.zp_account_level_from_xp(p_xp bigint)
returns integer
language sql immutable as $$
  select least(10, greatest(1, (greatest(coalesce(p_xp,0),0) / 10000)::integer + 1));
$$;

create or replace function public.zp_sync_account_progress()
returns trigger
language plpgsql as $$
declare
  delta bigint;
  next_xp bigint;
begin
  if tg_op = 'INSERT' then
    next_xp := greatest(coalesce(new.account_xp,0), coalesce(new.coins,0));
    new.account_xp := next_xp;
    new.account_level := public.zp_account_level_from_xp(next_xp);
    return new;
  end if;

  delta := greatest(coalesce(new.coins,0) - coalesce(old.coins,0), 0);
  next_xp := coalesce(old.account_xp,0) + delta;
  new.account_xp := greatest(coalesce(new.account_xp,0), next_xp);
  new.account_level := public.zp_account_level_from_xp(new.account_xp);
  return new;
end;
$$;

drop trigger if exists trg_zp_account_progress on public.zp_profiles;
create trigger trg_zp_account_progress
before insert or update of coins, account_xp on public.zp_profiles
for each row execute function public.zp_sync_account_progress();

create or replace function public.zp_get_account_progress()
returns jsonb
language sql
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'level', p.account_level,
    'xp', p.account_xp,
    'current_level_xp', case when p.account_level >= 10 then 90000 else (p.account_level-1)*10000 end,
    'next_level_xp', case when p.account_level >= 10 then 100000 else p.account_level*10000 end,
    'xp_to_next', case when p.account_level >= 10 then 0 else greatest(p.account_level*10000-p.account_xp,0) end,
    'max_level', 10
  )
  from public.zp_profiles p
  where p.id=auth.uid();
$$;
grant execute on function public.zp_get_account_progress() to authenticated;

comment on column public.zp_profiles.account_xp is 'Cumulative credited Coins converted 1:1 to account XP; spending Coins does not reduce XP.';
comment on column public.zp_profiles.account_level is 'Account level 1..10 derived server-side from account_xp.';
