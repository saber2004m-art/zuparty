-- Phase 2: close two gaps found during code review.
-- 1) mic_muted on zp_room_members was read everywhere but never written by
--    the client, so Realtime never reflected a user's real mute state.
-- 2) Room settings (who can speak/chat, guest gifts, private/locked) were
--    edited only in local Flutter state and never persisted to zp_rooms,
--    so an owner's changes were never saved server-side or seen by others.

-- ---------------------------------------------------------------------
-- 1) Persist the caller's own mic mute state for a room they're a member of.
-- ---------------------------------------------------------------------
create or replace function public.zp_set_mic_muted(p_room_id uuid, p_muted boolean)
returns public.zp_room_members
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_row public.zp_room_members;
begin
  if v_uid is null then
    raise exception 'not_authenticated';
  end if;

  update public.zp_room_members
     set mic_muted = p_muted
   where room_id = p_room_id and user_id = v_uid
  returning * into v_row;

  if v_row is null then
    raise exception 'not_room_member';
  end if;

  return v_row;
end;
$$;

revoke all on function public.zp_set_mic_muted(uuid, boolean) from public;
grant execute on function public.zp_set_mic_muted(uuid, boolean) to authenticated;

-- ---------------------------------------------------------------------
-- 2) Persist room settings. Owner-only (matches rooms_update_owner policy
--    already used for direct table updates elsewhere in the project).
-- ---------------------------------------------------------------------
create or replace function public.zp_update_room_settings(
  p_room_id uuid,
  p_name text,
  p_description text,
  p_who_can_speak text,
  p_who_can_chat text,
  p_allow_guest_gifts boolean,
  p_is_private boolean
)
returns public.zp_rooms
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_row public.zp_rooms;
begin
  if v_uid is null then
    raise exception 'not_authenticated';
  end if;
  if p_name is null or length(trim(p_name)) = 0 then
    raise exception 'invalid_name';
  end if;

  update public.zp_rooms
     set name = trim(p_name),
         description = coalesce(p_description, ''),
         who_can_speak = coalesce(p_who_can_speak, who_can_speak),
         who_can_chat = coalesce(p_who_can_chat, who_can_chat),
         allow_guest_gifts = p_allow_guest_gifts,
         is_private = p_is_private,
         updated_at = now()
   where id = p_room_id and owner_id = v_uid
  returning * into v_row;

  if v_row is null then
    raise exception 'not_room_owner_or_room_not_found';
  end if;

  return v_row;
end;
$$;

revoke all on function public.zp_update_room_settings(uuid, text, text, text, text, boolean, boolean) from public;
grant execute on function public.zp_update_room_settings(uuid, text, text, text, text, boolean, boolean) to authenticated;
