-- Final live shipping + social hardening for Zuparty.
-- Recharge is ONLY an agent/admin operation. Regular users see "available later".
-- Direct messages/follows are server-backed.

create or replace function public.zp_my_staff_role()
returns table(role text, shipping_agency boolean, status text, badge text)
language sql security definer set search_path=public as $$
  select s.role, s.shipping_agency, s.status, s.badge
  from public.zp_staff_roles s where s.user_id=auth.uid() limit 1;
$$;
grant execute on function public.zp_my_staff_role() to authenticated;

create or replace function public.zp_agent_recharge_user(p_user_id uuid,p_coins bigint,p_note text default '')
returns table(ok boolean,new_balance bigint,transaction_id uuid)
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); bal bigint; nb bigint; tid uuid; allowed boolean;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select exists(select 1 from public.zp_staff_roles s where s.user_id=uid and s.status='active' and s.shipping_agency=true and (s.role in ('agent','admin'))) into allowed;
  if not allowed then raise exception 'shipping_agent_required'; end if;
  if p_user_id is null or p_user_id=uid then raise exception 'invalid_user'; end if;
  if p_coins is null or p_coins<=0 or p_coins>1000000000 then raise exception 'invalid_coins'; end if;
  select p.coins into bal from public.zp_profiles p where p.id=p_user_id for update;
  if bal is null then raise exception 'user_not_found'; end if;
  nb:=bal+p_coins;
  update public.zp_profiles p set coins=nb,updated_at=now() where p.id=p_user_id;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,metadata)
  values(p_user_id,'agent_recharge',p_coins,nb,'agent_recharge',jsonb_build_object('agent_id',uid,'note',coalesce(p_note,''))) returning id into tid;
  return query select true,nb,tid;
end; $$;
grant execute on function public.zp_agent_recharge_user(uuid,bigint,text) to authenticated;

-- User lookup for the in-wallet shipping-agent panel. No sensitive Auth fields are exposed.
create or replace function public.zp_agent_search_users(p_query text default '')
returns table(user_id uuid,display_name text,avatar_url text,coins bigint,vip_level integer)
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); allowed boolean; q text:=lower(trim(coalesce(p_query,'')));
begin
  select exists(select 1 from public.zp_staff_roles s where s.user_id=uid and s.status='active' and s.shipping_agency=true and s.role in ('agent','admin')) into allowed;
  if not allowed then raise exception 'shipping_agent_required'; end if;
  return query
  select p.id,p.display_name,p.avatar_url,p.coins,p.vip_level
  from public.zp_profiles p
  where p.id<>uid and (q='' or lower(coalesce(p.display_name,'')) like '%'||q||'%')
  order by p.updated_at desc limit 50;
end; $$;
grant execute on function public.zp_agent_search_users(text) to authenticated;

-- Disable the client-created payment-intent path for normal users. The agent flow is the only launch recharge path.
create or replace function public.zp_create_recharge_order(p_package_id text,p_usd_cents integer,p_coins bigint,p_payment_method text)
returns table(id uuid,status text)
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); oid uuid; allowed boolean;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select exists(select 1 from public.zp_staff_roles s where s.user_id=uid and s.status='active' and s.shipping_agency=true and s.role in ('agent','admin')) into allowed;
  if not allowed then raise exception 'shipping_agent_required'; end if;
  if p_usd_cents not in (1000,5000,10000) then raise exception 'invalid_package'; end if;
  if p_coins not in (35000000,175000000,350000000) then raise exception 'invalid_coins'; end if;
  insert into public.zp_recharge_orders(user_id,package_id,usd_cents,coins,payment_method)
  values(uid,p_package_id,p_usd_cents,p_coins,p_payment_method) returning id into oid;
  return query select oid,'pending'::text;
end; $$;
grant execute on function public.zp_create_recharge_order(text,integer,bigint,text) to authenticated;

-- Social graph.
create table if not exists public.zp_follows(
  follower_id uuid not null references public.zp_profiles(id) on delete cascade,
  following_id uuid not null references public.zp_profiles(id) on delete cascade,
  status text not null default 'accepted' check(status in ('pending','accepted','blocked')),
  created_at timestamptz not null default now(),
  primary key(follower_id,following_id),
  check(follower_id<>following_id)
);
create index if not exists zp_follows_following_idx on public.zp_follows(following_id,status);
alter table public.zp_follows enable row level security;
drop policy if exists follows_select_self on public.zp_follows;
create policy follows_select_self on public.zp_follows for select to authenticated using(follower_id=auth.uid() or following_id=auth.uid());
drop policy if exists follows_insert_self on public.zp_follows;
create policy follows_insert_self on public.zp_follows for insert to authenticated with check(follower_id=auth.uid());
drop policy if exists follows_delete_self on public.zp_follows;
create policy follows_delete_self on public.zp_follows for delete to authenticated using(follower_id=auth.uid());

create or replace function public.zp_follow_user(p_user_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_user_id is null or p_user_id=auth.uid() then raise exception 'invalid_user'; end if;
  insert into public.zp_follows(follower_id,following_id,status) values(auth.uid(),p_user_id,'accepted') on conflict(follower_id,following_id) do update set status='accepted';
  return true;
end; $$;
grant execute on function public.zp_follow_user(uuid) to authenticated;

create or replace function public.zp_unfollow_user(p_user_id uuid)
returns boolean language sql security definer set search_path=public as $$
  delete from public.zp_follows where follower_id=auth.uid() and following_id=p_user_id; select true;
$$;
grant execute on function public.zp_unfollow_user(uuid) to authenticated;

create or replace function public.zp_my_following()
returns table(user_id uuid,display_name text,avatar_url text,vip_level integer)
language sql security definer set search_path=public as $$
 select p.id,p.display_name,p.avatar_url,p.vip_level from public.zp_follows f join public.zp_profiles p on p.id=f.following_id where f.follower_id=auth.uid() and f.status='accepted' order by f.created_at desc;
$$;
grant execute on function public.zp_my_following() to authenticated;

create table if not exists public.zp_direct_messages(
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references public.zp_profiles(id) on delete cascade,
 receiver_id uuid not null references public.zp_profiles(id) on delete cascade,
 text text not null check(length(trim(text)) between 1 and 4000),
 created_at timestamptz not null default now(),
 read_at timestamptz,
 check(sender_id<>receiver_id)
);
create index if not exists zp_dm_pair_created_idx on public.zp_direct_messages(sender_id,receiver_id,created_at desc);
create index if not exists zp_dm_receiver_created_idx on public.zp_direct_messages(receiver_id,created_at desc);
alter table public.zp_direct_messages enable row level security;
drop policy if exists dm_select_participant on public.zp_direct_messages;
create policy dm_select_participant on public.zp_direct_messages for select to authenticated using(sender_id=auth.uid() or receiver_id=auth.uid());
drop policy if exists dm_insert_sender on public.zp_direct_messages;
create policy dm_insert_sender on public.zp_direct_messages for insert to authenticated with check(sender_id=auth.uid());
drop policy if exists dm_update_receiver on public.zp_direct_messages;
create policy dm_update_receiver on public.zp_direct_messages for update to authenticated using(receiver_id=auth.uid()) with check(receiver_id=auth.uid());

create or replace function public.zp_send_direct_message(p_receiver_id uuid,p_text text)
returns uuid language plpgsql security definer set search_path=public as $$
declare mid uuid;
begin
 if auth.uid() is null then raise exception 'not_authenticated'; end if;
 if p_receiver_id is null or p_receiver_id=auth.uid() then raise exception 'invalid_receiver'; end if;
 if length(trim(coalesce(p_text,'')))=0 or length(trim(p_text))>4000 then raise exception 'invalid_message'; end if;
 insert into public.zp_direct_messages(sender_id,receiver_id,text) values(auth.uid(),p_receiver_id,trim(p_text)) returning id into mid;
 return mid;
end; $$;
grant execute on function public.zp_send_direct_message(uuid,text) to authenticated;

-- VIP/SVIP launch pricing: SVIP 11 starts at $50 and SVIP 13 is $100,000.
update public.zp_vip_tiers set price_usd_cents=case level
 when 1 then 5000 when 2 then 10000 when 3 then 15000 when 4 then 25000 when 5 then 50000
 when 6 then 75000 when 7 then 100000 when 8 then 250000 when 9 then 500000 when 10 then 1000000
 when 11 then 5000 when 12 then 2500000 when 13 then 10000000 end
where level between 1 and 13;

-- The first verified $50+ recharge creates a one-time virtual $50-value reward record.
-- It is not cash and cannot be withdrawn.
