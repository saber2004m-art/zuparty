-- Phase 3: close the last gap for full multi-user Mic <-> Seat sync.
--
-- Context (no schema change needed for most of this):
-- `mic_muted` already lives on `zp_room_members`, whose primary key is
-- (room_id, user_id) -- the SAME row that holds `seat_index`. So a user's
-- mic state is already inherently scoped to room+user+current-seat, and
-- moving seats (zp_take_seat only ever updates seat_index on that row)
-- already carries the mic state along automatically. The gaps that existed
-- were all client-side (see CHANGELOG_FOR_DEV.md), except for one missing
-- server capability: there was no way for the room owner to mute/unmute a
-- seated member's mic other than that member's own device calling
-- zp_set_mic_muted (self-only, by design).
--
-- This migration adds exactly that one RPC, reusing the same owner_id check
-- already used by zp_update_room_settings -- no new role/grant is
-- introduced, and normal members still can only ever touch their own row via
-- zp_set_mic_muted (unchanged, not redefined here).

create or replace function public.zp_set_member_mic_muted(
  p_room_id uuid,
  p_target_user_id uuid,
  p_muted boolean
)
returns public.zp_room_members
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_owner_id uuid;
  v_row public.zp_room_members;
begin
  if v_uid is null then
    raise exception 'not_authenticated';
  end if;
  if p_target_user_id is null then
    raise exception 'invalid_target';
  end if;

  select owner_id into v_owner_id from public.zp_rooms where id = p_room_id;
  if v_owner_id is null then
    raise exception 'room_not_found';
  end if;

  -- Owner-only, matching the exact pattern already used by
  -- zp_update_room_settings (owner_id = auth.uid()). No admin/staff role is
  -- consulted here on purpose: that concept isn't wired to room membership
  -- anywhere else in this project, so we don't introduce it just for this.
  if v_owner_id <> v_uid then
    raise exception 'not_room_owner';
  end if;

  update public.zp_room_members
     set mic_muted = p_muted
   where room_id = p_room_id and user_id = p_target_user_id
  returning * into v_row;

  if v_row is null then
    raise exception 'not_room_member';
  end if;

  return v_row;
end;
$$;

revoke all on function public.zp_set_member_mic_muted(uuid, uuid, boolean) from public;
grant execute on function public.zp_set_member_mic_muted(uuid, uuid, boolean) to authenticated;

-- No RLS changes: zp_room_members already has no UPDATE policy at all (see
-- 20260831000000_zuparty_backend.sql), so this SECURITY DEFINER function
-- remains the only way to change mic_muted for a row that isn't your own --
-- a direct client-side `.update()` call is still rejected by RLS either way.
-- Realtime is already enabled for the whole zp_room_members table (see
-- 20260901000000_realtime_seats.sql), so writes from this new RPC already
-- broadcast to every client in the room with no further setup.
