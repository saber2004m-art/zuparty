-- Phase 1: real multiplayer seat sync for voice rooms.
-- Adds atomic seat-claim / seat-leave RPCs (race-condition safe) and turns on
-- Supabase Realtime for public.zp_room_members so every client in a room sees
-- seat changes instantly. Does not touch any other table/feature.

-- Seat numbering convention used by the client:
--   seat_index 0            -> reserved, not assigned via this RPC (owner tile
--                               is rendered from zp_rooms.owner_id, not from a
--                               room_members row).
--   seat_index 1..mic_seats-1 -> regular seats, first-come first-served.
--
-- A partial unique index guarantees the database itself will never let two
-- different users hold the same occupied seat in the same room, no matter
-- what the application layer does.
create unique index if not exists zp_room_members_room_seat_uidx
  on public.zp_room_members(room_id, seat_index)
  where seat_index is not null;

-- Atomically claim a seat. Uses a per-room advisory transaction lock (same
-- pattern already used by zp_get_or_create_game_round) so two concurrent
-- requests for the same room are fully serialized: the second one to reach
-- the lock will see the first one's row and fail with 'seat_taken' instead of
-- racing on the insert/update.
create or replace function public.zp_take_seat(p_room_id uuid, p_seat_index integer)
returns public.zp_room_members
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_mic_seats integer;
  v_row public.zp_room_members;
begin
  if v_uid is null then
    raise exception 'not_authenticated';
  end if;
  if p_seat_index is null or p_seat_index < 1 then
    raise exception 'invalid_seat';
  end if;

  select mic_seats into v_mic_seats from public.zp_rooms where id = p_room_id;
  if v_mic_seats is null then
    raise exception 'room_not_found';
  end if;
  if p_seat_index >= v_mic_seats then
    raise exception 'seat_out_of_range';
  end if;

  -- Serialize seat assignment for this room only (closes the race-condition
  -- window between the "is it free" check and the write).
  perform pg_advisory_xact_lock(hashtext('zp_seat_' || p_room_id::text));

  if exists (
    select 1 from public.zp_room_members
     where room_id = p_room_id and seat_index = p_seat_index and user_id <> v_uid
  ) then
    raise exception 'seat_taken';
  end if;

  insert into public.zp_room_members(room_id, user_id, seat_index)
  values (p_room_id, v_uid, p_seat_index)
  on conflict (room_id, user_id) do update set seat_index = excluded.seat_index
  returning * into v_row;

  return v_row;
exception
  when unique_violation then
    -- Belt-and-suspenders: even if two calls somehow reach the insert at the
    -- exact same instant, the unique index guarantees only one succeeds.
    raise exception 'seat_taken';
end;
$$;

revoke all on function public.zp_take_seat(uuid, integer) from public;
grant execute on function public.zp_take_seat(uuid, integer) to authenticated;

-- Vacate whatever seat the caller currently holds in this room (if any).
-- Leaves the room-membership row in place (still an audience member) —
-- the existing zp_room_members delete-self policy already handles a full
-- "leave the room" action separately.
create or replace function public.zp_leave_seat(p_room_id uuid)
returns public.zp_room_members
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_row public.zp_room_members;
begin
  if v_uid is null then
    raise exception 'not_authenticated';
  end if;

  update public.zp_room_members
     set seat_index = null
   where room_id = p_room_id and user_id = v_uid
  returning * into v_row;

  return v_row;
end;
$$;

revoke all on function public.zp_leave_seat(uuid) from public;
grant execute on function public.zp_leave_seat(uuid) to authenticated;

-- Full row data on UPDATE/DELETE change payloads (needed so a client can tell
-- which seat/user a DELETE or seat_index->null UPDATE affected).
alter table public.zp_room_members replica identity full;

-- Turn on Realtime postgres_changes broadcasts for this table only.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
     where pubname = 'supabase_realtime'
       and schemaname = 'public'
       and tablename = 'zp_room_members'
  ) then
    alter publication supabase_realtime add table public.zp_room_members;
  end if;
end $$;
