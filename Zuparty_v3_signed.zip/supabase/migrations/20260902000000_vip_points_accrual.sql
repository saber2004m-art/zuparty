-- Centralized VIP/SVIP point accrual.
-- One point per $1 credited, on EVERY coin-crediting recharge path:
--   - official payment  -> public.zp_finalize_recharge_order
--   - direct agent recharge -> public.zp_agent_recharge_user
-- The level (vip_level) auto-recomputes from the accumulated points against
-- public.zp_vip_tiers.min_points and can only go UP, never down.
-- zp_subscribe_vip own min_points floor-on-purchase logic is untouched.

-- 1) Shared internal helper. Not reachable directly from the client:
--    it is only ever called from inside other SECURITY DEFINER functions
--    owned by this migration role, so no EXECUTE grant to authenticated
--    is needed for that path to keep working.
create or replace function public.zp_apply_vip_points(p_user_id uuid, p_usd_cents integer)
returns void
language plpgsql security definer set search_path=public as $$
declare
  add_points   bigint;
  new_points   bigint;
  cur_level    integer;
  best_level   integer;
begin
  if p_user_id is null or p_usd_cents is null or p_usd_cents <= 0 then
    return;
  end if;

  add_points := floor(p_usd_cents / 100.0)::bigint; -- 1 point per $1 (100 cents)
  if add_points <= 0 then
    return;
  end if;

  update public.zp_profiles
     set vip_points = vip_points + add_points,
         updated_at = now()
   where id = p_user_id
  returning vip_points, vip_level into new_points, cur_level;

  if new_points is null then
    return; -- user not found; nothing to level up
  end if;

  select max(level) into best_level
    from public.zp_vip_tiers
   where min_points <= new_points;

  if best_level is not null and best_level > cur_level then
    update public.zp_profiles
       set vip_level = best_level, updated_at = now()
     where id = p_user_id;
  end if;
end;
$$;

-- Revoke first (in case this function pre-existed from a partial deploy),
-- then confirm no client role can call it directly.
revoke all on function public.zp_apply_vip_points(uuid,integer) from public;
revoke all on function public.zp_apply_vip_points(uuid,integer) from authenticated;
revoke all on function public.zp_apply_vip_points(uuid,integer) from anon;

comment on function public.zp_apply_vip_points(uuid,integer) is
  'Internal only. Adds 1 VIP/SVIP point per $1 and auto-levels up (never down). '
  'Call exclusively from zp_finalize_recharge_order / zp_agent_recharge_user. Never grant to clients.';

-- 2) Wire into the official payment path.
create or replace function public.zp_finalize_recharge_order(p_order_id uuid, p_provider_reference text default null)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  uid uuid := auth.uid();
  o public.zp_recharge_orders%rowtype;
  p public.zp_profiles%rowtype;
  t public.zp_vip_tiers%rowtype;
  final_coins bigint;
  bonus_coins bigint := 0;
  tid uuid;
  reward_id uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from public.zp_staff_roles s where s.user_id=uid and s.role='admin' and s.status='active') then
    raise exception 'admin_required';
  end if;
  select * into o from public.zp_recharge_orders where id=p_order_id for update;
  if o.id is null then raise exception 'order_not_found'; end if;
  if o.status = 'paid' then
    return jsonb_build_object('status','paid','order_id',o.id,'coins',o.coins);
  end if;
  if o.status <> 'pending' then raise exception 'order_not_payable'; end if;

  select * into p from public.zp_profiles where id=o.user_id for update;
  select * into t from public.zp_vip_tiers where level=p.vip_level;
  final_coins := floor(o.coins * coalesce(t.recharge_multiplier,1.0))::bigint;

  update public.zp_profiles set coins=coins+final_coins, updated_at=now() where id=o.user_id;
  update public.zp_recharge_orders set status='paid',verified_at=now() where id=o.id;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,metadata)
  select o.user_id,'recharge_verified',final_coins,coins,'recharge',o.id,
         jsonb_build_object('provider_reference',p_provider_reference,'base_coins',o.coins,'multiplier',coalesce(t.recharge_multiplier,1.0));

  -- VIP/SVIP points: 1 point per $1 of the verified order amount.
  perform public.zp_apply_vip_points(o.user_id, o.usd_cents);

  -- VIP 1 one-time welcome bonus.
  if p.vip_level >= 1 and not exists(select 1 from public.zp_reward_grants where user_id=o.user_id and reward_code='vip1_welcome_100k') then
    bonus_coins := 100000;
    update public.zp_profiles set coins=coins+bonus_coins, updated_at=now() where id=o.user_id;
    insert into public.zp_reward_grants(user_id,reward_code,value_coins,metadata)
      values(o.user_id,'vip1_welcome_100k',bonus_coins,jsonb_build_object('order_id',o.id)) returning id into reward_id;
    insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,metadata)
      select o.user_id,'vip1_welcome_bonus',bonus_coins,coins,'reward',reward_id,jsonb_build_object('order_id',o.id);
  end if;

  -- First $50+ verified recharge: one-time virtual reward with a displayed $50 value.
  if o.usd_cents >= 5000 and not exists(select 1 from public.zp_reward_grants where user_id=o.user_id and reward_code='first_recharge_50_usd_gift') then
    insert into public.zp_reward_grants(user_id,reward_code,value_usd_cents,metadata)
      values(o.user_id,'first_recharge_50_usd_gift',5000,jsonb_build_object('order_id',o.id)) returning id into reward_id;
  end if;

  select coins into final_coins from public.zp_profiles where id=o.user_id;
  return jsonb_build_object('status','paid','order_id',o.id,'credited_coins',final_coins,'welcome_bonus_coins',bonus_coins,'first_recharge_gift',o.usd_cents >= 5000);
end;
$$;
grant execute on function public.zp_finalize_recharge_order(uuid,text) to authenticated;

-- 3) Wire into the direct agent-recharge path. Agent recharges are Coins-only
--    (no usd_cents column on this call), so we convert using the SAME fixed
--    package rate already used across the app's paid packages: $1 = 3,500,000 Coins.
create or replace function public.zp_agent_recharge_user(p_user_id uuid,p_coins bigint,p_note text default '')
returns table(ok boolean,new_balance bigint,transaction_id uuid)
language plpgsql security definer set search_path=public as $$
declare
  uid uuid:=auth.uid(); bal bigint; nb bigint; tid uuid; allowed boolean; equiv_usd_cents integer;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select exists(select 1 from public.zp_staff_roles s where s.user_id=uid and s.status='active' and s.shipping_agency=true and (s.role in ('agent','admin'))) into allowed;
  if not allowed then raise exception 'shipping_agent_required'; end if;
  if p_user_id is null or p_user_id=uid then raise exception 'invalid_user'; end if;
  if p_coins is null or p_coins<=0 or p_coins>1000000000000 then raise exception 'invalid_coins'; end if;
  select p.coins into bal from public.zp_profiles p where p.id=p_user_id for update;
  if bal is null then raise exception 'user_not_found'; end if;
  nb:=bal+p_coins;
  update public.zp_profiles p set coins=nb,updated_at=now() where p.id=p_user_id;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,metadata)
  values(p_user_id,'agent_recharge',p_coins,nb,'agent_recharge',jsonb_build_object('agent_id',uid,'note',coalesce(p_note,''))) returning id into tid;

  -- VIP/SVIP points: 1 point per $1 equivalent, at the fixed 3,500,000 Coins = $1 rate.
  equiv_usd_cents := floor((p_coins::numeric / 3500000.0) * 100)::integer;
  perform public.zp_apply_vip_points(p_user_id, equiv_usd_cents);

  return query select true,nb,tid;
end; $$;
grant execute on function public.zp_agent_recharge_user(uuid,bigint,text) to authenticated;
