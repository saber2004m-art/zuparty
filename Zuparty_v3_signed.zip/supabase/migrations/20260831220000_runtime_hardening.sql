-- Zuparty runtime hardening.
-- Fixes PL/pgSQL name collisions (notably game_id) and makes RPC output
-- references explicit. Safe to run after 20260831000000_zuparty_backend.sql.

create or replace function public.zp_get_or_create_game_round(p_game_id text)
returns table(id uuid, game_id text, round_no bigint, starts_at timestamptz, ends_at timestamptz, status text)
language plpgsql security definer set search_path = public as $$
declare
  v_round public.zp_game_rounds%rowtype;
  v_next_no bigint;
  v_game_id text := trim(p_game_id);
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if v_game_id is null or v_game_id = '' then raise exception 'invalid_game'; end if;
  if not exists (
    select 1 from public.zp_games as g
    where g.id = v_game_id and g.enabled = true
  ) then raise exception 'game_disabled'; end if;

  perform pg_advisory_xact_lock(hashtext(v_game_id));

  select gr.*
    into v_round
    from public.zp_game_rounds as gr
   where gr.game_id = v_game_id
     and gr.status = 'open'
     and gr.ends_at > now()
   order by gr.round_no desc
   limit 1;

  if v_round.id is null then
    select coalesce(max(gr.round_no), 0) + 1
      into v_next_no
      from public.zp_game_rounds as gr
     where gr.game_id = v_game_id;

    insert into public.zp_game_rounds(game_id, round_no, starts_at, ends_at)
    values (v_game_id, v_next_no, now(), now() + interval '30 seconds')
    returning * into v_round;
  end if;

  return query
  select
    v_round.id,
    v_round.game_id,
    v_round.round_no,
    v_round.starts_at,
    v_round.ends_at,
    v_round.status;
end;
$$;

create or replace function public.zp_place_game_bet(
  p_game_id text,
  p_round_id uuid,
  p_choice text,
  p_amount bigint
)
returns table(ok boolean, new_balance bigint, bet_id uuid)
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_balance bigint;
  v_new_balance bigint;
  v_round public.zp_game_rounds%rowtype;
  v_valid_choice boolean;
  v_bet_id uuid;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if p_amount is null or p_amount <= 0 or p_amount > 10000000 then raise exception 'invalid_amount'; end if;

  select gr.* into v_round
    from public.zp_game_rounds as gr
   where gr.id = p_round_id
     and gr.game_id = p_game_id
   for update;

  if v_round.id is null or v_round.status <> 'open' or v_round.ends_at <= now() then
    raise exception 'round_closed';
  end if;

  select exists(
    select 1
      from public.zp_games as g,
           jsonb_array_elements(g.choices) as c
     where g.id = p_game_id
       and g.enabled = true
       and c->>'key' = p_choice
  ) into v_valid_choice;

  if not v_valid_choice then raise exception 'invalid_choice'; end if;

  select p.coins into v_balance
    from public.zp_profiles as p
   where p.id = v_uid
   for update;

  if v_balance is null then raise exception 'profile_not_found'; end if;
  if v_balance < p_amount then raise exception 'insufficient_coins'; end if;

  v_new_balance := v_balance - p_amount;

  update public.zp_profiles as p
     set coins = v_new_balance, updated_at = now()
   where p.id = v_uid;

  insert into public.zp_game_bets(round_id, game_id, user_id, choice, amount)
  values (v_round.id, p_game_id, v_uid, p_choice, p_amount)
  returning id into v_bet_id;

  insert into public.zp_wallet_transactions(user_id, type, amount, balance_after, reference_type, reference_id)
  values (v_uid, 'game_bet', -p_amount, v_new_balance, 'game_bet', v_bet_id);

  return query select true, v_new_balance, v_bet_id;
end;
$$;

create or replace function public.zp_resolve_game_round(p_round_id uuid)
returns table(winner_key text, payout bigint)
language plpgsql security definer set search_path = public as $$
declare
  v_round public.zp_game_rounds%rowtype;
  v_choice jsonb;
  v_uid uuid := auth.uid();
  v_mult bigint;
  v_payout bigint;
  v_user_payout bigint := 0;
  v_winner text;
  v_balance bigint;
  v_bet record;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;

  select gr.* into v_round
    from public.zp_game_rounds as gr
   where gr.id = p_round_id
   for update;

  if v_round.id is null then raise exception 'round_not_found'; end if;

  if v_round.status = 'resolved' then
    select coalesce(sum(b.payout), 0)
      into v_user_payout
      from public.zp_game_bets as b
     where b.round_id = v_round.id
       and b.user_id = v_uid;
    return query select v_round.winner_key, v_user_payout;
    return;
  end if;

  if v_round.ends_at > now() then raise exception 'round_not_finished'; end if;

  select c
    into v_choice
    from public.zp_games as g,
         jsonb_array_elements(g.choices) as c
   where g.id = v_round.game_id
     and g.enabled = true
   order by random()
   limit 1;

  if v_choice is null then raise exception 'game_disabled'; end if;
  v_winner := v_choice->>'key';
  v_mult := (v_choice->>'mult')::bigint;

  for v_bet in
    select b.id, b.user_id, b.amount, b.choice
      from public.zp_game_bets as b
     where b.round_id = v_round.id
     for update
  loop
    v_payout := case when v_bet.choice = v_winner then v_bet.amount * v_mult else 0 end;
    update public.zp_game_bets as b set payout = v_payout where b.id = v_bet.id;

    if v_payout > 0 then
      update public.zp_profiles as p
         set coins = p.coins + v_payout, updated_at = now()
       where p.id = v_bet.user_id
       returning p.coins into v_balance;

      insert into public.zp_wallet_transactions(user_id, type, amount, balance_after, reference_type, reference_id)
      values (v_bet.user_id, 'game_win', v_payout, v_balance, 'game_win', v_bet.id);

      if v_bet.user_id = v_uid then v_user_payout := v_user_payout + v_payout; end if;
    end if;
  end loop;

  update public.zp_game_rounds as gr
     set status = 'resolved', winner_key = v_winner, resolved_at = now()
   where gr.id = v_round.id;

  return query select v_winner, v_user_payout;
end;
$$;

grant execute on function public.zp_get_or_create_game_round(text) to authenticated;
grant execute on function public.zp_place_game_bet(text, uuid, text, bigint) to authenticated;
grant execute on function public.zp_resolve_game_round(uuid) to authenticated;

-- Explicit qualification avoids the same PL/pgSQL output-name collision for staff role RPC.
create or replace function public.zp_my_staff_role()
returns table(role text, shipping_agency boolean, status text, badge text)
language sql security definer set search_path = public as $$
  select s.role, s.shipping_agency, s.status, s.badge
    from public.zp_staff_roles as s
   where s.user_id = auth.uid()
   limit 1;
$$;
grant execute on function public.zp_my_staff_role() to authenticated;

-- Economy hardening: atomic, idempotent gifts; verified recharge rewards; VIP benefits.
alter table public.zp_wallet_transactions add column if not exists idempotency_key text;
create unique index if not exists zp_wallet_idempotency_uq
  on public.zp_wallet_transactions(user_id, idempotency_key)
  where idempotency_key is not null;

-- Promotional rewards are virtual in-app rewards. They are not cash and cannot be withdrawn.
create table if not exists public.zp_reward_grants (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.zp_profiles(id) on delete cascade,
  reward_code text not null,
  value_coins bigint not null default 0 check (value_coins >= 0),
  value_usd_cents integer not null default 0 check (value_usd_cents >= 0),
  source_reference uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(user_id, reward_code)
);
alter table public.zp_reward_grants enable row level security;
drop policy if exists reward_grants_select_self on public.zp_reward_grants;
create policy reward_grants_select_self on public.zp_reward_grants for select to authenticated using (user_id = auth.uid());

-- VIP configuration requested for the launch build. Prices below are metadata for a future
-- payment provider; the app must never pretend a payment happened until the provider verifies it.
alter table public.zp_vip_tiers add column if not exists price_usd_cents bigint not null default 0;
alter table public.zp_vip_tiers add column if not exists recharge_multiplier numeric(5,2) not null default 1.00;
alter table public.zp_vip_tiers add column if not exists welcome_bonus_coins bigint not null default 0;

update public.zp_vip_tiers set
  price_usd_cents = case level
    when 1 then 5000 when 2 then 10000 when 3 then 15000 when 4 then 25000 when 5 then 50000
    when 6 then 75000 when 7 then 100000 when 8 then 250000 when 9 then 500000 when 10 then 1000000
    when 11 then 5000 when 12 then 5000000 when 13 then 10000000000
  end,
  recharge_multiplier = case level
    when 1 then 2.00 when 2 then 2.10 when 3 then 2.20 when 4 then 2.30 when 5 then 2.50
    when 6 then 2.70 when 7 then 3.00 when 8 then 3.20 when 9 then 3.50 when 10 then 3.80
    when 11 then 4.00 when 12 then 4.50 when 13 then 5.00
  end,
  welcome_bonus_coins = case when level = 1 then 100000 else 0 end,
  perks = case level
    when 1 then '["100,000 Coins ترحيبية مرة واحدة","مضاعف شحن 2x","بادج VIP 1","إطار VIP"]'::jsonb
    when 2 then '["كل مزايا VIP 1","مضاعف شحن 2.1x","أولوية دخول"]'::jsonb
    when 3 then '["كل مزايا VIP 2","مضاعف شحن 2.2x","تأثير دخول"]'::jsonb
    when 4 then '["كل مزايا VIP 3","مضاعف شحن 2.3x","رسائل مميزة"]'::jsonb
    when 5 then '["كل مزايا VIP 4","مضاعف شحن 2.5x","هدايا حصرية"]'::jsonb
    when 6 then '["كل مزايا VIP 5","مضاعف شحن 2.7x","أولوية دعم"]'::jsonb
    when 7 then '["كل مزايا VIP 6","مضاعف شحن 3x","إطار متقدم"]'::jsonb
    when 8 then '["كل مزايا VIP 7","مضاعف شحن 3.2x","مؤثرات خاصة"]'::jsonb
    when 9 then '["كل مزايا VIP 8","مضاعف شحن 3.5x","هدايا متقدمة"]'::jsonb
    when 10 then '["كل مزايا VIP 9","مضاعف شحن 3.8x","شارة VIP 10"]'::jsonb
    when 11 then '["كل مزايا VIP 10","مضاعف شحن 4x","SVIP 11","هدايا SVIP"]'::jsonb
    when 12 then '["كل مزايا SVIP 11","مضاعف شحن 4.5x","دعم أولوية"]'::jsonb
    when 13 then '["كل مزايا SVIP 12","مضاعف شحن 5x","SVIP 13 MAX","شارة أسطورية"]'::jsonb
  end
where level between 1 and 13;

-- First recharge promotion: a virtual 50 USD-value gift/reward is granted only once,
-- after a recharge order of at least $50 has been verified as paid.
create or replace function public.zp_finalize_recharge_order(p_order_id uuid, p_provider_reference text default null)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  uid uuid := auth.uid();
  o public.zp_recharge_orders%rowtype;
  p public.zp_profiles%rowtype;
  t public.zp_vip_tiers%rowtype;
  final_coins bigint;
  bonus_coins bigint := 0;
  tid uuid;
  reward_id uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from public.zp_staff_roles s where s.user_id=uid and s.role='admin' and s.status='active') then
    raise exception 'admin_required';
  end if;
  select * into o from public.zp_recharge_orders where id=p_order_id for update;
  if o.id is null then raise exception 'order_not_found'; end if;
  if o.status = 'paid' then
    return jsonb_build_object('status','paid','order_id',o.id,'coins',o.coins);
  end if;
  if o.status <> 'pending' then raise exception 'order_not_payable'; end if;

  select * into p from public.zp_profiles where id=o.user_id for update;
  select * into t from public.zp_vip_tiers where level=p.vip_level;
  final_coins := floor(o.coins * coalesce(t.recharge_multiplier,1.0))::bigint;

  update public.zp_profiles set coins=coins+final_coins, updated_at=now() where id=o.user_id;
  update public.zp_recharge_orders set status='paid',verified_at=now() where id=o.id;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,metadata)
  select o.user_id,'recharge_verified',final_coins,coins,'recharge',o.id,
         jsonb_build_object('provider_reference',p_provider_reference,'base_coins',o.coins,'multiplier',coalesce(t.recharge_multiplier,1.0));

  -- VIP 1 one-time welcome bonus.
  if p.vip_level >= 1 and not exists(select 1 from public.zp_reward_grants where user_id=o.user_id and reward_code='vip1_welcome_100k') then
    bonus_coins := 100000;
    update public.zp_profiles set coins=coins+bonus_coins, updated_at=now() where id=o.user_id;
    insert into public.zp_reward_grants(user_id,reward_code,value_coins,metadata)
      values(o.user_id,'vip1_welcome_100k',bonus_coins,jsonb_build_object('order_id',o.id)) returning id into reward_id;
    insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,metadata)
      select o.user_id,'vip1_welcome_bonus',bonus_coins,coins,'reward',reward_id,jsonb_build_object('order_id',o.id);
  end if;

  -- First $50+ verified recharge: one-time virtual reward with a displayed $50 value.
  if o.usd_cents >= 5000 and not exists(select 1 from public.zp_reward_grants where user_id=o.user_id and reward_code='first_recharge_50_usd_gift') then
    insert into public.zp_reward_grants(user_id,reward_code,value_usd_cents,metadata)
      values(o.user_id,'first_recharge_50_usd_gift',5000,jsonb_build_object('order_id',o.id)) returning id into reward_id;
  end if;

  select coins into final_coins from public.zp_profiles where id=o.user_id;
  return jsonb_build_object('status','paid','order_id',o.id,'credited_coins',final_coins,'welcome_bonus_coins',bonus_coins,'first_recharge_gift',o.usd_cents >= 5000);
end;
$$;
grant execute on function public.zp_finalize_recharge_order(uuid,text) to authenticated;

-- Atomic gift send with an idempotency key. Repeating the same request cannot charge twice.
create or replace function public.zp_send_gift(p_receiver_id uuid,p_gift_id text,p_quantity integer,p_idempotency_key text)
returns table(ok boolean,new_sender_balance bigint,total_cost bigint,transaction_id uuid)
language plpgsql security definer set search_path=public as $$
declare
  uid uuid:=auth.uid(); sender_balance bigint; unit_price bigint; total bigint; nb bigint; tid uuid; old_tx public.zp_wallet_transactions%rowtype;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if p_idempotency_key is null or length(trim(p_idempotency_key)) < 8 then raise exception 'invalid_idempotency_key'; end if;
  select * into old_tx from public.zp_wallet_transactions where user_id=uid and idempotency_key=p_idempotency_key limit 1;
  if old_tx.id is not null then
    return query select true,old_tx.balance_after,abs(old_tx.amount),old_tx.id;
    return;
  end if;
  if p_receiver_id is null or p_receiver_id=uid then raise exception 'invalid_receiver'; end if;
  if p_quantity < 1 or p_quantity > 99 then raise exception 'invalid_quantity'; end if;
  select price into unit_price from public.zp_gifts where id=p_gift_id and enabled=true;
  if unit_price is null then raise exception 'gift_not_found'; end if;
  total:=unit_price*p_quantity;
  select coins into sender_balance from public.zp_profiles where id=uid for update;
  if sender_balance < total then raise exception 'insufficient_coins'; end if;
  nb:=sender_balance-total;
  update public.zp_profiles set coins=nb,updated_at=now() where id=uid;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,idempotency_key,metadata)
    values(uid,'gift_sent',-total,nb,'gift',p_idempotency_key,jsonb_build_object('receiver_id',p_receiver_id,'gift_id',p_gift_id,'quantity',p_quantity)) returning id into tid;
  update public.zp_profiles set coins=coins+total,updated_at=now() where id=p_receiver_id;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,metadata)
    select p_receiver_id,'gift_received',total,coins,'gift',tid,jsonb_build_object('sender_id',uid,'gift_id',p_gift_id,'quantity',p_quantity) from public.zp_profiles where id=p_receiver_id;
  return query select true,nb,total,tid;
end;
$$;
grant execute on function public.zp_send_gift(uuid,text,integer,text) to authenticated;

-- Final VIP subscription implementation: grants VIP 1's 100,000 Coins welcome bonus once.
create or replace function public.zp_subscribe_vip(p_level integer)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  uid uuid:=auth.uid(); p public.zp_profiles; t public.zp_vip_tiers; nb bigint; np bigint; nl integer; bonus bigint:=0; rid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if p_level < 1 or p_level > 13 then raise exception 'invalid_vip_level'; end if;
  select * into t from public.zp_vip_tiers where level=p_level;
  if t.level is null then raise exception 'invalid_vip_level'; end if;
  select * into p from public.zp_profiles where id=uid for update;
  if p.id is null then raise exception 'profile_not_found'; end if;
  if p_level <= p.vip_level then raise exception 'vip_level_not_higher'; end if;
  if p.coins < t.price_coins then raise exception 'insufficient_coins'; end if;
  nb:=p.coins-t.price_coins;
  np:=greatest(p.vip_points,t.min_points);
  nl:=p_level;
  update public.zp_profiles set coins=nb,vip_points=np,vip_level=nl,vip_until=greatest(coalesce(vip_until,now()),now())+interval '30 days',updated_at=now() where id=uid;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,metadata)
  values(uid,'vip_sub',-t.price_coins,nb,'vip',jsonb_build_object('level',t.level,'title',t.title));
  if nl >= 1 and not exists(select 1 from public.zp_reward_grants where user_id=uid and reward_code='vip1_welcome_100k') then
    bonus:=100000;
    update public.zp_profiles set coins=coins+bonus,updated_at=now() where id=uid;
    insert into public.zp_reward_grants(user_id,reward_code,value_coins,metadata)
      values(uid,'vip1_welcome_100k',bonus,jsonb_build_object('vip_level',nl)) returning id into rid;
    insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,metadata)
      select uid,'vip1_welcome_bonus',bonus,coins,'reward',rid,jsonb_build_object('vip_level',nl) from public.zp_profiles where id=uid;
  end if;
  select coins into nb from public.zp_profiles where id=uid;
  return jsonb_build_object('level',nl,'points',np,'coins',nb,'vip_until',(select vip_until from public.zp_profiles where id=uid),'welcome_bonus_coins',bonus,'recharge_multiplier',t.recharge_multiplier,'price_usd_cents',t.price_usd_cents);
end; $$;
grant execute on function public.zp_subscribe_vip(integer) to authenticated;


create or replace function public.zp_my_rewards()
returns table(reward_code text,value_coins bigint,value_usd_cents integer,created_at timestamptz,metadata jsonb)
language sql security definer set search_path=public as $$
  select r.reward_code,r.value_coins,r.value_usd_cents,r.created_at,r.metadata
    from public.zp_reward_grants r
   where r.user_id=auth.uid()
   order by r.created_at desc;
$$;
grant execute on function public.zp_my_rewards() to authenticated;
