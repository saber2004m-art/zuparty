-- Agent-only recharge policy.
-- Direct payment/recharge UI is intentionally disabled for all users.
-- Only an active, verified shipping agent/admin may credit Coins through zp_agent_recharge_user.
revoke execute on function public.zp_create_recharge_order(text,integer,bigint,text) from public, anon, authenticated;

-- Defensive: keep the payment-intent table readable only by the owner if it exists,
-- but no client can create new payment intents from this release.
alter table if exists public.zp_recharge_orders enable row level security;
drop policy if exists recharge_orders_insert_self on public.zp_recharge_orders;

comment on table public.zp_recharge_orders is 'Legacy payment intents retained for audit compatibility; direct client recharge is disabled. Coins may be credited only by verified shipping agents/admins via server RPC.';
