-- Zuparty production backend foundation.
-- Coins are virtual in-app currency. No cash-out or real-money wagering is implemented here.

create extension if not exists pgcrypto;

create table if not exists public.zp_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'مستخدم Zuparty',
  gender text,
  avatar_url text,
  coins bigint not null default 0 check (coins >= 0),
  level integer not null default 1 check (level >= 1),
  vip_until timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.zp_rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.zp_profiles(id) on delete cascade,
  room_code text not null unique,
  name text not null,
  image_path text,
  category text,
  description text not null default '',
  announcement text not null default '',
  is_private boolean not null default false,
  is_locked boolean not null default false,
  effect_index integer not null default 0,
  mic_seats integer not null default 9 check (mic_seats between 1 and 30),
  who_can_speak text not null default 'الجميع',
  who_can_chat text not null default 'الجميع',
  allow_guest_gifts boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.zp_room_members (
  room_id uuid not null references public.zp_rooms(id) on delete cascade,
  user_id uuid not null references public.zp_profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  seat_index integer,
  mic_muted boolean not null default true,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table if not exists public.zp_room_messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.zp_rooms(id) on delete cascade,
  sender_id uuid not null references public.zp_profiles(id) on delete cascade,
  message_type text not null default 'text',
  text text,
  created_at timestamptz not null default now()
);

create table if not exists public.zp_wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.zp_profiles(id) on delete cascade,
  type text not null,
  amount bigint not null,
  balance_after bigint,
  reference_type text,
  reference_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.zp_games (
  id text primary key,
  name text not null,
  enabled boolean not null default true,
  choices jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists public.zp_game_rounds (
  id uuid primary key default gen_random_uuid(),
  game_id text not null references public.zp_games(id) on delete cascade,
  round_no bigint not null,
  starts_at timestamptz not null default now(),
  ends_at timestamptz not null,
  status text not null default 'open' check (status in ('open','resolved')),
  winner_key text,
  resolved_at timestamptz,
  unique (game_id, round_no)
);

create table if not exists public.zp_game_bets (
  id uuid primary key default gen_random_uuid(),
  round_id uuid not null references public.zp_game_rounds(id) on delete cascade,
  game_id text not null references public.zp_games(id) on delete cascade,
  user_id uuid not null references public.zp_profiles(id) on delete cascade,
  choice text not null,
  amount bigint not null check (amount > 0),
  payout bigint not null default 0,
  created_at timestamptz not null default now()
);

insert into public.zp_games(id,name,choices) values
('lucky_fruit','Lucky Fruit','[{"key":"cherry","mult":5},{"key":"grape","mult":5},{"key":"lemon","mult":5},{"key":"peach","mult":5},{"key":"strawberry","mult":45},{"key":"mango","mult":25},{"key":"watermelon","mult":15},{"key":"apple","mult":10}]'::jsonb),
('greedy_pro','Greedy Pro','[{"key":"bread","mult":5},{"key":"skewer","mult":5},{"key":"ham","mult":5},{"key":"steak","mult":5},{"key":"carrot","mult":10},{"key":"corn","mult":15},{"key":"cabbage","mult":25},{"key":"tomato","mult":45}]'::jsonb)
on conflict (id) do update set name=excluded.name, choices=excluded.choices;

create index if not exists zp_room_messages_room_created_idx on public.zp_room_messages(room_id, created_at desc);
create index if not exists zp_game_bets_round_idx on public.zp_game_bets(round_id);

alter table public.zp_profiles enable row level security;
alter table public.zp_rooms enable row level security;
alter table public.zp_room_members enable row level security;
alter table public.zp_room_messages enable row level security;
alter table public.zp_wallet_transactions enable row level security;
alter table public.zp_games enable row level security;
alter table public.zp_game_rounds enable row level security;
alter table public.zp_game_bets enable row level security;

drop policy if exists profiles_select_authenticated on public.zp_profiles;
create policy profiles_select_authenticated on public.zp_profiles for select to authenticated using (true);
drop policy if exists profiles_insert_self on public.zp_profiles;
create policy profiles_insert_self on public.zp_profiles for insert to authenticated with check (id = auth.uid());
-- IMPORTANT: no direct UPDATE policy on zp_profiles. Coins must never be client-writable.

drop policy if exists rooms_select_authenticated on public.zp_rooms;
create policy rooms_select_authenticated on public.zp_rooms for select to authenticated using (true);
drop policy if exists rooms_insert_owner on public.zp_rooms;
create policy rooms_insert_owner on public.zp_rooms for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists rooms_update_owner on public.zp_rooms;
create policy rooms_update_owner on public.zp_rooms for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

drop policy if exists room_members_select on public.zp_room_members;
create policy room_members_select on public.zp_room_members for select to authenticated using (true);
drop policy if exists room_members_insert_self on public.zp_room_members;
create policy room_members_insert_self on public.zp_room_members for insert to authenticated with check (user_id = auth.uid());
drop policy if exists room_members_delete_self on public.zp_room_members;
create policy room_members_delete_self on public.zp_room_members for delete to authenticated using (user_id = auth.uid());
drop policy if exists room_messages_select on public.zp_room_messages;
create policy room_messages_select on public.zp_room_messages for select to authenticated using (true);
drop policy if exists room_messages_insert_self on public.zp_room_messages;
create policy room_messages_insert_self on public.zp_room_messages for insert to authenticated with check (sender_id = auth.uid());

drop policy if exists wallet_select_self on public.zp_wallet_transactions;
create policy wallet_select_self on public.zp_wallet_transactions for select to authenticated using (user_id = auth.uid());

drop policy if exists games_select on public.zp_games;
create policy games_select on public.zp_games for select to authenticated using (enabled = true);
drop policy if exists rounds_select on public.zp_game_rounds;
create policy rounds_select on public.zp_game_rounds for select to authenticated using (true);
drop policy if exists bets_select_self on public.zp_game_bets;
create policy bets_select_self on public.zp_game_bets for select to authenticated using (user_id = auth.uid());

-- Profile creation for anonymous/authenticated users.
create or replace function public.zp_touch_profile()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.zp_profiles(id) values (new.id) on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_zp on auth.users;
create trigger on_auth_user_created_zp after insert on auth.users for each row execute function public.zp_touch_profile();
insert into public.zp_profiles(id) select id from auth.users on conflict (id) do nothing;

-- Round creation: exactly one open round per game at a time.
create or replace function public.zp_get_or_create_game_round(p_game_id text)
returns table(id uuid, game_id text, round_no bigint, starts_at timestamptz, ends_at timestamptz, status text)
language plpgsql security definer set search_path = public as $$
declare
  r public.zp_game_rounds;
  next_no bigint;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from public.zp_games as g where g.id=p_game_id and g.enabled=true) then raise exception 'game_disabled'; end if;
  perform pg_advisory_xact_lock(hashtext(p_game_id));
  select gr.* into r from public.zp_game_rounds as gr where gr.game_id=p_game_id and gr.status='open' and gr.ends_at > now() order by gr.round_no desc limit 1;
  if r.id is null then
    select coalesce(max(gr.round_no),0)+1 into next_no from public.zp_game_rounds as gr where gr.game_id=p_game_id;
    insert into public.zp_game_rounds(game_id,round_no,starts_at,ends_at)
      values(p_game_id,next_no,now(),now()+interval '30 seconds') returning * into r;
  end if;
  return query select r.id,r.game_id,r.round_no,r.starts_at,r.ends_at,r.status;
end;
$$;

-- Atomic virtual-coin bet. Client cannot directly update the balance.
create or replace function public.zp_place_game_bet(p_game_id text,p_round_id uuid,p_choice text,p_amount bigint)
returns table(ok boolean,new_balance bigint,bet_id uuid)
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  bal bigint;
  r public.zp_game_rounds;
  valid_choice boolean;
  new_bal bigint;
  bid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if p_amount <= 0 or p_amount > 10000000 then raise exception 'invalid_amount'; end if;
  select * into r from public.zp_game_rounds where id=p_round_id and game_id=p_game_id for update;
  if r.id is null or r.status <> 'open' or r.ends_at <= now() then raise exception 'round_closed'; end if;
  select exists(select 1 from public.zp_games g, jsonb_array_elements(g.choices) c where g.id=p_game_id and c->>'key'=p_choice) into valid_choice;
  if not valid_choice then raise exception 'invalid_choice'; end if;
  select coins into bal from public.zp_profiles where id=uid for update;
  if bal < p_amount then raise exception 'insufficient_coins'; end if;
  new_bal := bal - p_amount;
  update public.zp_profiles set coins=new_bal,updated_at=now() where id=uid;
  insert into public.zp_game_bets(round_id,game_id,user_id,choice,amount) values(r.id,p_game_id,uid,p_choice,p_amount) returning id into bid;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id) values(uid,'game_bet',-p_amount,new_bal,'game_bet',bid);
  return query select true,new_bal,bid;
end;
$$;

-- Server-authoritative result. It can only resolve after the timer ends and only once.
create or replace function public.zp_resolve_game_round(p_round_id uuid)
returns table(winner_key text,payout bigint)
language plpgsql security definer set search_path = public as $$
declare
  r public.zp_game_rounds;
  choice jsonb;
  uid uuid := auth.uid();
  b record;
  mult integer;
  p bigint;
  user_payout bigint := 0;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  select * into r from public.zp_game_rounds where id=p_round_id for update;
  if r.id is null then raise exception 'round_not_found'; end if;
  if r.status='resolved' then return query select r.winner_key,coalesce((select sum(payout) from public.zp_game_bets where round_id=r.id and user_id=uid),0); return; end if;
  if r.ends_at > now() then raise exception 'round_not_finished'; end if;
  select c into choice from public.zp_games g, jsonb_array_elements(g.choices) c where g.id=r.game_id order by random() limit 1;
  r.winner_key := choice->>'key';
  mult := (choice->>'mult')::int;
  for b in select id,user_id,amount from public.zp_game_bets where round_id=r.id for update loop
    p := case when b.choice=r.winner_key then b.amount*mult else 0 end;
    update public.zp_game_bets set payout=p where id=b.id;
    if p > 0 then
      update public.zp_profiles set coins=coins+p,updated_at=now() where id=b.user_id;
      insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id)
        select b.user_id,'game_win',p,coins,'game_win',b.id from public.zp_profiles where id=b.user_id;
      if b.user_id = uid then user_payout := user_payout + p; end if;
    end if;
  end loop;
  update public.zp_game_rounds set status='resolved',winner_key=r.winner_key,resolved_at=now() where id=r.id;
  return query select r.winner_key,user_payout;
end;
$$;

grant execute on function public.zp_get_or_create_game_round(text) to authenticated;
grant execute on function public.zp_place_game_bet(text,uuid,text,bigint) to authenticated;
grant execute on function public.zp_resolve_game_round(uuid) to authenticated;



-- Server-authoritative profile update. Coins are intentionally excluded.
create or replace function public.zp_update_my_profile(p_display_name text default null, p_gender text default null, p_avatar_url text default null)
returns public.zp_profiles
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); row public.zp_profiles;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  update public.zp_profiles
     set display_name=coalesce(nullif(trim(p_display_name),''),display_name),
         gender=coalesce(p_gender,gender),
         avatar_url=coalesce(p_avatar_url,avatar_url),
         updated_at=now()
   where id=uid
   returning * into row;
  if row.id is null then raise exception 'profile_not_found'; end if;
  return row;
end;
$$;
grant execute on function public.zp_update_my_profile(text,text,text) to authenticated;

-- Server-authoritative gift catalog and atomic gift transfer.
create table if not exists public.zp_gifts (
  id text primary key,
  name text not null,
  emoji text not null,
  price bigint not null check (price > 0),
  enabled boolean not null default true
);
insert into public.zp_gifts(id,name,emoji,price) values
('rose','وردة','🌹',10),
('heart','قلب','❤️',20),
('crown','تاج','👑',500),
('car','سيارة','🚗',2000),
('7777','7777','🎁',7777)
on conflict (id) do update set name=excluded.name,emoji=excluded.emoji,price=excluded.price,enabled=true;
alter table public.zp_gifts enable row level security;
drop policy if exists gifts_select_enabled on public.zp_gifts;
create policy gifts_select_enabled on public.zp_gifts for select to authenticated using (enabled=true);

create or replace function public.zp_send_gift(p_receiver_id uuid,p_gift_id text,p_quantity integer default 1)
returns table(ok boolean,new_sender_balance bigint,total_cost bigint,transaction_id uuid)
language plpgsql security definer set search_path=public as $$
declare
  uid uuid:=auth.uid(); sender_balance bigint; receiver_exists boolean; unit_price bigint; total bigint; nb bigint; tid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if p_receiver_id is null or p_receiver_id=uid then raise exception 'invalid_receiver'; end if;
  if p_quantity < 1 or p_quantity > 99 then raise exception 'invalid_quantity'; end if;
  select exists(select 1 from public.zp_profiles where id=p_receiver_id) into receiver_exists;
  if not receiver_exists then raise exception 'receiver_not_found'; end if;
  select price into unit_price from public.zp_gifts where id=p_gift_id and enabled=true;
  if unit_price is null then raise exception 'gift_not_found'; end if;
  total := unit_price * p_quantity;
  select coins into sender_balance from public.zp_profiles where id=uid for update;
  if sender_balance < total then raise exception 'insufficient_coins'; end if;
  nb := sender_balance-total;
  update public.zp_profiles set coins=nb,updated_at=now() where id=uid;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,metadata)
    values(uid,'gift_sent',-total,nb,'gift',jsonb_build_object('receiver_id',p_receiver_id,'gift_id',p_gift_id,'quantity',p_quantity)) returning id into tid;
  update public.zp_profiles set coins=coins+total,updated_at=now() where id=p_receiver_id;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,metadata)
    select p_receiver_id,'gift_received',total,coins,'gift',tid,jsonb_build_object('sender_id',uid,'gift_id',p_gift_id,'quantity',p_quantity)
      from public.zp_profiles where id=p_receiver_id;
  return query select true,nb,total,tid;
end;
$$;
grant execute on function public.zp_send_gift(uuid,text,integer) to authenticated;

-- Wagering RPCs are disabled in this safe build.

-- Server-side staff/agent system. Role changes are never trusted from the client.
create table if not exists public.zp_staff_roles (
  user_id uuid primary key references public.zp_profiles(id) on delete cascade,
  role text not null check (role in ('admin','agent')),
  shipping_agency boolean not null default false,
  status text not null default 'active' check (status in ('active','suspended')),
  badge text not null default 'وكيل شحن Zuparty',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.zp_staff_roles add column if not exists shipping_agency boolean not null default false;

create table if not exists public.zp_agent_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.zp_profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  note text not null default '',
  reviewed_by uuid references public.zp_profiles(id),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

alter table public.zp_staff_roles enable row level security;
alter table public.zp_agent_applications enable row level security;

create or replace function public.zp_my_staff_role()
returns table(role text,shipping_agency boolean,status text,badge text)
language sql security definer set search_path=public as $$
  select role,shipping_agency,status,badge from public.zp_staff_roles where user_id=auth.uid() limit 1;
$$;

grant execute on function public.zp_my_staff_role() to authenticated;

create or replace function public.zp_apply_agent(p_note text default '')
returns table(id uuid,status text)
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); aid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  insert into public.zp_agent_applications(user_id,note)
  values(uid,coalesce(p_note,''))
  on conflict(user_id) do update set note=excluded.note, status=case when public.zp_agent_applications.status='rejected' then 'pending' else public.zp_agent_applications.status end;
  select a.id,a.status into aid,status from public.zp_agent_applications a where a.user_id=uid;
  return query select aid,status;
end;
$$;
grant execute on function public.zp_apply_agent(text) to authenticated;

create or replace function public.zp_agent_recharge_user(p_user_id uuid,p_coins bigint,p_note text default '')
returns table(ok boolean,new_balance bigint,transaction_id uuid)
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); agent_ok boolean; bal bigint; nb bigint; tid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select exists(select 1 from public.zp_staff_roles where user_id=uid and status='active' and (role='agent' or role='admin')) into agent_ok;
  if not agent_ok then raise exception 'agent_required'; end if;
  if p_coins<=0 or p_coins>1000000000 then raise exception 'invalid_coins'; end if;
  select coins into bal from public.zp_profiles where id=p_user_id for update;
  if bal is null then raise exception 'user_not_found'; end if;
  nb:=bal+p_coins;
  update public.zp_profiles set coins=nb,updated_at=now() where id=p_user_id;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,metadata)
  values(p_user_id,'agent_recharge',p_coins,nb,'agent_recharge',jsonb_build_object('agent_id',uid,'note',coalesce(p_note,''))) returning id into tid;
  return query select true,nb,tid;
end;
$$;
grant execute on function public.zp_agent_recharge_user(uuid,bigint,text) to authenticated;

create or replace function public.zp_admin_review_agent(p_application_id uuid,p_approve boolean,p_note text default '')
returns table(ok boolean,status text)
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); app public.zp_agent_applications;
 admin_ok boolean;
begin
  select exists(select 1 from public.zp_staff_roles where user_id=uid and role='admin' and status='active') into admin_ok;
  if not admin_ok then raise exception 'admin_required'; end if;
  select * into app from public.zp_agent_applications where id=p_application_id for update;
  if app.id is null then raise exception 'application_not_found'; end if;
  if p_approve then
    insert into public.zp_staff_roles(user_id,role,shipping_agency,status,badge) values(app.user_id,'agent',true,'active','وكيل شحن Zuparty')
    on conflict(user_id) do update set shipping_agency=true,status='active',badge='وكيل شحن Zuparty',updated_at=now();
    update public.zp_agent_applications set status='approved',reviewed_by=uid,reviewed_at=now(),note=coalesce(p_note,note) where id=app.id;
  else
    update public.zp_staff_roles set shipping_agency=false,updated_at=now() where user_id=app.user_id;
    update public.zp_agent_applications set status='rejected',reviewed_by=uid,reviewed_at=now(),note=coalesce(p_note,note) where id=app.id;
  end if;
  return query select true,(select status from public.zp_agent_applications where id=app.id);
end;
$$;
grant execute on function public.zp_admin_review_agent(uuid,boolean,text) to authenticated;

create or replace function public.zp_admin_list_agent_applications()
returns table(id uuid,user_id uuid,status text,note text,created_at timestamptz,display_name text)
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); ok boolean;
begin
  select exists(select 1 from public.zp_staff_roles where user_id=uid and role='admin' and status='active') into ok;
  if not ok then raise exception 'admin_required'; end if;
  return query select a.id,a.user_id,a.status,a.note,a.created_at,p.display_name
    from public.zp_agent_applications a join public.zp_profiles p on p.id=a.user_id order by a.created_at desc;
end;
$$;
grant execute on function public.zp_admin_list_agent_applications() to authenticated;


-- Company owner bootstrap: run this once after the company's Auth user exists.
-- Replace the email with the company's email. This keeps the account as ADMIN and
-- enables the shipping-agency capability at the same time.
create or replace function public.zp_set_company_admin(p_email text)
returns table(user_id uuid,email text,role text,shipping_agency boolean)
language plpgsql security definer set search_path=public as $$
declare target_id uuid;
begin
  if p_email is null or length(trim(p_email)) < 3 then raise exception 'invalid_email'; end if;
  if exists(select 1 from public.zp_staff_roles where role='admin' and status='active') then
    raise exception 'admin_already_exists';
  end if;
  select id into target_id from auth.users where lower(email)=lower(trim(p_email)) limit 1;
  if target_id is null then raise exception 'user_not_found'; end if;
  insert into public.zp_staff_roles(user_id,role,shipping_agency,status,badge)
  values(target_id,'admin',true,'active','إدارة Zuparty • وكالة شحن')
  on conflict(user_id) do update set role='admin',shipping_agency=true,status='active',badge='إدارة Zuparty • وكالة شحن',updated_at=now();
  return query select target_id,trim(p_email),'admin'::text,true;
end;
$$;
revoke execute on function public.zp_set_company_admin(text) from public,anon,authenticated;

-- Coins are protected by column privileges: clients may not UPDATE the coins column.
alter table public.zp_profiles alter column coins set default 0;
revoke update(coins) on public.zp_profiles from authenticated;

-- Recharge orders are payment intents only. They never credit Coins by themselves.
create table if not exists public.zp_recharge_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.zp_profiles(id) on delete cascade,
  package_id text not null,
  usd_cents integer not null check (usd_cents > 0),
  coins bigint not null check (coins > 0),
  payment_method text not null,
  status text not null default 'pending' check (status in ('pending','paid','rejected','expired')),
  created_at timestamptz not null default now(),
  verified_at timestamptz
);

create index if not exists zp_recharge_orders_user_created_idx on public.zp_recharge_orders(user_id, created_at desc);
alter table public.zp_recharge_orders enable row level security;
drop policy if exists recharge_orders_select_self on public.zp_recharge_orders;
create policy recharge_orders_select_self on public.zp_recharge_orders for select to authenticated using (user_id = auth.uid());

create or replace function public.zp_create_recharge_order(p_package_id text,p_usd_cents integer,p_coins bigint,p_payment_method text)
returns table(id uuid,status text)
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); oid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if p_usd_cents not in (1000,5000,10000) then raise exception 'invalid_package'; end if;
  if p_coins not in (35000000,175000000,350000000) then raise exception 'invalid_coins'; end if;
  insert into public.zp_recharge_orders(user_id,package_id,usd_cents,coins,payment_method)
  values(uid,p_package_id,p_usd_cents,p_coins,p_payment_method) returning id into oid;
  return query select oid,'pending'::text;
end;
$$;

grant execute on function public.zp_create_recharge_order(text,integer,bigint,text) to authenticated;

-- Requested clean launch state: existing test profiles start with zero Coins.
update public.zp_profiles set coins=0, updated_at=now();

-- Legacy game/wallet transfer RPC removed: the live games now settle directly into zp_profiles.coins.


-- Server-authoritative VIP progression/subscription.
alter table public.zp_profiles add column if not exists vip_points bigint not null default 0 check (vip_points >= 0);
alter table public.zp_profiles add column if not exists vip_level integer not null default 1 check (vip_level between 1 and 13);

create table if not exists public.zp_vip_tiers (
  level integer primary key check (level between 1 and 13),
  title text not null,
  price_coins bigint not null check (price_coins > 0),
  min_points bigint not null check (min_points >= 0),
  perks jsonb not null default '[]'::jsonb,
  color_hex text not null default '#FF5722'
);

insert into public.zp_vip_tiers(level,title,price_coins,min_points,perks,color_hex) values
(1,'VIP 1',500,0,'["بادج VIP مميز","دخول أولوية للغرف","إطار صورة حصري"]','#F9A825'),
(2,'VIP 2',1000,2000,'["كل مزايا VIP 1","تأثير دخول للغرفة","رسائل ملونة"]','#FF7043'),
(3,'VIP 3',1500,6000,'["كل مزايا VIP 2","مزايا VIP 3"]','#FF8A65'),
(4,'VIP 4',2000,12000,'["كل مزايا VIP 3","مزايا VIP 4"]','#FF7043'),
(5,'VIP 5',2500,20000,'["كل مزايا VIP 4","مزايا VIP 5"]','#EF5350'),
(6,'VIP 6',3000,30000,'["كل مزايا VIP 5","مزايا VIP 6"]','#EC407A'),
(7,'VIP 7',3500,45000,'["كل مزايا VIP 6","مزايا VIP 7"]','#AB47BC'),
(8,'VIP 8',4000,65000,'["كل مزايا VIP 7","مزايا VIP 8"]','#7E57C2'),
(9,'VIP 9',4500,90000,'["كل مزايا VIP 8","مزايا VIP 9"]','#5E35B1'),
(10,'VIP 10',5000,120000,'["كل مزايا VIP 9","مزايا VIP 10"]','#4527A0'),
(11,'SVIP 11',6000,160000,'["كل مزايا VIP 10","هدايا SVIP حصرية"]','#3949AB'),
(12,'SVIP 12',7000,220000,'["كل مزايا SVIP 11","دعم أولوية"]','#1E88E5'),
(13,'SVIP 13',8000,300000,'["كل مزايا SVIP 12","بادج SVIP متقدم"]','#00ACC1')
on conflict(level) do update set title=excluded.title,price_coins=excluded.price_coins,min_points=excluded.min_points,perks=excluded.perks,color_hex=excluded.color_hex;

alter table public.zp_vip_tiers enable row level security;
drop policy if exists vip_tiers_select_authenticated on public.zp_vip_tiers;
create policy vip_tiers_select_authenticated on public.zp_vip_tiers for select to authenticated using (true);


create or replace function public.zp_get_vip_status()
returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); p public.zp_profiles; tier jsonb; next_tier jsonb;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into p from public.zp_profiles where id=uid;
  if p.id is null then raise exception 'profile_not_found'; end if;
  select jsonb_build_object('level',v.level,'title',v.title,'price_coins',v.price_coins,'min_points',v.min_points,'perks',v.perks,'color_hex',v.color_hex)
    into tier from public.zp_vip_tiers v where v.level=p.vip_level;
  select jsonb_build_object('level',v.level,'title',v.title,'price_coins',v.price_coins,'min_points',v.min_points,'perks',v.perks,'color_hex',v.color_hex)
    into next_tier from public.zp_vip_tiers v where v.level=p.vip_level+1;
  return jsonb_build_object('level',p.vip_level,'points',p.vip_points,'coins',p.coins,'vip_until',p.vip_until,'current',tier,'next',next_tier);
end; $$;


create or replace function public.zp_subscribe_vip(p_level integer)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); p public.zp_profiles; t public.zp_vip_tiers; nb bigint; np bigint; nl integer;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into t from public.zp_vip_tiers where level=p_level;
  if t.level is null then raise exception 'invalid_vip_level'; end if;
  select * into p from public.zp_profiles where id=uid for update;
  if p.id is null then raise exception 'profile_not_found'; end if;
  if p.coins < t.price_coins then raise exception 'insufficient_coins'; end if;
  nb:=p.coins-t.price_coins;
  np:=greatest(p.vip_points,t.min_points);
  nl:=greatest(p.vip_level,p_level);
  update public.zp_profiles set coins=nb,vip_points=np,vip_level=nl,vip_until=greatest(coalesce(vip_until,now()),now())+interval '30 days',updated_at=now() where id=uid;
  insert into public.zp_wallet_transactions(user_id,type,amount,balance_after,reference_type,metadata)
  values(uid,'vip_sub',-t.price_coins,nb,'vip',jsonb_build_object('level',t.level,'title',t.title));
  return jsonb_build_object('level',nl,'points',np,'coins',nb,'vip_until',(select vip_until from public.zp_profiles where id=uid));
end; $$;

grant execute on function public.zp_get_vip_status() to authenticated;
grant execute on function public.zp_subscribe_vip(integer) to authenticated;

-- Recompute level from points for existing accounts.
update public.zp_profiles p
set vip_level=coalesce((select max(v.level) from public.zp_vip_tiers v where v.min_points <= p.vip_points),1)
where vip_level is null or vip_level < 1;
