# Zuparty invite page

This page is intentionally independent from the Flutter app. It handles Supabase invitation sessions and lets the invited company user set a password before using the Android APK.

Publish this directory at a stable HTTPS URL, then use that URL as the Supabase Site URL only if you are using it specifically for the invitation flow. For a production app with normal email confirmation, use a dedicated auth callback/deep-link configuration instead of changing the global Site URL blindly.
