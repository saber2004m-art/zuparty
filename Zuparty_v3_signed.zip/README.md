# Zuparty — واجهة أولية (UI فقط) — نسخة محدّثة

## كيفية التشغيل

1. تأكد أن Flutter مثبت عندك: https://docs.flutter.dev/get-started/install
2. فك ضغط الملف وادخل للمجلد:
   ```
   cd zuparty
   ```
3. حمّل الاعتماديات:
   ```
   flutter pub get
   ```
4. شغّل التطبيق:
   ```
   flutter run
   ```

## محتوى الشاشات (كلها فارغة/مؤقتة، UI فقط بلا وظائف حقيقية)

- **رأسية**: دائرة بحث + إطار فيه 4 مربعات فارغة (اختصارات تطبيقات) + 3 مربعات فارغة تحتهم
- **غرفة**: إطار فيه دائرة بعلامة + فالنص
- **دردشة**: دائرتين على اليسار (أيقونة تطبيقات + أيقونة هدية)
- **بروفيل**: إطار فيه دائرة فارغة للصورة + أزرار (دعوة الأصدقاء، VIP، SVIP، خدمة العملاء، الإعدادات) + 3 دوائر صغار فالأسفل (جوج فيهم + ووحدة فارغة)

## الخطوة الجاية

- ربط شاشة الغرفة بنظام صوتي حقيقي (LiveKit / Agora)
- ربط تسجيل الدخول والبروفيل بـ backend حقيقي
- إضافة منطق الألعاب والاختصارات

## ملاحظات معروفة (Phase 1)

- التطبيق حاليًا مثبّت على `Directionality: RTL` بشكل كامل عبر `MaterialApp.builder` لأن المحتوى كله عربي. هذا طبيعي فهاد المرحلة، وغادي يتبدّل لنظام ديناميكي (RTL/LTR حسب اللغة المختارة) فمرحلة تعدد اللغات (i18n).
- الخط المستعمل حاليًا هو خط النظام الافتراضي (بلا Font مخصص مرفق فالمشروع). إذا تزاد خط زعما "Cairo" فـ `assets/fonts/` ويتصرح فـ `pubspec.yaml` تحت `flutter/fonts`، يقدر يترتبط فـ `lib/theme/app_theme.dart`.

## كيفاش تحط صور ديالك بدل الأيقونات

1. حط الصور ديالك (PNG/JPG) جوة المجلد `assets/images/`
   مثال: `assets/images/search.png`
2. فملف `pubspec.yaml` هادشي راه مكتوب ديجا:
   ```yaml
   flutter:
     assets:
       - assets/images/
   ```
3. فملف `lib/main.dart`، الدوائر (`_CircleIcon`) تقدر تاخد صورة بدل الأيقونة:
   ```dart
   // بدل
   const _CircleIcon(icon: Icons.search),
   // كتب
   const _CircleIcon(imagePath: 'assets/images/search.png'),
   ```
4. بعد ما تزيد الصور، دير:
   ```
   flutter pub get
   flutter run
   ```

نفس الطريقة تصدق على أيقونات الشريط السفلي (`BottomNavigationBarItem`) — بدل `Icon(_icons[i])` بـ `Image.asset('assets/images/your_icon.png')`.


## Latest visual update
- App launcher icon uses the supplied Zuparty game-cat image.
- Account sign-up/login screen uses the supplied purple social image as its background.


## Production launch path
- Android APK remains supported.
- Flutter Web scaffold is included for Supabase invitation redirects and a browser-accessible version.
- Company owner should be assigned with `zp_set_company_admin()` once.
- Normal users have no staff role by default.

## Company / roles
- Company account: `admin` + `shipping_agency=true`.
- Normal accounts: no row in `zp_staff_roles` and therefore no staff permissions.
- Run `select * from public.zp_set_company_admin('COMPANY_EMAIL');` once from Supabase SQL Editor after the company Auth user exists.
- See `COMPANY_SETUP.md` for the exact launch checklist.


## Live backend fix (2026-08-31)
- Fixed the PostgreSQL `game_id` ambiguity in `zp_get_or_create_game_round` by qualifying round-table columns.
- Re-enabled server-authoritative game betting and round resolution from Flutter.
- Added server-backed VIP state/subscription with VIP 1-10 and SVIP 11-13.
- Coins remain server-authoritative; the client never writes the Coins balance directly.
- No cash-out or real-money wagering is implemented by these game RPCs.

**Important:** this package still contains legacy mock/local UI in several non-game screens (friends, some room controls, notifications, rankings, etc.). They are not claimed as fully live until their corresponding Supabase tables/RPCs are wired.


## Runtime hardening (2026-08-31)
- Added `supabase/migrations/20260831220000_runtime_hardening.sql`.
- The game RPCs now use explicit table aliases/local variables to prevent `game_id` PL/pgSQL ambiguity.
- Staff-role lookup is also explicitly qualified.
- APK version bumped to `1.0.0+4`.

## Verification note
The source package was inspected after the fix. The environment used for this build review does not contain the Flutter SDK or a live Supabase SQL connection, so a device APK build and live RPC execution cannot be honestly claimed from this environment. The required server migration is included in the package.


## Production hardening pass — 2026-09-01
- Real room voice screens no longer seed members/chat/gift history from MockData; they start empty and load room members/messages from Supabase.
- Room preview no longer shows fabricated online users.
- Production search now queries `zp_profiles` for real users instead of local fixture users.
- Game search is intentionally not fabricated from local fixtures; it stays empty until the game catalog is wired to the production screen.
- No credentials or service-role secrets were added to the Flutter client.

This pass intentionally avoids changing the existing wallet, gift, recharge, VIP, room-seat, Agora, or game RPC contracts.
