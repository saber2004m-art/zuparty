# Payment integration status

This build adds server-backed recharge packages and creates a `zp_recharge_orders` payment-intent record in Supabase. It does **not** automatically credit Coins from a real USDT transfer.

Packages:
- $10 → 35,000,000 Coins
- $50 → 175,000,000 Coins
- $100 → 350,000,000 Coins

A production USDT gateway/webhook must verify the blockchain transaction server-side before changing an order to `paid` and crediting the user. The app intentionally does not contain private keys, service-role keys, or client-side balance mutation for recharge.
