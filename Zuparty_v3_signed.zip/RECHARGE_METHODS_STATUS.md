# Recharge methods — temporary state

Current public app state:
- Binance Pay: OFF / hidden
- USDT BEP20: OFF / hidden
- Other online payment methods: OFF / hidden
- Public recharge package UI: hidden
- Wallet balance and transaction history: still visible

Future manual/agent recharge:
- Keep it server-side and expose it only through the future admin/agent panel.
- Do not credit Coins from the Flutter client.
- Every manual recharge should create an auditable transaction with user, operator, amount, before/after balance, timestamp and reference.

The existing `zp_recharge_orders` table remains available for future payment integration, but the public Flutter UI does not create recharge orders while methods are disabled.
