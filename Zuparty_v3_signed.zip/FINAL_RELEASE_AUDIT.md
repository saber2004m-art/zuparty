# Zuparty — Final Candidate Static Audit (2026-09-01)

## Hardening completed in this package
- Real room member state is server-backed.
- Real room chat history is loaded from `zp_room_messages`.
- Real room preview no longer injects fake online users.
- User search uses the server profile table.
- Existing wallet, gift, recharge, VIP, Agora-token, seat and room-setting RPC contracts were not redesigned.
- Service-role / Agora certificate values are not embedded as client secrets; the certificate is referenced only as a server environment variable.
- Existing release hardening migration revokes client execution of `zp_apply_agent`.

## Important honesty boundary
This is a **final candidate for developer handoff**, not a claim that runtime testing was performed here. Flutter/Dart, the user's production Supabase project, and physical Agora devices are not available in this environment.

## Remaining production wiring
Legacy fixture data still exists in some screens where a corresponding production query/RPC is not present yet (rankings, some social/friends states, notifications, events, some gift history, and game catalog presentation). It has not been silently represented as live data.

The developer should run the supplied migrations in timestamp order, configure server-only environment variables, then run:
1. `flutter analyze`
2. `flutter test`
3. `flutter build apk --release`
4. Supabase migration/deployment
5. two-device Agora test
6. wallet/gift/recharge concurrency tests

## Security note
Do not place Supabase service-role keys, database passwords, or Agora App Certificate in Flutter/Dart source or APK. Keep them in the server/Edge Function environment only.

## Second pass — issues found and fixed in this package
A closer read of the actual code (not just this document) surfaced problems the previous audit pass did not catch. All were fixed directly in this candidate:

- `AndroidManifest.xml` was missing `INTERNET`/`ACCESS_NETWORK_STATE` permissions — the release APK could not have reached Supabase or Agora at all. Added, along with `CAMERA`/media permissions needed by the profile-photo picker.
- The Settings → Policies screen only showed "coming soon" toasts for Privacy Policy / Terms of Service / Child Safety Standards. Store submission requires real, reachable policy content. Replaced with real in-app policy screens (generic boilerplate — still needs legal review and real company contact details before submission).
- "Delete Account" only showed a local toast and deleted nothing. Added a real `delete-account` Edge Function (service-role, deletes only the authenticated caller's own account) and wired the button to it.
- "Logout" never actually called `auth.signOut()` — it only popped the navigation stack, leaving the Supabase session alive. Fixed to sign out and rebuild `AuthGate`.

## Still an honest boundary
None of the above was compiled or run — this environment has no Flutter SDK, no Android/Gradle toolchain, and no network access to a live Supabase project or physical Agora devices. The developer must still run `flutter analyze`, `flutter test`, a real release build, and the two-device Agora/wallet tests before shipping. The pre-existing Mock/local screens (rankings, followers/following, badges, notifications, some gift history, game catalog) and the real payment webhook were **not** touched in this pass and remain open scope, as already stated above.
