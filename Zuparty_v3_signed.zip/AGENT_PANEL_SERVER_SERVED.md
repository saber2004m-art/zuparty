# Remote Agent Panel

The recharge panel is served by the Supabase Edge Function `agent-panel`, not bundled as a static Flutter screen. The Flutter app opens the server URL with the current user session token. Approval/revocation is therefore role-driven by server state and does not require a new app release.
