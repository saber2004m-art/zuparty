# Zuparty — 99% Release Candidate Audit

## Verified in the package
- Server-authoritative wallet mutations for game bets, rewards, gifts, VIP and agent recharge.
- Gift transfer uses an idempotency key to prevent duplicate charging.
- Direct user recharge is revoked; recharge is restricted to an active shipping agent/admin with the shipping-agency capability.
- VIP/SVIP tiers 1..13 are stored server-side.
- Account progression is server-side with 10 account levels and XP.
- Supabase migrations are ordered by timestamp and include runtime hardening, agent-only recharge, social tables, and account levels.
- 1,104 project assets are present under `assets/`.
- ZIP archive integrity was checked after packaging.

## Runtime verification still required outside this environment
1. Run all Supabase migrations against the actual project and confirm each migration succeeds.
2. Build with Flutter (`flutter pub get`, `flutter analyze`, `flutter test`, `flutter build apk --release`).
3. Test on a physical Android device: login, wallet, gift, game bet/resolve, VIP/SVIP, room join/leave, chat, and agent recharge.
4. Test Agora credentials and reconnect behavior with a real project.
5. Verify the company account in the real Supabase project as `admin + shipping_agency`.

## Important truth about "99%"
This package is a **99% release-candidate package**, not a claim that a real APK was compiled and device-tested here. The environment does not contain Flutter SDK and cannot execute migrations against the user's Supabase project. Those two external checks are the remaining release gates.

## Economy rules included
- Game balance uses the same server wallet/Coins ledger.
- Gift sends debit sender and credit receiver atomically.
- VIP 1..10 and SVIP 11..13 are server-side.
- VIP 1 welcome reward is one-time.
- First-recharge offer is one-time and must be finalized by a trusted server-side payment/recharge event; the client cannot self-confirm payment.
- Shipping recharge is agent-only.

## Official support contact
- Complaint/support email configured in the app: `didin2004m@gmail.com`.
- Support topics open the device email composer with the topic prefilled.
