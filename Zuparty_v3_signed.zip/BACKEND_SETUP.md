# Zuparty backend setup — required once

The Flutter project is wired to Supabase and Agora, but two server-side actions must be completed in the dashboards before a release build can use live voice/database features.

## 1. Supabase

Project URL is already configured in `lib/services/zuparty_backend.dart`.

1. In Supabase Dashboard → Authentication → Providers, enable **Anonymous Sign-Ins**.
2. Run `supabase/migrations/20260831000000_zuparty_backend.sql` in SQL Editor.
3. Deploy `supabase/functions/agora-token` as an Edge Function named `agora-token`.
4. Set these Edge Function secrets (never put the certificate in the APK):
   - `AGORA_APP_ID` = the Agora App ID from the project.
   - `AGORA_APP_CERTIFICATE` = the Agora Primary Certificate.
5. Keep the Supabase Publishable Key in the app; never put a Supabase secret/service-role key in Flutter.

## 2. Agora

The Android client uses `agora_rtc_engine` and requests a short-lived RTC token from the Supabase Edge Function. The App Certificate is intentionally not embedded in the app.

## 3. Games

Lucky Fruit and Greedy Pro now request their round from Supabase, send every bet to an atomic database RPC, and request the result from the server. The browser/WebView no longer chooses a random winner locally and no longer owns the authoritative coin balance.

Coins in this backend are virtual in-app Coins. No cash-out or real-money wagering is implemented by these game RPCs.
