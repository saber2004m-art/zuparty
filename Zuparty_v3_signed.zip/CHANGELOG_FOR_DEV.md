# Zuparty — سجل التعديلات (للمطور)
هاد الملف كيلخص التعديلات اللي تدارت على النسخة الأصلية `Zuparty_seats_sync_v19_security_hardened.zip`،
باش تكون واضحة للمطور اللي غادي يكمل الخدمة/يبني APK.

---

## 1) مشكل: لائحة أعضاء الروم (`_members`) كانت MockData ديما
**الملفات:** `lib/services/zuparty_backend.dart`, `lib/screens/rooms/voice_room_screen.dart`

- زيد method جديدة `loadRoomMembers(roomId)` فـ `zuparty_backend.dart` كتجيب كل صفوف
  `zp_room_members` (مع بروفايل `zp_profiles`) لروم معينة.
- زيد `_loadAndApplyMembers()` فـ `voice_room_screen.dart` كتحول النتيجة لـ `RoomMemberInfo`
  وكتحدث `_members` (اللي كتستعمل فـ "عدد الحاضرين" ولائحة الأعضاء).
- كتتنادى:
  - مرة وحدة عند دخول روم حقيقية (`room.id != null`) فـ `initState`.
  - عند كل حدث Realtime (نفس القناة اللي كتحدث الكراسي `roomSeatsChannel`).
- رومات Mock/Demo (`room.id == null`) بقات تخدم بـ MockData بلا تغيير.

## 2) مشكل: `mic_muted` كيتقرا لكن حتى شي حاجة ما كتبكتب فيه
**الملفات:** الميغراسيون الجديدة، `lib/services/zuparty_backend.dart`, `lib/screens/rooms/voice_room_screen.dart`

- RPC جديدة `zp_set_mic_muted(p_room_id, p_muted)` فالميغراسيون
  `supabase/migrations/20260901010000_mic_and_room_settings_sync.sql`.
  كتسجل `mic_muted` غير للصف ديال `auth.uid()` نفسو (ما تقدرش تبدل حالة حتى واحد آخر).
- method جديدة `setMicMuted({roomId, muted})` فـ `zuparty_backend.dart`.
- `_toggleSelfMic()` دابا كتنادي هاد الـ method (بجانب Agora publish/mute)، غير إيلا
  `widget.room.id != null` (روم حقيقية).

## 3) مشكل: إعدادات الروم (صلاحيات، هدايا الزوار، خاص/عام) ما كانتش كتتسجل
**الملفات:** الميغراسيون الجديدة، `lib/services/zuparty_backend.dart`, `lib/screens/rooms/room_settings_screen.dart`

- RPC جديدة `zp_update_room_settings(...)` — **المالك فقط** (كتتحقق `owner_id = auth.uid()`
  قبل ما تبدل أي حاجة، وكتنطي `not_room_owner_or_room_not_found` إيلا ماشي المالك).
  كتبدل: `name`, `description`, `who_can_speak`, `who_can_chat`, `allow_guest_gifts`, `is_private`.
- method جديدة `updateRoomSettings(...)` فـ `zuparty_backend.dart`.
- `_save()` فـ `room_settings_screen.dart` دابا:
  - إيلا `room.id != null` → كتنادي الـ RPC، وإيلا فشلت كتبين رسالة خطأ وما كتبدلش
    الحالة المحلية (باش الواجهة ما تخدعش المستخدم بأن التسجيل نجح).
  - إيلا نجحت (ولا روم Mock بلا id) → كتبدل الحالة المحلية كيما كان الحال قبل.
  - زيد spinner (`_saving`) فوق الزر باش يبان أنها كتخدم مع السيرفر.

## 4) تحسين صغير: أخطاء Agora ما كانتش كتبان
**الملف:** `lib/services/agora_voice_service.dart`

- `onError` فـ Agora كانت فارغة (`{}`) — دابا كتسجل الخطأ بـ `print()` فـ debug console.

## نقطة كانت غير متصلحة — دابا متصلحة بالكامل (Multi-user Mic ↔ Seat)
**الملفات:** ميغراسيون جديدة `20260901020000_mic_seat_sync.sql`, `lib/data/models.dart`,
`lib/main.dart`, `lib/screens/rooms/create_room_screen.dart`, `lib/screens/search/search_screen.dart`,
`lib/services/zuparty_backend.dart`, `lib/screens/rooms/voice_room_screen.dart`, `lib/l10n/app_strings.dart`.

السبب الجذري: قاعدة البيانات كانت ديجا صحيحة (`mic_muted` فـ `zp_room_members`
مربوطة بـ `(room_id, user_id)` — نفس الصف اللي فيه `seat_index`، فحتى تبديل
المقعد ما كيمسحش حالة الميك). المشكل كان بالكامل فالـ Client:

1. `_toggleSelfMic()` كانت ديما كتبدل `ownerSeat` بغض النظر شكون كيبدّل —
   عضو عادي كيبدل الميك ديالو كان كيبان التغيير فتاج صاحب الروم بدل مقعده
   الحقيقي. دابا كاين `_applySelfMicVisual()` كيلقى المقعد الصحيح (ownerSeat
   إيلا كنت صاحب الروم، ولا المقعد المرقّم إيلا كنت جالس فيه).
2. حالة ميك صاحب الروم ما كانت كتترقّم من السيرفر لحتى واحد (`_loadAndApplySeats`
   كتقرا غير المقاعد المرقّمة 1..N، والـ ownerSeat ماشي مقعد مرقّم). دابا
   `_loadAndApplyMembers()` كتصحح `ownerSeat.isMuted` من نفس البيانات.
3. `_selfMicMuted` ما كانتش كتترقّم من السيرفر عند الدخول/refresh/Realtime —
   دابا كتتصادق فـ `_loadAndApplyMembers()`، وإيلا تبدلت (جهاز آخر، أو صاحب
   الروم كتمني عن بعد) كتزامن Agora فعلياً (`setPublishing`/`muteLocal`).
4. شيت "المقعد ديالي" (`_showSeatSheetSelf`) كانت كتبدل محلياً بلا أي تسجيل
   فالسيرفر ولا Agora — دابا كتنادي `_toggleSelfMic()` الحقيقية.
5. زيدت RPC جديدة `zp_set_member_mic_muted(room_id, target_user_id, muted)` —
   **صاحب الروم فقط** (نفس تحقق `owner_id = auth.uid()` ديال
   `zp_update_room_settings`، بلا أي صلاحية admin/staff إضافية). مربوطة فـ
   شيت مقعد عضو آخر (`_showSeatSheetOther`) — الزر ما كيبانش إلا لصاحب الروم.
   الـ Realtime الموجود ديجا (مفعّل على `zp_room_members` كاملة) كافي باش
   يبلغ جهاز العضو المستهدف، اللي كيزامن Agora ديالو من نفس منطق نقطة 3.
6. زيد حقل `RoomModel.ownerId` (كان ناقص بالكامل) باش الـ Client يقدر يعرف
   "شكون صاحب الروم" بثقة، معبّى فـ 4 أماكن: Home، شاشة "الغرف"، البحث، وإنشاء
   الروم.

**ماشي فيه أي تغيير** فـ RLS (ما زدنا حتى UPDATE policy — الطريق الوحيد لتبديل
`mic_muted` ديال غيرك بقى غير عبر الـ RPC الجديدة SECURITY DEFINER)، ولا فـ
`zp_take_seat`/`zp_leave_seat`/`zp_set_mic_muted` (بقاو كيما هوما)، ولا فأزرار
الرهان ولا نظام الشحن.

**ماتجربوش هنا:** هاد البيئة ماكاينش فيها Flutter/Dart SDK نهائيًا (تأكدنا:
`flutter`/`dart` غير موجودين، وحتى الشبكة معطلة باش نثبتوهم). خاصك تدير
`flutter pub get && flutter analyze && flutter test` ثم `flutter build apk --release`
فبيئة عندك فيها Flutter، وتجرب يدوياً بحسابين/جهازين:
- عضو عادي كيبدل الميك ديالو → يبان صحيح عند صاحب الروم (مقعده هو، ماشي
  تاج صاحب الروم).
- صاحب الروم كيبدل الميك ديالو → يبان صحيح عند عضو آخر بعد refresh/دخول جديد.
- صاحب الروم كيكتم عضو من شيت مقعده → يتبدل عند العضو نفسو (بما فيه Agora)
  وعند كل الأجهزة الأخرى عبر Realtime.
- عضو عادي ما عندوش زر "كتم" فوق مقعد عضو آخر (غير صاحب الروم اللي عندو).

## قبل ما تبني/تنشر
1. طبق الميغراسيونات الجداد بالترتيب الزمني: `20260901011000_profile_avatar_storage.sql`
   ثم `20260901020000_mic_seat_sync.sql` (بجانب الباقي، كيما مكتوب فـ `VERIFY_LIVE.md`).
2. `flutter pub get && flutter analyze && flutter test` — ما تجربوش فهاد البيئة (ماكاينش Flutter SDK هنا).
3. جرب يدوياً السيناريوهات المذكورة فوق بحسابين/جهازين.

## 5) Profile avatars — per-user image
**الملفات:** `lib/services/zuparty_backend.dart`, `lib/screens/profile/profile_screen.dart`, `lib/screens/shared/zp_widgets.dart`, `lib/data/app_state.dart`, `lib/main.dart`

- تفعيل اختيار صورة البروفايل من Gallery بدل الصورة الثابتة.
- رفع الصورة إلى Supabase Storage داخل مجلد خاص بمعرّف المستخدم.
- حفظ `avatar_url` في `zp_profiles` عبر `zp_update_my_profile`.
- `ZpAvatar` يدعم صور الشبكة (Supabase public URL) مع fallback آمن.
- تحميل صورة المستخدم عند فتح الجلسة وتحديثها بعد الحفظ.
- إضافة migration `20260901011000_profile_avatar_storage.sql` لإنشاء bucket `avatars` وسياسات القراءة/الرفع/التعديل الخاصة بكل مستخدم.

**ملاحظة:** يلزم تطبيق migration الجديدة على مشروع Supabase الحقيقي قبل تجربة رفع الصور.


## Production hardening pass — 2026-09-01
- Real room voice screens no longer seed members/chat/gift history from MockData; they start empty and load room members/messages from Supabase.
- Room preview no longer shows fabricated online users.
- Production search now queries `zp_profiles` for real users instead of local fixture users.
- Game search is intentionally not fabricated from local fixtures; it stays empty until the game catalog is wired to the production screen.
- No credentials or service-role secrets were added to the Flutter client.

This pass intentionally avoids changing the existing wallet, gift, recharge, VIP, room-seat, Agora, or game RPC contracts.
