# Zuparty Final Security Notes

- `zp_profiles.coins` has no client UPDATE policy.
- Profile edits use `zp_update_my_profile`, which cannot change coins.
- Gift spending uses `zp_send_gift` server-side and rejects insufficient balance.
- Gift price is read from the server catalog; client cannot choose an arbitrary price.
- `7777` is a server catalog gift with price 7777 Coins.
- Game wagering RPCs are disabled in this safe build.
- Recharge methods remain closed to regular users.
- Never ship a Supabase service-role key inside Flutter.
