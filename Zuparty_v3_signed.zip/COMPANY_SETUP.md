# Zuparty — إعداد حساب الشركة (الترتيب النهائي)

## الهدف
حساب الشركة يكون **Admin + وكالة شحن** في نفس الوقت. الحسابات الأخرى تبقى Users عاديين.

## 1) طبّق قاعدة البيانات
من Supabase > SQL Editor شغّل ملف:
`supabase/migrations/20260831000000_zuparty_backend.sql`

إذا كانت الجداول والدوال موجودة أصلاً، لا تعِد تشغيل migration كاملاً بلا مراجعة؛ استخدم الأجزاء الناقصة فقط.

## 2) انشر Edge Function الخاصة بالدعوة
بعد تثبيت Supabase CLI وربط المشروع:

```bash
supabase functions deploy invite --no-verify-jwt
```

الرابط سيكون:
`https://kwlcvnyznahfkyfvmymw.supabase.co/functions/v1/invite`

## 3) اضبط Redirect URL
في Supabase > Authentication > URL Configuration:

**Site URL**:
`https://kwlcvnyznahfkyfvmymw.supabase.co/functions/v1/invite`

وفي **Redirect URLs** أضف نفس الرابط.

هذا يمنع رابط دعوة الشركة من الرجوع إلى `localhost:3000`.

## 4) أنشئ حساب الشركة
من Authentication > Users > Add user > Send invitation، أدخل بريد الشركة.

بعد وصول الرسالة، افتح رابط الدعوة. الصفحة الجديدة تسمح باختيار كلمة المرور ثم تخبرك أن الحساب صار جاهزاً لتسجيل الدخول من APK.

## 5) أعطِ الحساب Admin + وكالة شحن
بعد إنشاء/تأكيد حساب الشركة، من SQL Editor شغّل:

```sql
select * from public.zp_set_company_admin('EMAIL_COMPANY');
```

بدّل `EMAIL_COMPANY` بالبريد الحقيقي.

المفروض ترجع:
- `role = admin`
- `shipping_agency = true`

الدالة مقيّدة لتعمل مرة واحدة فقط ما دام يوجد Admin نشط.

## 6) المستخدمون العاديون
لا تضف لهم صفاً في `zp_staff_roles`.

وجود الحساب في `auth.users` و`zp_profiles` وحده يعني User عادي، ولن تظهر له لوحة الشحن.

## 7) اختبار نهائي
1. سجّل دخول حساب الشركة من APK.
2. تأكد من ظهور لوحة شحن Zuparty.
3. تأكد من `role = admin` و`shipping_agency = true` في `zp_staff_roles`.
4. أنشئ حساب مستخدم ثانٍ.
5. تأكد أنه لا يرى لوحة الشحن ولا يملك صلاحيات Admin.
