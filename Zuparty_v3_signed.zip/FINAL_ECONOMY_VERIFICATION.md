# Zuparty — Economy & VIP verification

## Server-authoritative balances
- `zp_profiles.coins` is the wallet/game balance.
- No client UPDATE policy exists for `coins`.
- Game bets debit Coins through `zp_place_game_bet`.
- Game wins credit Coins through `zp_resolve_game_round`.
- Gifts debit sender and credit receiver atomically through `zp_send_gift`.
- Gift retries are protected by `idempotency_key`.
- VIP subscriptions debit Coins through `zp_subscribe_vip`.

## VIP/SVIP launch configuration
- VIP 1–10 are present.
- SVIP 11–13 are present.
- VIP 1 one-time welcome reward: 100,000 virtual Coins.
- Recharge multiplier is applied server-side after a recharge is verified as paid.
- SVIP 11 metadata price: $50.
- SVIP 13 metadata price: $100,000.
- These USD values are payment metadata only. No fake payment confirmation is generated.

## First recharge promotion
- A one-time virtual reward with a displayed value of $50 is granted after the first verified recharge of at least $50.
- It is recorded in `zp_reward_grants` and cannot be claimed twice.

## Important production boundary
A real payment provider/webhook is still required before `zp_finalize_recharge_order` can be called automatically. The app must never mark an order as paid based only on a client-side button.
