# Zuparty — نشر نسخة Web ووظيفة دعوة الحساب

## Web
المشروع يحتوي الآن على مجلد `web/`. على جهاز فيه Flutter SDK:

```bash
flutter pub get
flutter build web --release
```

الناتج يكون في `build/web` ويمكن نشره على Vercel/Netlify/Firebase Hosting أو أي static host.

## حذف الحساب (مطلوب لنشر التطبيق على المتجر)
شغّل هذا الأمر لنشر Edge Function التي تنفّذ حذف الحساب فعلياً (تحتاج صلاحية service-role التي توفرها Supabase تلقائياً داخل بيئة Edge Functions، بدون أي إعداد إضافي):

```bash
supabase functions deploy delete-account
```

هذه الدالة تحذف حساب `auth.users` الخاص بالمستخدم المتصل فقط (لا تقبل أي معرّف آخر من الطلب)، وبفضل `on delete cascade` الموجودة أصلاً فـ `zp_profiles` وما يتفرع عنها، تُحذف تلقائياً غرفه ورسائله وعضوياته وسجل محفظته. **ملاحظة:** إذا كان المستخدم مالك غرفة، فالغرفة تُحذف بالكامل مع بيانات الأعضاء الآخرين فيها (سلوك متفرع من تصميم قاعدة البيانات الحالي نفسه، وليس شيئاً جديداً) — إذا كان هذا غير مرغوب فيه، يحتاج الأمر إعادة تصميم (نقل الملكية بدل الحذف) قبل الاعتماد عليه.

## دعوة الشركة بدون localhost
الأبسط حالياً هو نشر Edge Function `invite` داخل Supabase:

```bash
supabase functions deploy invite --no-verify-jwt
```

ثم استعمال رابط:
`https://kwlcvnyznahfkyfvmymw.supabase.co/functions/v1/invite`

كـ Site URL وRedirect URL في Authentication > URL Configuration.

الصفحة تتحقق من رابط الدعوة، تسمح للمستخدم بتعيين كلمة المرور، ثم تسجّله خارج جلسة المتصفح. بعد ذلك يسجل الدخول من APK بالبريد وكلمة المرور.

## ملاحظة
لا نضع service-role key داخل Flutter أو داخل الصفحة. الصفحة تستعمل فقط `SUPABASE_ANON_KEY`، وصلاحية Admin تُمنح من SQL/قاعدة البيانات.
