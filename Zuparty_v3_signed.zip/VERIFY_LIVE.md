# Zuparty live verification checklist

## 1. Supabase SQL
Run the migrations in order:
1. `supabase/migrations/20260831000000_zuparty_backend.sql`
2. `supabase/migrations/20260831220000_runtime_hardening.sql`

Then verify:
- `select * from public.zp_games;`
- `select proname from pg_proc where proname in ('zp_get_or_create_game_round','zp_place_game_bet','zp_resolve_game_round');`
- Create/login one test account and confirm a row exists in `zp_profiles`.

## 2. Game smoke test
With a test account funded by the authorized agent/admin flow:
- Open Lucky Fruit.
- Open Greedy Pro.
- Confirm a round number and server balance appear.
- Place one valid bet.
- Confirm `zp_game_bets` and `zp_wallet_transactions` receive rows.
- Wait until the 30-second round ends.
- Confirm the round resolves once and the resulting balance matches the transaction ledger.

## 3. VIP smoke test
- Open VIP Center.
- Confirm VIP level/points/Coins come from `zp_get_vip_status()`.
- Subscribe to a test tier only when the test account has enough Coins.
- Confirm `vip_level`, `vip_until`, and `zp_wallet_transactions` update atomically.

## 4. Important limitation
This package still contains legacy local/mock UI in some non-critical screens. They are not described as live until their corresponding backend tables/realtime subscriptions are implemented.

## Account Levels
- `zp_profiles.account_xp` is cumulative credited Coins, 1:1.
- Spending Coins never lowers XP.
- Account levels are server-derived from 1 to 10.
- Thresholds are 0/10k/20k/.../90k XP; Level 10 is the cap.
- Client reads progress only through `zp_get_account_progress()`.
