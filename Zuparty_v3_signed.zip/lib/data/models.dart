import 'package:flutter/material.dart';

/// ============================================================
/// Zuparty — Mock Models (Phase 1 Foundation)
/// كل الموديلات المستعملة فالتطبيق (Mock فقط، بلا Backend)
/// ============================================================

// ------------------------------------------------------------
// موديلات موجودة مسبقًا (منقولة من main.dart بدون أي تغيير بالمنطق)
// ------------------------------------------------------------

/// موديل بسيط لتمثيل الغرفة
class RoomModel {
  final String? id; // معرّف اختياري (مستعمل فـ Home لربط البانرات بروم معيّن)
  /// معرّف صاحب الروم الحقيقي (Supabase auth.users.id / zp_rooms.owner_id).
  /// null فقط لرومات Mock/Demo. مستعمل باش نعرفو "شكون صاحب الروم" عند
  /// مزامنة حالة الـ Mic ديال تاج صاحب الروم (ownerSeat) عبر كل الأجهزة.
  final String? ownerId;
  String name; // قابل للتعديل من Room Settings (Phase 4 — Part 3/3)
  String? imagePath; // قابل للتعديل من Room Theme (Phase 4 — Part 3/3)
  SeatModel? ownerSeat;
  List<SeatModel>? seatsData;
  bool isRoomLocked;
  bool selfMicLocked;

  // إعدادات الغرفة القابلة للتغيير فعليًا
  String announcement;
  String welcomeMessage;
  String description; // وصف الروم (Phase 3 — Part 2: Create Room / Room Details)
  String roomType;
  int micSeats; // إجمالي عدد المقاعد (يشمل صاحب الروم)
  bool superMicEnabled;
  int effectIndex; // لون تأثير التحدث حول المقاعد
  bool showGiftEffects;
  bool showVoiceWave;
  String seatStyle; // شكل المقاعد: 'دائري' أو 'أريكة'

  // Room States (Phase 4 — Part 3/3): حالات دخول إضافية للروم — Mock/Local فقط
  bool isFull; // الروم وصل لأقصى سعة (مستعمل فتدفّق الانضمام)
  bool isUnavailable; // الروم غير متاح حاليًا (مثلاً: تحت الصيانة/انتهى)

  // Room Settings (Phase 4 — Part 3/3): صلاحيات + هدايا — Local/Mock فقط
  String whoCanSpeak; // 'الجميع' | 'الأعضاء المعتمدون فقط' | 'المالك والمشرفين فقط'
  String whoCanChat; // نفس الخيارات
  bool allowGuestGifts;

  // بيانات عرض إضافية (مستعملة فـ Home: Featured/Popular/Recommended Rooms)
  String? ownerName;
  int onlineCount;
  String? category;

  // بيانات إضافية (Phase 3 — شاشة "الغرف" Browse/List)
  String? roomCode; // معرّف الروم المعروض للمستخدم (Room ID) — مختلف عن id الداخلي
  String? ownerAvatarPath;
  bool isPopular;
  bool isRecommended;
  bool isNew;

  RoomModel({
    this.id,
    this.ownerId,
    required this.name,
    this.imagePath,
    this.ownerSeat,
    this.seatsData,
    this.isRoomLocked = false,
    this.selfMicLocked = false,
    this.announcement = '',
    this.welcomeMessage = '',
    this.description = '',
    this.roomType = 'غرفة الدردشة الصوتية',
    this.micSeats = 9,
    this.superMicEnabled = false,
    this.effectIndex = 0,
    this.showGiftEffects = true,
    this.showVoiceWave = true,
    this.seatStyle = 'دائري',
    this.isFull = false,
    this.isUnavailable = false,
    this.whoCanSpeak = 'الجميع',
    this.whoCanChat = 'الجميع',
    this.allowGuestGifts = true,
    this.ownerName,
    this.onlineCount = 0,
    this.category,
    this.roomCode,
    this.ownerAvatarPath,
    this.isPopular = false,
    this.isRecommended = false,
    this.isNew = false,
  });
}

/// خيارات شكل المقاعد المتاحة
const List<String> kSeatStyles = ['دائري', 'أريكة'];

/// خيارات التأثير المتاحة (لون هالة التحدث حول المقعد)
const List<Color> kRoomEffectColors = [Colors.deepOrange, Colors.deepPurple, Colors.redAccent, Colors.blueAccent];
const List<String> kRoomEffectNames = ['برتقالي', 'بنفسجي', 'أحمر', 'أزرق'];
const List<String> kRoomTypes = ['غرفة الدردشة الصوتية', 'غرفة الألعاب', 'غرفة الموسيقى', 'غرفة التعارف'];
const List<int> kMicSeatOptions = [6, 8, 9, 10, 12, 15];

/// خيارات صلاحيات الروم (من يقدر يتكلم / من يقدر يدردش) — Phase 4 Part 3/3
const List<String> kRoomPermissionOptions = ['الجميع', 'الأعضاء المعتمدون فقط', 'المالك والمشرفين فقط'];

// ------------------------------------------------------------
// ثوابت شاشة "إنشاء غرفة" (Phase 3 — Part 2)
// ------------------------------------------------------------

/// أغلفة جاهزة يقدر المستخدم يختار منها عند إنشاء غرفة (Assets موجودة فعليًا)
const List<String> kRoomCoverOptions = [
  'assets/images/room_bg_official.webp',
  'assets/images/podium_orange.webp',
  'assets/images/podium_purple.webp',
  'assets/images/podium_red.webp',
];

/// تصنيفات الغرفة (نفس التصنيفات المستعملة فـ MockData.browseRooms وفلاتر شاشة "الغرف")
const List<String> kRoomCategories = ['موسيقى', 'دردشة', 'ألعاب', 'اجتماعي'];

class SeatModel {
  String? occupantName;
  String? occupantImage;
  bool isSpeaking;
  bool isLocked;
  bool isMuted;
  /// معرّف المستخدم الحقيقي (Supabase auth.users.id) الجالس فهاد المقعد.
  /// null = مقعد فارغ أو (فحالة الروم Mock/Demo) معرّف غير معروف.
  /// مستعمل فقط باش نميزو "أنا" عن باقي اللاعبين فمزامنة المقاعد الحقيقية.
  String? occupantId;
  SeatModel({
    this.occupantName,
    this.occupantImage,
    this.isSpeaking = false,
    this.isLocked = false,
    this.isMuted = false,
    this.occupantId,
  });
}

class GameModel {
  final String id;
  final String name;
  final String assetPath;
  final Color color;
  final String emoji;

  // Phase 5 Part 2: Game Center — Local/Mock فقط
  final String category; // 'مميزة' | 'شائعة' | 'جديدة' | 'بطاقات' | 'حظ'
  final String description;
  final int players; // عدد اللاعبين الحاليين (Mock)
  final bool isPlayable; // إذا false: كتبان "قريبًا" وما كيتحلش الـ Play
  final bool isFeatured;
  final bool isNew;

  const GameModel({
    required this.id,
    required this.name,
    required this.assetPath,
    required this.color,
    required this.emoji,
    this.category = 'شائعة',
    this.description = '',
    this.players = 0,
    this.isPlayable = true,
    this.isFeatured = false,
    this.isNew = false,
  });
}

/// نتيجة فردية فسجل لعب المستخدم (Game History — Mock فقط)
class GameHistoryEntry {
  final String gameId;
  final String gameName;
  final String emoji;
  final DateTime time;
  final int coinsChange; // موجب = ربح، سالب = خسارة
  final bool isWin;

  const GameHistoryEntry({
    required this.gameId,
    required this.gameName,
    required this.emoji,
    required this.time,
    required this.coinsChange,
    required this.isWin,
  });
}

/// حركة محفظة (Wallet Transaction — Mock فقط)
enum WalletTxType { recharge, giftSent, giftReceived, gameWin, gameLoss, vipSub }

class WalletTransaction {
  final String id;
  final WalletTxType type;
  final String title;
  final int amount; // موجب = دخول رصيد، سالب = خروج رصيد
  final DateTime time;

  const WalletTransaction({
    required this.id,
    required this.type,
    required this.title,
    required this.amount,
    required this.time,
  });
}

/// شارة/إنجاز فالبروفيل (Badges / Achievements — Mock فقط)
class BadgeModel {
  final String id;
  final String label;
  final IconData icon;
  final Color color;
  final bool isUnlocked;
  final String? progressLabel; // مثلاً '7/10' إذا ماكملش

  const BadgeModel({
    required this.id,
    required this.label,
    required this.icon,
    required this.color,
    this.isUnlocked = true,
    this.progressLabel,
  });
}

// ------------------------------------------------------------
// موديلات جديدة (Mock Data Foundation للمراحل القادمة)
// ------------------------------------------------------------

class UserModel {
  final String id;
  final String name;
  final String? avatarPath;
  final String? gender;
  final bool isVip;
  final bool isNew;
  final int level;
  // Phase 5 — Part 3: حقول إضافية لشاشات الأصدقاء/البحث (كلها اختيارية، ما كتأثرش على الاستعمال القديم)
  final bool isOnline;
  final bool isFollowing; // أنا متابعه
  final bool isFollower; // كيتابعني
  final bool isRequestPending; // طلب متابعة معلّق
  final bool isBlocked;
  final String? bio;

  const UserModel({
    required this.id,
    required this.name,
    this.avatarPath,
    this.gender,
    this.isVip = false,
    this.isNew = false,
    this.level = 1,
    this.isOnline = false,
    this.isFollowing = false,
    this.isFollower = false,
    this.isRequestPending = false,
    this.isBlocked = false,
    this.bio,
  });

  UserModel copyWith({bool? isFollowing, bool? isRequestPending, bool? isBlocked}) => UserModel(
        id: id,
        name: name,
        avatarPath: avatarPath,
        gender: gender,
        isVip: isVip,
        isNew: isNew,
        level: level,
        isOnline: isOnline,
        isFollowing: isFollowing ?? this.isFollowing,
        isFollower: isFollower,
        isRequestPending: isRequestPending ?? this.isRequestPending,
        isBlocked: isBlocked ?? this.isBlocked,
        bio: bio,
      );
}

/// نوع رسالة الدردشة الخاصة (Chat — Phase 5 Part 2)
enum ChatMessageType { text, emoji, image, voice, gift }

class MessageModel {
  final String id;
  final String senderId;
  final String senderName;
  final String text;
  final DateTime time;
  final bool isMe;

  // Phase 5 Part 2: أنواع رسائل إضافية — Local/Mock فقط
  final ChatMessageType type;
  final String? imagePath; // مستعمل إذا type == image
  final int voiceSeconds; // مستعمل إذا type == voice
  final GiftModel? gift; // مستعمل إذا type == gift
  final int giftQuantity;
  bool isRead;

  MessageModel({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.text,
    required this.time,
    this.isMe = false,
    this.type = ChatMessageType.text,
    this.imagePath,
    this.voiceSeconds = 0,
    this.gift,
    this.giftQuantity = 1,
    this.isRead = true,
  });
}

class ConversationPreview {
  final String id;
  final String name;
  final String? avatarPath;
  final String lastMessage;
  final String time;
  int unreadCount;
  final bool isOnline;
  final bool isVip;
  bool isBlocked;
  bool isPinned;

  ConversationPreview({
    String? id,
    required this.name,
    this.avatarPath,
    required this.lastMessage,
    required this.time,
    this.unreadCount = 0,
    this.isOnline = false,
    this.isVip = false,
    this.isBlocked = false,
    this.isPinned = false,
  }) : id = id ?? name;
}

class GiftModel {
  final String id;
  final String name;
  final String emoji;
  final int price; // بالـ Coins

  const GiftModel({required this.id, required this.name, required this.emoji, required this.price});
}

class RankingEntry {
  final int rank;
  final String userName;
  final String? avatarPath;
  final int score;
  final bool isVip;
  final int levelChange; // + صاعد / - نازل / 0 بلا تغيير (مقارنة بالترتيب السابق)

  const RankingEntry({
    required this.rank,
    required this.userName,
    this.avatarPath,
    required this.score,
    this.isVip = false,
    this.levelChange = 0,
  });
}

/// نوع فعالية الأحداث + حالة مشاركة المستخدم
enum EventTaskStatus { locked, inProgress, completed, claimed }

class EventTask {
  final String id;
  final String title;
  final int targetValue;
  final int currentValue;
  final String rewardLabel;
  final EventTaskStatus status;

  const EventTask({
    required this.id,
    required this.title,
    required this.targetValue,
    required this.currentValue,
    required this.rewardLabel,
    this.status = EventTaskStatus.inProgress,
  });
}

class EventItem {
  final String id;
  final String title;
  final String description;
  final String? imagePath;
  final DateTime startDate;
  final DateTime endDate;
  // Phase 5 — Part 3: تفاصيل أوسع لمركز الفعاليات
  final List<EventTask> tasks;
  final List<RankingEntry> ranking;
  final bool isJoined;
  final String badgeLabel; // مثلاً 'جديد' / 'ساخن' / 'ينتهي قريبًا'

  const EventItem({
    required this.id,
    required this.title,
    required this.description,
    this.imagePath,
    required this.startDate,
    required this.endDate,
    this.tasks = const [],
    this.ranking = const [],
    this.isJoined = false,
    this.badgeLabel = '',
  });

  bool get isActive => DateTime.now().isBefore(endDate);
  Duration get remaining => endDate.difference(DateTime.now());
}

/// أنواع الإشعارات (Phase 5 — Part 3)
enum NotificationType { system, gift, follower, like, roomInvite, event, message }

class NotificationItem {
  final String id;
  final String title;
  final String body;
  final DateTime time;
  final bool isRead;
  final NotificationType type;
  final String? avatarPath;

  const NotificationItem({
    required this.id,
    required this.title,
    required this.body,
    required this.time,
    this.isRead = false,
    this.type = NotificationType.system,
    this.avatarPath,
  });

  NotificationItem copyWith({bool? isRead}) => NotificationItem(
        id: id,
        title: title,
        body: body,
        time: time,
        isRead: isRead ?? this.isRead,
        type: type,
        avatarPath: avatarPath,
      );
}

class CoinPackage {
  final String id;
  final int coins;
  final String priceLabel;
  final bool isBestValue;

  const CoinPackage({required this.id, required this.coins, required this.priceLabel, this.isBestValue = false});
}

class VipTier {
  final String title;
  final int level;
  final int priceCoinsPerMonth;
  final List<String> perks;
  final Color color;
  final int minPoints; // نقطة البداية لهاد المستوى (تقدّم VIP — Mock)

  const VipTier({
    required this.title,
    required this.level,
    required this.priceCoinsPerMonth,
    required this.perks,
    this.color = const Color(0xFFFF5722),
    this.minPoints = 0,
  });
}

/// عنصر Banner فـ Home (Mock فقط — بلا صور شبكة، مبني على تدرّجات لونية من Design System)
class BannerItem {
  final String id;
  final String title;
  final String subtitle;
  final List<Color> gradientColors;
  final IconData icon;
  final String? targetRoomId; // إذا موجود: الضغط كيفتح الروم المرتبط
  final bool opensVip; // إذا true: الضغط كيفتح شاشة VIP الموجودة

  const BannerItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.gradientColors,
    required this.icon,
    this.targetRoomId,
    this.opensVip = false,
  });
}

// ------------------------------------------------------------
// Voice Room (Phase 4 — Part 1/3): دور العضو داخل الغرفة الصوتية
// موديل خفيف يلف UserModel الموجود بدل تكراره (Mock/Local فقط)
// ------------------------------------------------------------

enum RoomRole { owner, admin, speaker, member }

extension RoomRoleLabel on RoomRole {
  String get label {
    switch (this) {
      case RoomRole.owner:
        return 'مالك الروم';
      case RoomRole.admin:
        return 'مشرف';
      case RoomRole.speaker:
        return 'متحدث';
      case RoomRole.member:
        return 'عضو';
    }
  }
}

/// يمثل عضو داخل الغرفة الصوتية (Members Sheet / Room Users) — Mock فقط
class RoomMemberInfo {
  final UserModel user;
  final RoomRole role;
  final bool isOnline;
  final bool isMicMuted;
  final bool isSpeaking;

  // حالة تفاعل محلية إضافية (Phase 4 — Part 2/3: Member Interactions) — Local/Mock فقط
  bool isFollowing;
  bool isModMuted; // مكتوم من طرف الإدارة (مختلف عن كتم المايك الشخصي فالمقعد)

  RoomMemberInfo({
    required this.user,
    this.role = RoomRole.member,
    this.isOnline = true,
    this.isMicMuted = true,
    this.isSpeaking = false,
    this.isFollowing = false,
    this.isModMuted = false,
  });
}

// ------------------------------------------------------------
// Voice Room (Phase 4 — Part 2/3): دردشة الروم + الهدايا + الدعوة
// كل الموديلات هنا Local/Mock فقط — بلا Backend / بلا Real-time.
// ------------------------------------------------------------

/// نوع رسالة داخل دردشة الروم
enum RoomChatMessageType { text, system, join, gift }

/// رسالة داخل دردشة الروم — تدعم: نص عادي / رسالة نظام / رسالة انضمام / رسالة هدية
class RoomChatMessage {
  final String id;
  final RoomChatMessageType type;
  final UserModel? sender; // null فقط لرسائل النظام (system)
  final String? text; // نص الرسالة (text) أو نص رسالة الانضمام/النظام
  final GiftModel? gift; // مستعمل فقط إذا type == gift
  final int giftQuantity;
  final UserModel? giftReceiver; // مستلم الهدية إذا type == gift
  final DateTime time;
  final bool isMe;

  RoomChatMessage({
    required this.id,
    required this.type,
    this.sender,
    this.text,
    this.gift,
    this.giftQuantity = 1,
    this.giftReceiver,
    required this.time,
    this.isMe = false,
  });
}

/// تصنيف هدايا (لتنظيم لوحة الهدايا — Mock فقط)
class GiftCategoryModel {
  final String id;
  final String label;
  final IconData icon;
  final List<GiftModel> gifts;

  const GiftCategoryModel({
    required this.id,
    required this.label,
    required this.icon,
    required this.gifts,
  });
}

/// سجل إرسال هدية (Gift History — Local/Mock فقط)
class GiftHistoryEntry {
  final String id;
  final UserModel sender;
  final UserModel receiver;
  final GiftModel gift;
  final int quantity;
  final DateTime time;

  const GiftHistoryEntry({
    required this.id,
    required this.sender,
    required this.receiver,
    required this.gift,
    this.quantity = 1,
    required this.time,
  });
}

class FriendModel {
  final String id;
  final String name;
  final String? avatarPath;
  final bool isOnline;
  final bool isFollowing;

  const FriendModel({
    required this.id,
    required this.name,
    this.avatarPath,
    this.isOnline = false,
    this.isFollowing = false,
  });
}
