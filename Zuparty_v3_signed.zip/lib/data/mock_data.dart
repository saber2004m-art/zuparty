import 'package:flutter/material.dart';
import 'models.dart';

/// ============================================================
/// Zuparty — Mock Data (Phase 1 Foundation)
/// بيانات تجريبية ثابتة ومنظمة (بلا Backend) لإعادة الاستعمال
/// فكل الشاشات فالمراحل القادمة.
/// ============================================================

class MockData {
  MockData._();

  // ---------------- Users ----------------
  static const List<UserModel> users = [
    UserModel(id: 'u1', name: 'Sara', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 12),
    UserModel(id: 'u2', name: 'Player_01', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 7),
    UserModel(id: 'u3', name: 'Zuparty Team', avatarPath: 'assets/images/profile.png', isNew: true, level: 1),
  ];

  // ---------------- Voice Room: أعضاء الغرفة (Phase 4 — Part 1/3) ----------------
  // Mock ثابت يغطي كل الحالات المطلوبة: owner / admin / speaker / member،
  // متصل/غير متصل، مكتوم/غير مكتوم. مبني فوق UserModel الموجود (بدون تكرار).
  static final List<RoomMemberInfo> voiceRoomMembers = [
    RoomMemberInfo(
      user: UserModel(id: 'm_owner', name: 'ربيع', avatarPath: 'assets/images/profile.png', isVip: true, level: 24),
      role: RoomRole.owner,
      isMicMuted: false,
      isSpeaking: true,
    ),
    RoomMemberInfo(
      user: UserModel(id: 'm_admin1', name: 'ياسمين', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 18),
      role: RoomRole.admin,
      isMicMuted: false,
    ),
    RoomMemberInfo(
      user: UserModel(id: 'm_speaker1', name: 'Player_01', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 9),
      role: RoomRole.speaker,
      isMicMuted: true,
    ),
    RoomMemberInfo(
      user: UserModel(id: 'm_speaker2', name: 'Sara', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 12),
      role: RoomRole.speaker,
      isMicMuted: false,
      isSpeaking: true,
    ),
    RoomMemberInfo(
      user: UserModel(id: 'm_mem1', name: 'خالد', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 5),
    ),
    RoomMemberInfo(
      user: UserModel(id: 'm_mem2', name: 'نور', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isNew: true, level: 1),
    ),
    RoomMemberInfo(
      user: UserModel(id: 'm_mem3', name: 'Zuparty Team', avatarPath: 'assets/images/profile.png', isNew: true, level: 1),
      isOnline: false,
    ),
    RoomMemberInfo(
      user: UserModel(id: 'm_mem4', name: 'Omar_99', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 3),
      isOnline: false,
    ),
  ];

  // ---------------- Rooms (أسماء تجريبية تستعمل فالبحث والقوائم) ----------------
  static const List<String> roomNames = [
    'السهرات العربية',
    'Zuparty Music',
    'Friends Lounge',
    'Gaming Room',
  ];

  // ---------------- Home: Banners ----------------
  static const List<BannerItem> banners = [
    BannerItem(
      id: 'b1',
      title: 'أهلاً بيك فـ Zuparty 🎉',
      subtitle: 'اكتشف الغرف، اصنع أصدقاء جدد، واستمتع بالألعاب',
      gradientColors: [Color(0xFFFF7043), Color(0xFFE64A19)],
      icon: Icons.celebration,
    ),
    BannerItem(
      id: 'b2',
      title: 'ترقّى إلى VIP',
      subtitle: 'بادج مميز، دخول أولوية، وهدايا حصرية',
      gradientColors: [Color(0xFF6A3DE8), Color(0xFF3A1650)],
      icon: Icons.workspace_premium_outlined,
      opensVip: true,
    ),
    BannerItem(
      id: 'b3',
      title: 'السهرات العربية 🔥',
      subtitle: 'انضم الآن وشارك فالسهرة مع الأصدقاء',
      gradientColors: [Color(0xFFED3914), Color(0xFF8E1A0F)],
      icon: Icons.mic_none,
      targetRoomId: 'r_featured_1',
    ),
    BannerItem(
      id: 'b4',
      title: 'ألعاب Zuparty',
      subtitle: 'جرّب Lucky Fruit و Greedy Pro وربح Coins',
      gradientColors: [Color(0xFF2E7D32), Color(0xFF1B4D1E)],
      icon: Icons.sports_esports_outlined,
    ),
  ];

  // ---------------- Home: Featured Rooms ----------------
  static final List<RoomModel> featuredRooms = [
    RoomModel(
      id: 'r_featured_1',
      name: 'السهرات العربية',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Sara',
      onlineCount: 128,
      category: 'دردشة صوتية',
    ),
    RoomModel(
      id: 'r_featured_2',
      name: 'Zuparty Music',
      imagePath: 'assets/images/podium_purple.webp',
      ownerName: 'Player_01',
      onlineCount: 96,
      category: 'موسيقى',
    ),
    RoomModel(
      id: 'r_featured_3',
      name: 'Friends Lounge',
      imagePath: 'assets/images/podium_red.webp',
      ownerName: 'Zuparty Team',
      onlineCount: 74,
      category: 'تعارف',
    ),
    RoomModel(
      id: 'r_featured_4',
      name: 'Gaming Room',
      imagePath: 'assets/images/podium_orange.webp',
      ownerName: 'Sara',
      onlineCount: 52,
      category: 'ألعاب',
    ),
  ];

  // ---------------- Home: Popular Rooms ----------------
  static final List<RoomModel> popularRooms = [
    RoomModel(
      id: 'r_popular_1',
      name: 'ليالي الرياض',
      imagePath: 'assets/images/podium_orange.webp',
      ownerName: 'Player_01',
      onlineCount: 210,
      category: 'دردشة صوتية',
    ),
    RoomModel(
      id: 'r_popular_2',
      name: 'Golden Voices',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Sara',
      onlineCount: 187,
      category: 'موسيقى',
    ),
    RoomModel(
      id: 'r_popular_3',
      name: 'دار الكوميديا',
      imagePath: 'assets/images/podium_red.webp',
      ownerName: 'Zuparty Team',
      onlineCount: 143,
      category: 'ترفيه',
    ),
    RoomModel(
      id: 'r_popular_4',
      name: 'Night Owls',
      imagePath: 'assets/images/podium_purple.webp',
      ownerName: 'Player_01',
      onlineCount: 121,
      category: 'تعارف',
    ),
  ];

  // ---------------- Home: Recommended Rooms ----------------
  static final List<RoomModel> recommendedRooms = [
    RoomModel(
      id: 'r_recommended_1',
      name: 'ركن الأصدقاء',
      imagePath: 'assets/images/podium_purple.webp',
      ownerName: 'Sara',
      onlineCount: 63,
      category: 'تعارف',
    ),
    RoomModel(
      id: 'r_recommended_2',
      name: 'استوديو الألحان',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Zuparty Team',
      onlineCount: 58,
      category: 'موسيقى',
    ),
    RoomModel(
      id: 'r_recommended_3',
      name: 'Champions Room',
      imagePath: 'assets/images/podium_orange.webp',
      ownerName: 'Player_01',
      onlineCount: 41,
      category: 'ألعاب',
    ),
  ];

  // ---------------- Rooms Screen: Browse / List (Phase 3 — Part 1) ----------------
  // مجموعة غرف تجريبية منظمة لشاشة "الغرف" (بحث + تصنيفات + قائمة)
  // كل تصنيف (موسيقى / دردشة / ألعاب / اجتماعي) فيه عدة غرف، وبعضها
  // موسوم كـ شائعة/موصى بها/جديدة باش تتفلتر فتبويبات "شائع" و"موصى به" و"جديد".
  static final List<RoomModel> browseRooms = [
    // ----- موسيقى -----
    RoomModel(
      id: 'br_1', roomCode: '482913', name: 'سهرة الموسيقى الشرقية',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Sara', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 245, category: 'موسيقى', isPopular: true,
    ),
    RoomModel(
      id: 'br_2', roomCode: '119284', name: 'Chill Beats Lounge',
      imagePath: 'assets/images/podium_purple.webp',
      ownerName: 'Yassine', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 88, category: 'موسيقى', isNew: true,
    ),
    RoomModel(
      id: 'br_3', roomCode: '558231', name: 'استوديو الطرب',
      imagePath: 'assets/images/podium_orange.webp',
      ownerName: 'Nour', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 132, category: 'موسيقى', isRecommended: true,
    ),
    RoomModel(
      id: 'br_4', roomCode: '904471', name: 'Vibes & Chill',
      imagePath: 'assets/images/podium_red.webp',
      ownerName: 'Player_01', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 57, category: 'موسيقى',
    ),

    // ----- دردشة -----
    RoomModel(
      id: 'br_5', roomCode: '223390', name: 'دردشة الأصدقاء',
      imagePath: 'assets/images/podium_red.webp',
      ownerName: 'Salma', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 176, category: 'دردشة', isPopular: true, isRoomLocked: true,
    ),
    RoomModel(
      id: 'br_6', roomCode: '671205', name: 'كلام الليل',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Anas', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 64, category: 'دردشة', isNew: true,
    ),
    RoomModel(
      id: 'br_7', roomCode: '340982', name: 'Late Night Talks',
      imagePath: 'assets/images/podium_purple.webp',
      ownerName: 'Rania', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 98, category: 'دردشة', isRecommended: true,
    ),
    RoomModel(
      id: 'br_8', roomCode: '785612', name: 'ركن النقاش',
      imagePath: 'assets/images/podium_orange.webp',
      ownerName: 'Sara', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 41, category: 'دردشة',
    ),

    // ----- ألعاب -----
    RoomModel(
      id: 'br_9', roomCode: '112230', name: 'Gaming Arena',
      imagePath: 'assets/images/podium_orange.webp',
      ownerName: 'Player_01', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 301, category: 'ألعاب', isPopular: true, isFull: true,
    ),
    RoomModel(
      id: 'br_10', roomCode: '998321', name: 'بطولة Zuparty',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Zuparty Team', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 210, category: 'ألعاب', isRecommended: true, isRoomLocked: true,
    ),
    RoomModel(
      id: 'br_11', roomCode: '447810', name: 'Casual Gamers',
      imagePath: 'assets/images/podium_red.webp',
      ownerName: 'Yassine', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 73, category: 'ألعاب', isNew: true,
    ),
    RoomModel(
      id: 'br_12', roomCode: '662193', name: 'Squad Up',
      imagePath: 'assets/images/podium_purple.webp',
      ownerName: 'Anas', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 39, category: 'ألعاب',
    ),

    // ----- اجتماعي -----
    RoomModel(
      id: 'br_13', roomCode: '223814', name: 'ملتقى التعارف',
      imagePath: 'assets/images/podium_purple.webp',
      ownerName: 'Nour', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 154, category: 'اجتماعي', isPopular: true, isRecommended: true,
    ),
    RoomModel(
      id: 'br_14', roomCode: '889012', name: 'Friends & Fun',
      imagePath: 'assets/images/podium_orange.webp',
      ownerName: 'Salma', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 112, category: 'اجتماعي',
    ),
    RoomModel(
      id: 'br_15', roomCode: '556670', name: 'وجوه جديدة',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Rania', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 29, category: 'اجتماعي', isNew: true,
    ),
    RoomModel(
      id: 'br_16', roomCode: '775102', name: 'Social Circle',
      imagePath: 'assets/images/podium_red.webp',
      ownerName: 'Zuparty Team', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 66, category: 'اجتماعي',
    ),
    RoomModel(
      id: 'br_17', roomCode: '990045', name: 'روم تحت الصيانة',
      imagePath: 'assets/images/room_bg_official.webp',
      ownerName: 'Zuparty Team', ownerAvatarPath: 'assets/images/profile.png',
      onlineCount: 0, category: 'اجتماعي', isUnavailable: true,
    ),
  ];

  // ---------------- Home: Online Users ----------------
  static const List<UserModel> onlineUsers = [
    UserModel(id: 'ou1', name: 'Sara', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 12),
    UserModel(id: 'ou2', name: 'Player_01', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 7),
    UserModel(id: 'ou3', name: 'Zuparty Team', avatarPath: 'assets/images/profile.png', isNew: true, level: 1),
    UserModel(id: 'ou4', name: 'Nour', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 9),
    UserModel(id: 'ou5', name: 'Yassine', avatarPath: 'assets/images/profile.png', gender: 'ذكر', isVip: true, level: 15),
    UserModel(id: 'ou6', name: 'Salma', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 4),
    UserModel(id: 'ou7', name: 'Anas', avatarPath: 'assets/images/profile.png', gender: 'ذكر', isNew: true, level: 2),
    UserModel(id: 'ou8', name: 'Rania', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 6),
  ];

  // ---------------- Messages / Conversations ----------------
  static final List<ConversationPreview> conversations = [
    ConversationPreview(name: 'Sara', avatarPath: 'assets/images/profile.png', lastMessage: 'أهلا بيك فـ Zuparty 👋', time: '09:24', unreadCount: 2, isOnline: true, isVip: true),
    ConversationPreview(name: 'Player_01', avatarPath: 'assets/images/profile.png', lastMessage: 'شحال هاد الروم زوينة 🔥', time: 'أمس', isOnline: true),
    ConversationPreview(name: 'Zuparty Team', avatarPath: 'assets/images/profile.png', lastMessage: 'مرحبًا بيك فحسابك الجديد!', time: 'أمس', unreadCount: 1),
    ConversationPreview(name: 'ياسمين', avatarPath: 'assets/images/profile.png', lastMessage: '[هدية] 🌹 وردة', time: 'الإثنين', isVip: true),
    ConversationPreview(name: 'Yassine', avatarPath: 'assets/images/profile.png', lastMessage: '[صورة]', time: 'الأحد', isOnline: true),
    ConversationPreview(name: 'Nour', avatarPath: 'assets/images/profile.png', lastMessage: '[رسالة صوتية] 0:12', time: 'السبت'),
  ];

  static List<MessageModel> messagesFor(String name) {
    final now = DateTime.now();
    return [
      MessageModel(id: 'm1', senderId: 'other', senderName: name, text: 'أهلا 👋', time: now.subtract(const Duration(minutes: 22))),
      MessageModel(id: 'm2', senderId: 'me', senderName: 'أنا', text: 'أهلا بيك! كيف داير؟', time: now.subtract(const Duration(minutes: 20)), isMe: true),
      MessageModel(id: 'm3', senderId: 'other', senderName: name, text: 'لاباس الحمد لله 😄', time: now.subtract(const Duration(minutes: 18))),
      MessageModel(id: 'm4', senderId: 'other', senderName: name, text: '', time: now.subtract(const Duration(minutes: 16)), type: ChatMessageType.image, imagePath: 'assets/images/profile.png'),
      MessageModel(id: 'm5', senderId: 'me', senderName: 'أنا', text: 'صورة زوينة 🔥', time: now.subtract(const Duration(minutes: 15)), isMe: true),
      MessageModel(id: 'm6', senderId: 'other', senderName: name, text: '', time: now.subtract(const Duration(minutes: 10)), type: ChatMessageType.voice, voiceSeconds: 14),
      MessageModel(id: 'm7', senderId: 'me', senderName: 'أنا', text: '', time: now.subtract(const Duration(minutes: 6)), isMe: true, type: ChatMessageType.gift, gift: gifts[0], giftQuantity: 1),
      MessageModel(id: 'm8', senderId: 'other', senderName: name, text: 'شكرا بزاف ❤️🌹', time: now.subtract(const Duration(minutes: 4))),
      MessageModel(id: 'm9', senderId: 'other', senderName: name, text: '👍', time: now.subtract(const Duration(minutes: 2)), type: ChatMessageType.emoji),
    ];
  }

  // ---------------- Gifts ----------------
  static const List<GiftModel> gifts = [
    GiftModel(id: 'g1', name: 'وردة', emoji: '🌹', price: 10),
    GiftModel(id: 'g2', name: 'قلب', emoji: '❤️', price: 20),
    GiftModel(id: 'g3', name: 'تاج', emoji: '👑', price: 500),
    GiftModel(id: 'g4', name: 'سيارة', emoji: '🚗', price: 2000),
  ];

  // ---------------- Voice Room: تصنيفات الهدايا (Phase 4 — Part 2/3) ----------------
  static final List<GiftCategoryModel> giftCategories = [
    GiftCategoryModel(
      id: 'popular',
      label: 'شائعة',
      icon: Icons.local_fire_department_rounded,
      gifts: [
        gifts[0],
        gifts[1],
        const GiftModel(id: 'g5', name: 'بالون', emoji: '🎈', price: 5),
        const GiftModel(id: 'g6', name: 'حلوى', emoji: '🍬', price: 15),
        const GiftModel(id: 'g11', name: 'نجمة', emoji: '⭐', price: 30),
        const GiftModel(id: 'g12', name: 'تصفيق', emoji: '👏', price: 8),
      ],
    ),
    GiftCategoryModel(
      id: 'vip',
      label: 'VIP',
      icon: Icons.workspace_premium_rounded,
      gifts: [
        gifts[2],
        const GiftModel(id: 'g7', name: 'خاتم', emoji: '💍', price: 800),
        const GiftModel(id: 'g8', name: 'قصر', emoji: '🏰', price: 3500),
        const GiftModel(id: 'g13', name: 'صاروخ', emoji: '🚀', price: 1200),
      ],
    ),
    GiftCategoryModel(
      id: 'luxury',
      label: 'فاخرة',
      icon: Icons.diamond_rounded,
      gifts: [
        gifts[3],
        const GiftModel(id: 'g9', name: 'يخت', emoji: '🛥️', price: 5000),
        const GiftModel(id: 'g10', name: 'طائرة', emoji: '✈️', price: 8000),
      ],
    ),
  ];

  // ---------------- Voice Room: سجل الهدايا (Gift History — Mock ثابت) ----------------
  static final List<GiftHistoryEntry> voiceRoomGiftHistory = [
    GiftHistoryEntry(
      id: 'gh1',
      sender: const UserModel(id: 'm_speaker1', name: 'Player_01', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 9),
      receiver: const UserModel(id: 'm_owner', name: 'ربيع', avatarPath: 'assets/images/profile.png', isVip: true, level: 24),
      gift: gifts[0],
      quantity: 3,
      time: DateTime.now().subtract(const Duration(minutes: 15)),
    ),
    GiftHistoryEntry(
      id: 'gh2',
      sender: const UserModel(id: 'm_speaker2', name: 'Sara', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 12),
      receiver: const UserModel(id: 'm_owner', name: 'ربيع', avatarPath: 'assets/images/profile.png', isVip: true, level: 24),
      gift: gifts[2],
      quantity: 1,
      time: DateTime.now().subtract(const Duration(hours: 1)),
    ),
  ];

  // ---------------- Voice Room: دردشة الروم — Seed أولي (Phase 4 — Part 2/3) ----------------
  static List<RoomChatMessage> voiceRoomChatSeed() {
    final now = DateTime.now();
    return [
      RoomChatMessage(
        id: 'c_sys1',
        type: RoomChatMessageType.system,
        text: 'أهلاً بيكم فالروم 🎉 يرجى احترام الجميع',
        time: now.subtract(const Duration(minutes: 30)),
      ),
      RoomChatMessage(
        id: 'c_join1',
        type: RoomChatMessageType.join,
        sender: const UserModel(id: 'm_speaker2', name: 'Sara', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 12),
        time: now.subtract(const Duration(minutes: 22)),
      ),
      RoomChatMessage(
        id: 'c_txt1',
        type: RoomChatMessageType.text,
        sender: const UserModel(id: 'm_admin1', name: 'ياسمين', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 18),
        text: 'مرحبا بالجميع 👋',
        time: now.subtract(const Duration(minutes: 20)),
      ),
      RoomChatMessage(
        id: 'c_gift1',
        type: RoomChatMessageType.gift,
        sender: const UserModel(id: 'm_speaker1', name: 'Player_01', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 9),
        giftReceiver: const UserModel(id: 'm_owner', name: 'ربيع', avatarPath: 'assets/images/profile.png', isVip: true, level: 24),
        gift: gifts[0],
        giftQuantity: 3,
        time: now.subtract(const Duration(minutes: 15)),
      ),
      RoomChatMessage(
        id: 'c_join2',
        type: RoomChatMessageType.join,
        sender: const UserModel(id: 'm_mem1', name: 'خالد', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 5),
        time: now.subtract(const Duration(minutes: 10)),
      ),
      RoomChatMessage(
        id: 'c_txt2',
        type: RoomChatMessageType.text,
        sender: const UserModel(id: 'm_mem2', name: 'نور', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isNew: true, level: 1),
        text: 'الروم زوينة بزاف 🔥',
        time: now.subtract(const Duration(minutes: 6)),
      ),
    ];
  }

  // ---------------- Voice Room: دعوة أعضاء (Invite — Mock ثابت) ----------------
  static const List<UserModel> inviteCandidates = [
    UserModel(id: 'inv1', name: 'Sara', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 12),
    UserModel(id: 'inv2', name: 'Nour', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 9),
    UserModel(id: 'inv3', name: 'Yassine', avatarPath: 'assets/images/profile.png', gender: 'ذكر', isVip: true, level: 15),
    UserModel(id: 'inv4', name: 'Salma', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 4),
    UserModel(id: 'inv5', name: 'Anas', avatarPath: 'assets/images/profile.png', gender: 'ذكر', isNew: true, level: 2),
    UserModel(id: 'inv6', name: 'Rania', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 6),
    UserModel(id: 'inv7', name: 'Player_01', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 7),
  ];

  /// المقترحون (Recommended) — Mock: أول 3 من نفس قائمة الدعوة
  static List<UserModel> get inviteRecommended => inviteCandidates.take(3).toList();

  // ---------------- Games (الألعاب الموجودة فعليًا فالمشروع) ----------------
  static const List<GameModel> games = [
    GameModel(
      id: 'lucky_fruit',
      name: 'Lucky Fruit',
      assetPath: 'assets/games/lucky_fruit/index.html',
      color: Color(0xFFED3914),
      emoji: '🍒',
      category: 'مميزة',
      description: 'لعبة حظ سريعة: راهن على الفواكه واربح Coins مضاعفة.',
      players: 1284,
      isPlayable: true,
      isFeatured: true,
    ),
    GameModel(
      id: 'greedy_pro',
      name: 'Greedy Pro',
      assetPath: 'assets/games/greedy_pro/index.html',
      color: Color(0xFF3A1650),
      emoji: '💰',
      category: 'مميزة',
      description: 'اجمع الكنوز وتفادى الأخطار فمغامرة Greedy Pro المثيرة.',
      players: 962,
      isPlayable: true,
      isFeatured: true,
    ),
    GameModel(
      id: 'lucky_wheel',
      name: 'عجلة الحظ',
      assetPath: '',
      color: Color(0xFF0288D1),
      emoji: '🎡',
      category: 'شائعة',
      description: 'أدر العجلة واربح جوائز وCoins عشوائية كل يوم.',
      players: 2110,
      isPlayable: false,
    ),
    GameModel(
      id: 'dice_kings',
      name: 'Dice Kings',
      assetPath: '',
      color: Color(0xFF2E7D32),
      emoji: '🎲',
      category: 'جديدة',
      description: 'لعبة نرد جماعية تفاعلية مع أصدقائك فالغرفة.',
      players: 340,
      isPlayable: false,
      isNew: true,
    ),
    GameModel(
      id: 'card_master',
      name: 'Card Master',
      assetPath: '',
      color: Color(0xFFF9A825),
      emoji: '🃏',
      category: 'بطاقات',
      description: 'تحدى لاعبين آخرين فلعبة بطاقات كلاسيكية.',
      players: 578,
      isPlayable: false,
      isNew: true,
    ),
  ];

  static List<GameModel> get featuredGames => games.where((g) => g.isFeatured).toList();
  static List<GameModel> get newGames => games.where((g) => g.isNew).toList();
  static List<GameModel> get popularGames =>
      (List<GameModel>.from(games)..sort((a, b) => b.players.compareTo(a.players)));

  static const List<String> gameCategories = ['الكل', 'مميزة', 'شائعة', 'جديدة', 'بطاقات', 'حظ'];

  static final List<GameHistoryEntry> gameHistory = [
    GameHistoryEntry(gameId: 'lucky_fruit', gameName: 'Lucky Fruit', emoji: '🍒', time: DateTime.now().subtract(const Duration(minutes: 30)), coinsChange: 120, isWin: true),
    GameHistoryEntry(gameId: 'greedy_pro', gameName: 'Greedy Pro', emoji: '💰', time: DateTime.now().subtract(const Duration(hours: 3)), coinsChange: -50, isWin: false),
    GameHistoryEntry(gameId: 'lucky_fruit', gameName: 'Lucky Fruit', emoji: '🍒', time: DateTime.now().subtract(const Duration(days: 1)), coinsChange: 300, isWin: true),
    GameHistoryEntry(gameId: 'greedy_pro', gameName: 'Greedy Pro', emoji: '💰', time: DateTime.now().subtract(const Duration(days: 2)), coinsChange: -20, isWin: false),
  ];

  static const List<RankingEntry> gameRanking = [
    RankingEntry(rank: 1, userName: 'Player_01', avatarPath: 'assets/images/profile.png', score: 24800),
    RankingEntry(rank: 2, userName: 'Sara', avatarPath: 'assets/images/profile.png', score: 19750),
    RankingEntry(rank: 3, userName: 'Yassine', avatarPath: 'assets/images/profile.png', score: 15420),
    RankingEntry(rank: 4, userName: 'Anas', avatarPath: 'assets/images/profile.png', score: 9100),
    RankingEntry(rank: 5, userName: 'Rania', avatarPath: 'assets/images/profile.png', score: 7600),
  ];

  // ---------------- Wallet: سجل المعاملات (Mock فقط) ----------------
  static final List<WalletTransaction> walletTransactions = [
    WalletTransaction(id: 't1', type: WalletTxType.recharge, title: 'إعادة شحن', amount: 1200, time: DateTime.now().subtract(const Duration(hours: 2))),
    WalletTransaction(id: 't2', type: WalletTxType.giftSent, title: 'هدية إلى Sara — تاج 👑', amount: -500, time: DateTime.now().subtract(const Duration(hours: 5))),
    WalletTransaction(id: 't3', type: WalletTxType.giftReceived, title: 'هدية من Player_01', amount: 200, time: DateTime.now().subtract(const Duration(days: 1))),
    WalletTransaction(id: 't4', type: WalletTxType.gameWin, title: 'ربح — Lucky Fruit', amount: 120, time: DateTime.now().subtract(const Duration(days: 1, hours: 2))),
    WalletTransaction(id: 't5', type: WalletTxType.gameLoss, title: 'خسارة — Greedy Pro', amount: -50, time: DateTime.now().subtract(const Duration(days: 2))),
    WalletTransaction(id: 't6', type: WalletTxType.vipSub, title: 'اشتراك VIP شهري', amount: -500, time: DateTime.now().subtract(const Duration(days: 4))),
    WalletTransaction(id: 't7', type: WalletTxType.recharge, title: 'إعادة شحن', amount: 550, time: DateTime.now().subtract(const Duration(days: 6))),
  ];

  // ---------------- Profile: شارات وإنجازات (Mock فقط) ----------------
  static const List<BadgeModel> badges = [
    BadgeModel(id: 'b1', label: 'عضو مؤسس', icon: Icons.emoji_events_rounded, color: Color(0xFFF9A825)),
    BadgeModel(id: 'b2', label: 'نجم الغرف', icon: Icons.mic_rounded, color: Color(0xFFED3914)),
    BadgeModel(id: 'b3', label: 'كريم الهدايا', icon: Icons.card_giftcard_rounded, color: Color(0xFF3A1650)),
    BadgeModel(id: 'b4', label: 'محبوب', icon: Icons.favorite_rounded, color: Color(0xFFE91E63)),
    BadgeModel(id: 'b5', label: 'بطل الألعاب', icon: Icons.sports_esports_rounded, color: Color(0xFF2E7D32), isUnlocked: false, progressLabel: '6/10'),
    BadgeModel(id: 'b6', label: 'صديق الجميع', icon: Icons.groups_rounded, color: Color(0xFF0288D1), isUnlocked: false, progressLabel: '40/100'),
  ];

  static const List<BadgeModel> achievements = [
    BadgeModel(id: 'a1', label: 'أول تسجيل دخول', icon: Icons.login_rounded, color: Color(0xFF2E7D32)),
    BadgeModel(id: 'a2', label: '7 أيام متتالية', icon: Icons.local_fire_department_rounded, color: Color(0xFFED3914)),
    BadgeModel(id: 'a3', label: 'أرسل 50 هدية', icon: Icons.card_giftcard_rounded, color: Color(0xFF3A1650), isUnlocked: false, progressLabel: '32/50'),
    BadgeModel(id: 'a4', label: 'وصل للمستوى 20', icon: Icons.trending_up_rounded, color: Color(0xFFF9A825), isUnlocked: false, progressLabel: '14/20'),
  ];

  // ---------------- Rankings ----------------
  static const List<RankingEntry> rankings = [
    RankingEntry(rank: 1, userName: 'Sara', avatarPath: 'assets/images/profile.png', score: 12500),
    RankingEntry(rank: 2, userName: 'Player_01', avatarPath: 'assets/images/profile.png', score: 9800),
    RankingEntry(rank: 3, userName: 'Zuparty Team', avatarPath: 'assets/images/profile.png', score: 6400),
    RankingEntry(rank: 4, userName: 'Yassine', avatarPath: 'assets/images/profile.png', score: 5200),
    RankingEntry(rank: 5, userName: 'Nour', avatarPath: 'assets/images/profile.png', score: 4100),
  ];

  // ---------------- Voice Room: Ranking (Phase 4 — Part 3/3) ----------------
  // ترتيب داخل الروم (أسبوعي + أفضل المساهمين بالهدايا) — Mock/Local فقط
  static const List<RankingEntry> roomWeeklyRanking = [
    RankingEntry(rank: 1, userName: 'Sara', avatarPath: 'assets/images/profile.png', score: 48200),
    RankingEntry(rank: 2, userName: 'ياسمين', avatarPath: 'assets/images/profile.png', score: 35600),
    RankingEntry(rank: 3, userName: 'Player_01', avatarPath: 'assets/images/profile.png', score: 27950),
    RankingEntry(rank: 4, userName: 'Yassine', avatarPath: 'assets/images/profile.png', score: 19100),
    RankingEntry(rank: 5, userName: 'Nour', avatarPath: 'assets/images/profile.png', score: 14300),
    RankingEntry(rank: 6, userName: 'Anas', avatarPath: 'assets/images/profile.png', score: 9800),
    RankingEntry(rank: 7, userName: 'Rania', avatarPath: 'assets/images/profile.png', score: 6200),
  ];

  static const List<RankingEntry> roomTopContributors = [
    RankingEntry(rank: 1, userName: 'Player_01', avatarPath: 'assets/images/profile.png', score: 152000),
    RankingEntry(rank: 2, userName: 'Sara', avatarPath: 'assets/images/profile.png', score: 98500),
    RankingEntry(rank: 3, userName: 'Salma', avatarPath: 'assets/images/profile.png', score: 71200),
    RankingEntry(rank: 4, userName: 'ياسمين', avatarPath: 'assets/images/profile.png', score: 44300),
    RankingEntry(rank: 5, userName: 'Anas', avatarPath: 'assets/images/profile.png', score: 22750),
  ];

  // ---------------- Events ----------------
  static final List<EventItem> events = [
    EventItem(
      id: 'e1',
      title: 'فعالية الافتتاح 🎉',
      description: 'انضم لأول فعالية فـ Zuparty واربح جوائز حصرية.',
      startDate: DateTime.now(),
      endDate: DateTime.now().add(const Duration(days: 7)),
    ),
    EventItem(
      id: 'e2',
      title: 'تحدي الغرف الأسبوعي 🏆',
      description: 'أكثر غرفة تفاعل هاد الأسبوع كتربح بادج حصري.',
      startDate: DateTime.now(),
      endDate: DateTime.now().add(const Duration(days: 3)),
    ),
  ];

  // ---------------- Notifications ----------------
  static final List<NotificationItem> notifications = [
    NotificationItem(
      id: 'n1',
      title: 'مرحبًا بيك فـ Zuparty 🎉',
      body: 'أهلا بيك فحسابك الجديد، اكتشف الغرف وألعاب Zuparty الآن.',
      time: DateTime.now().subtract(const Duration(minutes: 5)),
    ),
    NotificationItem(
      id: 'n2',
      title: 'دعوة إلى الميكروفون',
      body: 'Sara دعتك للصعود إلى الميكروفون فـ "السهرات العربية".',
      time: DateTime.now().subtract(const Duration(hours: 2)),
    ),
    NotificationItem(
      id: 'n3',
      title: 'فعالية الافتتاح 🎊',
      body: 'انضم لأول فعالية فـ Zuparty واربح جوائز حصرية.',
      time: DateTime.now().subtract(const Duration(days: 1)),
      isRead: true,
    ),
  ];

  // ---------------- Coins / VIP ----------------
  static const List<CoinPackage> coinPackages = [
    CoinPackage(id: 'usd10', coins: 35000000, priceLabel: '\$10'),
    CoinPackage(id: 'usd50', coins: 175000000, priceLabel: '\$50', isBestValue: true),
    CoinPackage(id: 'usd100', coins: 350000000, priceLabel: '\$100'),
  ];

  static const List<VipTier> vipTiers = [
    VipTier(
      title: 'VIP 1',
      level: 1,
      priceCoinsPerMonth: 500,
      perks: ['بادج VIP مميز', 'دخول أولوية للغرف', 'إطار صورة حصري'],
      color: Color(0xFFF9A825),
      minPoints: 0,
    ),
    VipTier(
      title: 'VIP 2',
      level: 2,
      priceCoinsPerMonth: 1000,
      perks: ['كل مزايا VIP 1', 'تأثير دخول للغرفة', 'رسائل ملونة'],
      color: Color(0xFFFF7043),
      minPoints: 2000,
    ),
    VipTier(
      title: 'SVIP',
      level: 3,
      priceCoinsPerMonth: 1500,
      perks: ['كل مزايا VIP 2', 'هدايا حصرية SVIP', 'دعم عملاء مخصص', 'بادج ذهبي متحرك'],
      color: Color(0xFF3A1650),
      minPoints: 6000,
    ),
  ];

  /// نقاط VIP الحالية للمستخدم (Mock — تحدد مستوى التقدّم فـ VIP Center)
  static int userVipPoints = 2450;

  /// رصيد Coins الحالي للمستخدم (Mock موحّد — يُستعمل فالمحفظة/الهدايا/VIP)
  static int userCoinBalance = 0;

  // ---------------- Friends ----------------
  static const List<FriendModel> friends = [
    FriendModel(id: 'f1', name: 'Sara', avatarPath: 'assets/images/profile.png', isOnline: true),
    FriendModel(id: 'f2', name: 'Player_01', avatarPath: 'assets/images/profile.png'),
    FriendModel(id: 'f3', name: 'Zuparty Team', avatarPath: 'assets/images/profile.png', isOnline: true),
  ];

  // ---------------- Profile: متابَعون / متابِعون (Mock فقط) ----------------
  static const List<UserModel> followers = [
    UserModel(id: 'fw1', name: 'Sara', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 12),
    UserModel(id: 'fw2', name: 'Player_01', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 9),
    UserModel(id: 'fw3', name: 'خالد', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 5),
    UserModel(id: 'fw4', name: 'نور', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isNew: true, level: 1),
    UserModel(id: 'fw5', name: 'Rania', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 6),
  ];

  static const List<UserModel> following = [
    UserModel(id: 'fl1', name: 'ياسمين', avatarPath: 'assets/images/profile.png', gender: 'أنثى', isVip: true, level: 18),
    UserModel(id: 'fl2', name: 'Yassine', avatarPath: 'assets/images/profile.png', gender: 'ذكر', isVip: true, level: 15),
    UserModel(id: 'fl3', name: 'Anas', avatarPath: 'assets/images/profile.png', gender: 'ذكر', isNew: true, level: 2),
    UserModel(id: 'fl4', name: 'Zuparty Team', avatarPath: 'assets/images/profile.png', level: 30),
  ];

  // ---------------- Profile: الهدايا المستلمة (Mock فقط) ----------------
  static final List<GiftHistoryEntry> profileReceivedGifts = [
    GiftHistoryEntry(id: 'pg1', sender: const UserModel(id: 'm_speaker1', name: 'Player_01', avatarPath: 'assets/images/profile.png', level: 9), receiver: users.first, gift: gifts[2], quantity: 1, time: DateTime.now().subtract(const Duration(hours: 4))),
    GiftHistoryEntry(id: 'pg2', sender: const UserModel(id: 'm_speaker2', name: 'Sara', avatarPath: 'assets/images/profile.png', isVip: true, level: 12), receiver: users.first, gift: gifts[0], quantity: 5, time: DateTime.now().subtract(const Duration(days: 1))),
    GiftHistoryEntry(id: 'pg3', sender: const UserModel(id: 'm_admin1', name: 'ياسمين', avatarPath: 'assets/images/profile.png', isVip: true, level: 18), receiver: users.first, gift: gifts[1], quantity: 3, time: DateTime.now().subtract(const Duration(days: 2))),
  ];

  // ============================================================
  // Phase 5 — Part 3/3: Rankings / Events / Notifications / Friends / Search
  // ============================================================

  // ---------------- Rankings: تصنيفات إضافية (مستخدم/هدية/ثروة/مساهمة) ----------------
  static const List<RankingEntry> userWealthRanking = [
    RankingEntry(rank: 1, userName: 'Player_01', avatarPath: 'assets/images/profile.png', score: 320000, isVip: true, levelChange: 1),
    RankingEntry(rank: 2, userName: 'Sara', avatarPath: 'assets/images/profile.png', score: 275500, isVip: true, levelChange: -1),
    RankingEntry(rank: 3, userName: 'Yassine', avatarPath: 'assets/images/profile.png', score: 198200, isVip: true),
    RankingEntry(rank: 4, userName: 'ياسمين', avatarPath: 'assets/images/profile.png', score: 121000, levelChange: 2),
    RankingEntry(rank: 5, userName: 'Zuparty Team', avatarPath: 'assets/images/profile.png', score: 87500),
    RankingEntry(rank: 6, userName: 'Anas', avatarPath: 'assets/images/profile.png', score: 45200, levelChange: -1),
  ];

  static const List<RankingEntry> giftSendersRanking = [
    RankingEntry(rank: 1, userName: 'Sara', avatarPath: 'assets/images/profile.png', score: 152000, isVip: true),
    RankingEntry(rank: 2, userName: 'ياسمين', avatarPath: 'assets/images/profile.png', score: 98500, isVip: true, levelChange: 1),
    RankingEntry(rank: 3, userName: 'Nour', avatarPath: 'assets/images/profile.png', score: 61200),
    RankingEntry(rank: 4, userName: 'Rania', avatarPath: 'assets/images/profile.png', score: 33300, levelChange: -1),
    RankingEntry(rank: 5, userName: 'Salma', avatarPath: 'assets/images/profile.png', score: 18750),
  ];

  static const List<RankingEntry> contributionRanking = [
    RankingEntry(rank: 1, userName: 'Zuparty Team', avatarPath: 'assets/images/profile.png', score: 9800),
    RankingEntry(rank: 2, userName: 'ربيع', avatarPath: 'assets/images/profile.png', score: 7200, levelChange: 1),
    RankingEntry(rank: 3, userName: 'Player_01', avatarPath: 'assets/images/profile.png', score: 5100),
    RankingEntry(rank: 4, userName: 'Anas', avatarPath: 'assets/images/profile.png', score: 3400, levelChange: -2),
  ];

  static const List<RankingEntry> monthlyRanking = [
    RankingEntry(rank: 1, userName: 'Yassine', avatarPath: 'assets/images/profile.png', score: 540200, isVip: true, levelChange: 2),
    RankingEntry(rank: 2, userName: 'Sara', avatarPath: 'assets/images/profile.png', score: 498100, isVip: true, levelChange: -1),
    RankingEntry(rank: 3, userName: 'Player_01', avatarPath: 'assets/images/profile.png', score: 355000),
    RankingEntry(rank: 4, userName: 'Nour', avatarPath: 'assets/images/profile.png', score: 210400, levelChange: 1),
    RankingEntry(rank: 5, userName: 'Zuparty Team', avatarPath: 'assets/images/profile.png', score: 152300),
  ];

  // ---------------- Events: مهام/جوائز/ترتيب لكل فعالية ----------------
  static final List<EventItem> eventsDetailed = [
    EventItem(
      id: 'e1',
      title: 'فعالية الافتتاح 🎉',
      description: 'انضم لأول فعالية فـ Zuparty وأكمل المهام لربح جوائز حصرية ومكانة فالترتيب العام.',
      startDate: DateTime.now().subtract(const Duration(days: 1)),
      endDate: DateTime.now().add(const Duration(days: 6)),
      isJoined: true,
      badgeLabel: 'جديد',
      tasks: const [
        EventTask(id: 't1', title: 'ادخل لـ 3 غرف مختلفة', targetValue: 3, currentValue: 3, rewardLabel: '+200 Coins', status: EventTaskStatus.completed),
        EventTask(id: 't2', title: 'أرسل هدية واحدة على الأقل', targetValue: 1, currentValue: 0, rewardLabel: 'بادج حصري', status: EventTaskStatus.inProgress),
        EventTask(id: 't3', title: 'اقضِ 30 دقيقة فالتطبيق', targetValue: 30, currentValue: 12, rewardLabel: '+500 Coins', status: EventTaskStatus.inProgress),
      ],
      ranking: userWealthRanking,
    ),
    EventItem(
      id: 'e2',
      title: 'تحدي الغرف الأسبوعي 🏆',
      description: 'أكثر غرفة تفاعل هاد الأسبوع كتربح بادج حصري ومكافآت لكل الأعضاء.',
      startDate: DateTime.now().subtract(const Duration(days: 2)),
      endDate: DateTime.now().add(const Duration(days: 2)),
      badgeLabel: 'ساخن',
      tasks: const [
        EventTask(id: 't4', title: 'شارك فروم أثناء الفعالية', targetValue: 1, currentValue: 1, rewardLabel: '+100 Coins', status: EventTaskStatus.claimed),
        EventTask(id: 't5', title: 'ادعُ صديق للروم', targetValue: 1, currentValue: 0, rewardLabel: '+150 Coins', status: EventTaskStatus.locked),
      ],
      ranking: roomWeeklyRanking,
    ),
    EventItem(
      id: 'e3',
      title: 'سباق الهدايا الذهبي 🎁',
      description: 'أرسل أكبر عدد من الهدايا الذهبية وادخل قائمة أفضل 10 مرسلين.',
      startDate: DateTime.now().add(const Duration(days: 1)),
      endDate: DateTime.now().add(const Duration(days: 10)),
      badgeLabel: 'قريبًا',
      tasks: const [
        EventTask(id: 't6', title: 'أرسل 5 هدايا ذهبية', targetValue: 5, currentValue: 0, rewardLabel: 'إطار صورة حصري', status: EventTaskStatus.locked),
      ],
      ranking: giftSendersRanking,
    ),
  ];

  // ---------------- Notifications: مصنّفة حسب النوع ----------------
  static final List<NotificationItem> notificationsDetailed = [
    NotificationItem(id: 'nn1', title: 'مرحبًا بيك فـ Zuparty 🎉', body: 'أهلا بيك فحسابك الجديد، اكتشف الغرف وألعاب Zuparty الآن.', time: DateTime.now().subtract(const Duration(minutes: 5)), type: NotificationType.system),
    NotificationItem(id: 'nn2', title: 'هدية جديدة 🎁', body: 'Sara أرسلت ليك 🌹 وردة فـ "السهرات العربية".', time: DateTime.now().subtract(const Duration(minutes: 40)), type: NotificationType.gift, avatarPath: 'assets/images/profile.png'),
    NotificationItem(id: 'nn3', title: 'متابع جديد', body: 'ياسمين بدات تتابعك الآن.', time: DateTime.now().subtract(const Duration(hours: 1)), type: NotificationType.follower, avatarPath: 'assets/images/profile.png'),
    NotificationItem(id: 'nn4', title: 'إعجاب بصورتك', body: 'Player_01 وشخصين آخرين أعجبوا بصورة البروفيل ديالك.', time: DateTime.now().subtract(const Duration(hours: 2)), type: NotificationType.like, isRead: true),
    NotificationItem(id: 'nn5', title: 'دعوة لغرفة', body: 'ربيع دعاك للانضمام لغرفة "Gaming Room".', time: DateTime.now().subtract(const Duration(hours: 3)), type: NotificationType.roomInvite, avatarPath: 'assets/images/profile.png'),
    NotificationItem(id: 'nn6', title: 'فعالية الافتتاح 🎊', body: 'باقي 3 أيام لانتهاء فعالية الافتتاح، أكمل مهامك الآن.', time: DateTime.now().subtract(const Duration(days: 1)), type: NotificationType.event, isRead: true),
    NotificationItem(id: 'nn7', title: 'رسالة جديدة', body: 'Nour: "شحال هاد الروم زوينة 🔥"', time: DateTime.now().subtract(const Duration(days: 1, hours: 2)), type: NotificationType.message, isRead: true, avatarPath: 'assets/images/profile.png'),
    NotificationItem(id: 'nn8', title: 'تحديث النظام', body: 'تم إصلاح بعض المشاكل وتحسين الأداء العام للتطبيق.', time: DateTime.now().subtract(const Duration(days: 3)), type: NotificationType.system, isRead: true),
  ];

  // ---------------- Friends: طلبات المتابعة + المحظورون ----------------
  static const List<UserModel> friendRequests = [
    UserModel(id: 'fr1', name: 'خالد', avatarPath: 'assets/images/profile.png', gender: 'ذكر', level: 8, isRequestPending: true),
    UserModel(id: 'fr2', name: 'Salma', avatarPath: 'assets/images/profile.png', gender: 'أنثى', level: 3, isRequestPending: true),
  ];

  static const List<UserModel> blockedUsers = [
    UserModel(id: 'bl1', name: 'مستخدم مزعج', avatarPath: 'assets/images/profile.png', isBlocked: true, level: 1),
  ];

  // ---------------- Search: عمليات بحث سابقة (Mock محلي فقط) ----------------
  static final List<String> recentSearches = ['السهرات العربية', 'Sara', 'Lucky Fruit', 'ROOM-2201'];
}
