import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../data/mock_data.dart';
import '../../routing/app_page_route.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import '../profile/profile_screen.dart';

/// ============================================================
/// Phase 5 — Part 3/3: شاشة الأصدقاء / السوشيال الكاملة
/// أصدقاء / متابِعون / متابَعون / متصلون الآن / الطلبات /
/// موصى بهم / دعوة أصدقاء / محظورون — كلها Local + Mock Data.
/// ============================================================
class FriendsScreen extends StatefulWidget {
  final int initialTabIndex;
  const FriendsScreen({super.key, this.initialTabIndex = 0});

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  // نسخ محلية قابلة للتعديل (متابعة/إلغاء متابعة/قبول/رفض/حظر...) — Local State فقط
  late List<UserModel> _followers = List.of(MockData.followers);
  late List<UserModel> _following = List.of(MockData.following);
  late List<UserModel> _requests = List.of(MockData.friendRequests);
  late List<UserModel> _blocked = List.of(MockData.blockedUsers);

  static const _tabs = ['friends_title', 'friends_followers', 'friends_following', 'friends_online', 'friends_requests', 'friends_recommended', 'friends_blocked'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this, initialIndex: widget.initialTabIndex.clamp(0, _tabs.length - 1));
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _toggleFollow(UserModel user, List<UserModel> list) {
    setState(() {
      final i = list.indexWhere((u) => u.id == user.id);
      if (i != -1) list[i] = list[i].copyWith(isFollowing: !list[i].isFollowing);
    });
  }

  void _acceptRequest(UserModel user) {
    setState(() {
      _requests.removeWhere((u) => u.id == user.id);
      _followers.insert(0, user.copyWith(isRequestPending: false));
    });
    zpToast(context, '${user.name}: ${S.tr('friends_accept')} ✓');
  }

  void _declineRequest(UserModel user) {
    setState(() => _requests.removeWhere((u) => u.id == user.id));
    zpToast(context, '${user.name}: ${S.tr('friends_decline')}', icon: Icons.close_rounded, color: AppColors.grey500);
  }

  Future<void> _unblockUser(UserModel user) async {
    final ok = await zpConfirmSheet(
      context,
      title: S.tr('friends_unblock'),
      message: user.name,
      confirmLabel: S.tr('friends_unblock'),
      icon: Icons.person_off_outlined,
      color: AppColors.primary,
    );
    if (ok) {
      setState(() => _blocked.removeWhere((u) => u.id == user.id));
      zpToast(context, '${user.name}: ${S.tr('friends_unblock')} ✓');
    }
  }

  void _openInviteSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl))),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.xl, AppSpacing.lg, AppSpacing.xl, AppSpacing.xl),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4))),
                const SizedBox(height: AppSpacing.lg),
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), shape: BoxShape.circle),
                  child: const Icon(Icons.ios_share_rounded, color: AppColors.primary, size: 26),
                ),
                const SizedBox(height: AppSpacing.md),
                Text(S.tr('friends_invite'), style: AppTextStyles.h3, textAlign: TextAlign.center),
                const SizedBox(height: AppSpacing.xs),
                const Text('ID: 10000001 — zuparty.app/invite/10000001', style: AppTextStyles.caption, textAlign: TextAlign.center),
                const SizedBox(height: AppSpacing.xl),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      zpToast(context, 'تم نسخ رابط الدعوة (محاكاة محلية)', icon: Icons.check_circle_rounded, color: AppColors.success);
                    },
                    icon: const Icon(Icons.copy_rounded, size: 17),
                    label: const Text('نسخ رابط الدعوة'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: Text(S.tr('friends_title'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        actions: [
          IconButton(icon: const Icon(Icons.person_add_alt_1_rounded, color: AppColors.primary), onPressed: _openInviteSheet, tooltip: S.tr('friends_invite')),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.grey500,
          indicatorColor: AppColors.primary,
          labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          tabs: _tabs.map((k) => Tab(text: S.tr(k))).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _friendsTab(),
          _userListTab(_followers, S.tr('friends_empty_followers'), showFollowBtn: true, listRef: _followers),
          _userListTab(_following, S.tr('friends_empty_following'), showFollowBtn: true, listRef: _following),
          _onlineTab(),
          _requestsTab(),
          _recommendedTab(),
          _blockedTab(),
        ],
      ),
    );
  }

  // ---------------- Friends (close friends list) ----------------
  Widget _friendsTab() {
    final friends = MockData.friends;
    if (friends.isEmpty) {
      return AppEmptyState(icon: Icons.people_outline_rounded, title: S.tr('friends_empty_followers'));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: friends.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final f = friends[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: ZpAvatar(imagePath: f.avatarPath, size: 46, showOnlineDot: f.isOnline),
          title: Text(f.name, style: AppTextStyles.bodyBold),
          subtitle: f.isOnline ? Text(S.tr('friends_online'), style: const TextStyle(color: AppColors.success, fontSize: 11.5)) : null,
          onTap: () => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: UserModel(id: f.id, name: f.name, avatarPath: f.avatarPath)))),
          trailing: OutlinedButton(
            onPressed: () => zpToast(context, f.isFollowing ? S.tr('friends_following_btn') : S.tr('friends_follow')),
            child: Text(f.isFollowing ? S.tr('friends_following_btn') : S.tr('friends_follow')),
          ),
        );
      },
    );
  }

  // ---------------- Followers / Following (generic) ----------------
  Widget _userListTab(List<UserModel> list, String emptyLabel, {required bool showFollowBtn, required List<UserModel> listRef}) {
    if (list.isEmpty) {
      return AppEmptyState(icon: Icons.people_outline_rounded, title: emptyLabel);
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: list.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final u = list[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: ZpAvatar(imagePath: u.avatarPath, size: 46, showVipRing: u.isVip, showOnlineDot: u.isOnline),
          title: Text(u.name, style: AppTextStyles.bodyBold),
          subtitle: Align(alignment: Alignment.centerRight, child: ZpLevelBadge(level: u.level)),
          onTap: () => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: u))),
          trailing: showFollowBtn
              ? OutlinedButton(
                  onPressed: () => _toggleFollow(u, listRef),
                  style: u.isFollowing
                      ? null
                      : OutlinedButton.styleFrom(backgroundColor: AppColors.primary, side: const BorderSide(color: AppColors.primary)),
                  child: Text(
                    u.isFollowing ? S.tr('friends_following_btn') : S.tr('friends_follow'),
                    style: TextStyle(color: u.isFollowing ? null : Colors.white),
                  ),
                )
              : null,
        );
      },
    );
  }

  // ---------------- Online now ----------------
  Widget _onlineTab() {
    final online = MockData.onlineUsers;
    if (online.isEmpty) {
      return AppEmptyState(icon: Icons.wifi_off_rounded, title: S.tr('friends_empty_online'));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(AppSpacing.lg),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisSpacing: AppSpacing.md, crossAxisSpacing: AppSpacing.sm, childAspectRatio: 0.78),
      itemCount: online.length,
      itemBuilder: (context, i) {
        final u = online[i];
        return GestureDetector(
          onTap: () => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: u))),
          child: Column(
            children: [
              ZpAvatar(imagePath: u.avatarPath, size: 56, showOnlineDot: true, showVipRing: u.isVip),
              const SizedBox(height: 6),
              Text(u.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w700)),
            ],
          ),
        );
      },
    );
  }

  // ---------------- Requests ----------------
  Widget _requestsTab() {
    if (_requests.isEmpty) {
      return AppEmptyState(icon: Icons.person_add_disabled_rounded, title: S.tr('friends_empty_requests'));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: _requests.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final u = _requests[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: ZpAvatar(imagePath: u.avatarPath, size: 46),
          title: Text(u.name, style: AppTextStyles.bodyBold),
          subtitle: Align(alignment: Alignment.centerRight, child: ZpLevelBadge(level: u.level)),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              OutlinedButton(onPressed: () => _declineRequest(u), child: Text(S.tr('friends_decline'))),
              const SizedBox(width: 6),
              ElevatedButton(onPressed: () => _acceptRequest(u), child: Text(S.tr('friends_accept'))),
            ],
          ),
        );
      },
    );
  }

  // ---------------- Recommended ----------------
  Widget _recommendedTab() {
    final list = MockData.inviteCandidates;
    if (list.isEmpty) {
      return AppEmptyState(icon: Icons.person_search_rounded, title: S.tr('no_results'));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: list.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final u = list[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: ZpAvatar(imagePath: u.avatarPath, size: 46, showVipRing: u.isVip),
          title: Text(u.name, style: AppTextStyles.bodyBold),
          subtitle: Align(alignment: Alignment.centerRight, child: ZpLevelBadge(level: u.level)),
          onTap: () => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: u))),
          trailing: OutlinedButton(
            onPressed: () => zpToast(context, S.tr('friends_follow')),
            child: Text(S.tr('friends_follow')),
          ),
        );
      },
    );
  }

  // ---------------- Blocked ----------------
  Widget _blockedTab() {
    if (_blocked.isEmpty) {
      return AppEmptyState(icon: Icons.block_rounded, title: S.tr('friends_empty_blocked'));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: _blocked.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final u = _blocked[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: ZpAvatar(imagePath: u.avatarPath, size: 46),
          title: Text(u.name, style: AppTextStyles.bodyBold),
          trailing: OutlinedButton(onPressed: () => _unblockUser(u), child: Text(S.tr('friends_unblock'))),
        );
      },
    );
  }
}
