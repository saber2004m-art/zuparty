import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../data/models.dart';
import '../../services/zuparty_backend.dart';
import '../../routing/app_page_route.dart';
import '../shared/zp_widgets.dart';
import '../profile/profile_screen.dart';
import '../gifts/gift_center_screen.dart';

/// ============================================================
/// Phase 5 — Part 2: Chat — شاشة المحادثة (Local/Mock فقط)
/// ============================================================
class ConversationScreen extends StatefulWidget {
  final ConversationPreview conversation;
  const ConversationScreen({super.key, required this.conversation});

  @override
  State<ConversationScreen> createState() => _ConversationScreenState();
}

class _ConversationScreenState extends State<ConversationScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  late List<MessageModel> _messages;
  bool _showEmojiBar = false;
  bool _isBlocked = false;
  bool _sending = false;

  static const _quickEmojis = ['😀', '😂', '❤️', '🔥', '👍', '😍', '🎉', '😢', '👏', '😮'];

  @override
  void initState() {
    super.initState();
    _messages = [];
    _loadLiveMessages();
    _isBlocked = widget.conversation.isBlocked;
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  Future<void> _loadLiveMessages() async {
    try {
      final rows = await ZupartyBackend.instance.loadDirectMessages(widget.conversation.id);
      final currentId = ZupartyBackend.instance.client.auth.currentUser?.id;
      if (!mounted) return;
      setState(() {
        _messages = rows.map((r) {
          final senderId = r['sender_id']?.toString() ?? '';
          final created = DateTime.tryParse(r['created_at']?.toString() ?? '') ?? DateTime.now();
          return MessageModel(
            id: r['id']?.toString() ?? created.microsecondsSinceEpoch.toString(),
            senderId: senderId,
            senderName: senderId == currentId ? 'أنا' : widget.conversation.name,
            text: r['text']?.toString() ?? '',
            time: created,
            isMe: senderId == currentId,
          );
        }).toList();
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    } catch (_) {
      if (mounted) setState(() => _messages = []);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (!_scrollController.hasClients) return;
    _scrollController.animateTo(_scrollController.position.maxScrollExtent + 80, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
  }

  void _addMessage(MessageModel m) {
    setState(() => _messages.add(m));
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  Future<void> _sendText() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _isBlocked) return;
    _controller.clear();
    setState(() => _sending = true);
    try {
      await ZupartyBackend.instance.sendDirectMessage(receiverId: widget.conversation.id, text: text);
      await _loadLiveMessages();
    } catch (e) {
      if (mounted) zpToast(context, 'تعذر إرسال الرسالة: $e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _sendEmoji(String emoji) {
    _addMessage(MessageModel(id: 'local_${DateTime.now().microsecondsSinceEpoch}', senderId: 'me', senderName: 'أنا', text: emoji, time: DateTime.now(), isMe: true, type: ChatMessageType.emoji));
  }

  void _sendMockImage() {
    _addMessage(MessageModel(id: 'local_${DateTime.now().microsecondsSinceEpoch}', senderId: 'me', senderName: 'أنا', text: '', time: DateTime.now(), isMe: true, type: ChatMessageType.image, imagePath: 'assets/images/profile.png'));
    zpToast(context, 'تم إرسال الصورة');
  }

  void _sendMockVoice() {
    _addMessage(MessageModel(id: 'local_${DateTime.now().microsecondsSinceEpoch}', senderId: 'me', senderName: 'أنا', text: '', time: DateTime.now(), isMe: true, type: ChatMessageType.voice, voiceSeconds: 6 + DateTime.now().second % 20));
    zpToast(context, 'تم إرسال رسالة صوتية');
  }

  Future<void> _openGiftSheet() async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl))),
      builder: (_) => SendGiftSheet(receiverName: widget.conversation.name),
    );
    if (result != null) {
      final gift = result['gift'] as GiftModel;
      final qty = result['quantity'] as int;
      _addMessage(MessageModel(id: 'local_${DateTime.now().microsecondsSinceEpoch}', senderId: 'me', senderName: 'أنا', text: '', time: DateTime.now(), isMe: true, type: ChatMessageType.gift, gift: gift, giftQuantity: qty));
    }
  }

  void _openProfile() {
    Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(
      user: UserModel(id: widget.conversation.id, name: widget.conversation.name, avatarPath: widget.conversation.avatarPath, isVip: widget.conversation.isVip, level: 14),
    )));
  }

  Future<void> _onBlock() async {
    final ok = await zpConfirmSheet(
      context,
      title: _isBlocked ? 'إلغاء الحظر' : 'حظر ${widget.conversation.name}',
      message: _isBlocked ? 'غادي يقدر يبعث ليك رسائل من جديد.' : 'ما غاديش يقدر يبعث ليك رسائل بعد الحظر.',
      confirmLabel: _isBlocked ? 'إلغاء الحظر' : 'حظر',
      icon: Icons.block_rounded,
    );
    if (!ok) return;
    setState(() {
      _isBlocked = !_isBlocked;
      widget.conversation.isBlocked = _isBlocked;
    });
    if (mounted) zpToast(context, _isBlocked ? 'تم حظر المستخدم' : 'تم إلغاء الحظر', icon: Icons.block_rounded, color: _isBlocked ? AppColors.danger : AppColors.success);
  }

  Future<void> _onReport() async {
    final ok = await zpConfirmSheet(
      context,
      title: 'إبلاغ عن ${widget.conversation.name}',
      message: 'سيتم مراجعة هاد المحادثة من طرف فريق Zuparty.',
      confirmLabel: 'إرسال الإبلاغ',
      icon: Icons.flag_outlined,
      color: AppColors.warning,
    );
    if (ok && mounted) zpToast(context, 'تم إرسال الإبلاغ، شكرًا ليك', icon: Icons.flag_outlined, color: AppColors.warning);
  }

  Future<void> _onDelete() async {
    final ok = await zpConfirmSheet(
      context,
      title: 'حذف المحادثة',
      message: 'غادي يتحذف سجل المحادثة كاملة من عندك.',
      confirmLabel: 'حذف',
      icon: Icons.delete_outline_rounded,
    );
    if (ok && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        titleSpacing: 0,
        title: GestureDetector(
          onTap: _openProfile,
          child: Row(
            children: [
              ZpAvatar(imagePath: widget.conversation.avatarPath, size: 36, showOnlineDot: widget.conversation.isOnline, showVipRing: widget.conversation.isVip),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(widget.conversation.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5), overflow: TextOverflow.ellipsis),
                    Text(widget.conversation.isOnline ? 'متصل الآن' : 'غير متصل', style: TextStyle(fontSize: 10.5, color: widget.conversation.isOnline ? AppColors.success : AppColors.grey500)),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded, color: AppColors.textPrimary),
            onSelected: (v) {
              if (v == 'profile') _openProfile();
              if (v == 'block') _onBlock();
              if (v == 'report') _onReport();
              if (v == 'delete') _onDelete();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'profile', child: Row(children: [Icon(Icons.person_outline_rounded, size: 18), SizedBox(width: 8), Text('عرض البروفيل')])),
              PopupMenuItem(value: 'block', child: Row(children: [const Icon(Icons.block_rounded, size: 18), const SizedBox(width: 8), Text(_isBlocked ? 'إلغاء الحظر' : 'حظر')])),
              const PopupMenuItem(value: 'report', child: Row(children: [Icon(Icons.flag_outlined, size: 18), SizedBox(width: 8), Text('إبلاغ')])),
              const PopupMenuItem(value: 'delete', child: Row(children: [Icon(Icons.delete_outline_rounded, size: 18, color: AppColors.danger), SizedBox(width: 8), Text('حذف المحادثة', style: TextStyle(color: AppColors.danger))])),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          if (_isBlocked)
            Container(
              width: double.infinity,
              color: AppColors.danger.withOpacity(0.08),
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: const Text('هذا المستخدم محظور — ما تقدرش تبعث ليه رسائل', textAlign: TextAlign.center, style: TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600)),
            ),
          Expanded(
            child: _messages.isEmpty
                ? const AppEmptyStateWrapper()
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    itemCount: _messages.length,
                    itemBuilder: (context, i) => _MessageBubble(message: _messages[i]),
                  ),
          ),
          if (_showEmojiBar)
            Container(
              height: 52,
              color: Colors.white,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                itemCount: _quickEmojis.length,
                separatorBuilder: (_, __) => const SizedBox(width: 14),
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () => _sendEmoji(_quickEmojis[i]),
                  child: Center(child: Text(_quickEmojis[i], style: const TextStyle(fontSize: 24))),
                ),
              ),
            ),
          SafeArea(top: false, child: _buildInputBar()),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
      child: Row(
        children: [
          IconButton(
            onPressed: _isBlocked ? null : () => setState(() => _showEmojiBar = !_showEmojiBar),
            icon: Icon(Icons.emoji_emotions_outlined, color: _showEmojiBar ? AppColors.primary : AppColors.grey600),
          ),
          IconButton(onPressed: _isBlocked ? null : _sendMockImage, icon: const Icon(Icons.image_outlined, color: AppColors.grey600)),
          IconButton(onPressed: _isBlocked ? null : _sendMockVoice, icon: const Icon(Icons.mic_none_rounded, color: AppColors.grey600)),
          IconButton(onPressed: _isBlocked ? null : _openGiftSheet, icon: const Icon(Icons.card_giftcard_rounded, color: AppColors.primary)),
          Expanded(
            child: TextField(
              controller: _controller,
              enabled: !_isBlocked,
              textAlign: TextAlign.right,
              onTap: () => setState(() => _showEmojiBar = false),
              decoration: InputDecoration(
                hintText: _isBlocked ? 'مستخدم محظور' : 'اكتب رسالة...',
                filled: true,
                fillColor: AppColors.surface,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppRadius.pill), borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(width: 6),
          CircleAvatar(
            radius: 20,
            backgroundColor: _isBlocked ? AppColors.grey300 : AppColors.primary,
            child: _sending
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : IconButton(
                    onPressed: _isBlocked ? null : _sendText,
                    icon: const Icon(Icons.send_rounded, size: 18, color: Colors.white),
                  ),
          ),
        ],
      ),
    );
  }
}

class AppEmptyStateWrapper extends StatelessWidget {
  const AppEmptyStateWrapper({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('ابدأ المحادثة الآن 👋', style: TextStyle(color: AppColors.textSecondary)));
  }
}

class _MessageBubble extends StatelessWidget {
  final MessageModel message;
  const _MessageBubble({required this.message});

  String _formatTime(DateTime t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final isMe = message.isMe;
    final bubbleColor = isMe ? AppColors.primary : Colors.white;
    final textColor = isMe ? Colors.white : AppColors.textPrimary;

    Widget content;
    switch (message.type) {
      case ChatMessageType.image:
        content = ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.md),
          child: Image.asset(message.imagePath ?? 'assets/images/profile.png', width: 160, height: 160, fit: BoxFit.cover),
        );
        break;
      case ChatMessageType.voice:
        content = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.play_arrow_rounded, color: textColor),
            const SizedBox(width: 6),
            SizedBox(
              width: 90,
              child: Row(children: List.generate(14, (i) => Expanded(child: Container(margin: const EdgeInsets.symmetric(horizontal: 1), height: 6 + (i % 4) * 4.0, color: textColor.withOpacity(0.6))))),
            ),
            const SizedBox(width: 6),
            Text('0:${message.voiceSeconds.toString().padLeft(2, '0')}', style: TextStyle(color: textColor, fontSize: 11)),
          ],
        );
        break;
      case ChatMessageType.gift:
        content = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(message.gift?.emoji ?? '🎁', style: const TextStyle(fontSize: 28)),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('هدية: ${message.gift?.name ?? ''}', style: TextStyle(color: textColor, fontWeight: FontWeight.w800, fontSize: 13)),
                Text('x${message.giftQuantity}', style: TextStyle(color: textColor.withOpacity(0.85), fontSize: 11)),
              ],
            ),
          ],
        );
        break;
      case ChatMessageType.emoji:
        content = Text(message.text, style: const TextStyle(fontSize: 32));
        break;
      case ChatMessageType.text:
        content = Text(message.text, style: TextStyle(color: textColor, fontSize: 14, height: 1.35));
        break;
    }

    final isPlainEmoji = message.type == ChatMessageType.emoji;

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        constraints: const BoxConstraints(maxWidth: 260),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: isPlainEmoji ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
              decoration: isPlainEmoji
                  ? null
                  : BoxDecoration(
                      color: message.type == ChatMessageType.gift ? (isMe ? AppColors.primaryDark : const Color(0xFFFFF3E0)) : bubbleColor,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(16),
                        topRight: const Radius.circular(16),
                        bottomLeft: Radius.circular(isMe ? 16 : 4),
                        bottomRight: Radius.circular(isMe ? 4 : 16),
                      ),
                      boxShadow: isMe ? null : AppShadows.card,
                    ),
              child: content,
            ),
            const SizedBox(height: 3),
            Text(_formatTime(message.time), style: const TextStyle(fontSize: 9.5, color: AppColors.grey500)),
          ],
        ),
      ),
    );
  }
}
