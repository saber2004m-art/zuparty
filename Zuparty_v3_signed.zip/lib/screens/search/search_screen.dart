import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../routing/app_page_route.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import '../profile/profile_screen.dart';
import '../rooms/room_details_screen.dart';
import '../../services/zuparty_backend.dart';

/// ============================================================
/// Phase 5 — Part 3/3: شاشة البحث الكاملة (Search Center)
/// مستخدمون / غرف / ألعاب / معرّفات — Local Mock Data فقط.
/// عمليات بحث سابقة + نتائج فارغة.
/// ============================================================
class SearchScreen extends StatefulWidget {
  final Future<void> Function(RoomModel room)? onOpenRoom;
  final void Function(GameModel game)? onOpenGame;
  const SearchScreen({super.key, this.onOpenRoom, this.onOpenGame});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final _controller = TextEditingController();
  String _query = '';
  List<RoomModel> _serverRooms = [];
  List<String> _recent = [];

  static const _tabs = ['search_users', 'search_rooms', 'search_games', 'search_ids'];

  List<UserModel> _serverUsers = [];

  List<UserModel> get _allUsers => _serverUsers;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    _loadRooms();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadRooms() async { try { final rows = await ZupartyBackend.instance.listRooms(); if (!mounted) return; setState(() { _serverRooms = rows.map((r) => RoomModel(id:r['id']?.toString(), ownerId:r['owner_id']?.toString(), name:r['name']?.toString() ?? 'Room', roomCode:r['room_code']?.toString(), imagePath:r['image_path']?.toString(), category:r['category']?.toString(), description:r['description']?.toString() ?? '', ownerName:r['owner_name']?.toString(), ownerAvatarPath:r['owner_avatar']?.toString() ?? 'assets/images/profile.png')).toList(); }); } catch (_) {} }

  Future<void> _submitSearch(String value) async {
    final v = value.trim();
    if (v.isEmpty) return;
    setState(() {
      _query = v;
      _recent.remove(v);
      _recent.insert(0, v);
      if (_recent.length > 8) _recent = _recent.sublist(0, 8);
    });
    try {
      final rows = await ZupartyBackend.instance.searchProfiles(v);
      if (!mounted) return;
      setState(() {
        _serverUsers = rows.map((r) => UserModel(
          id: r['id']?.toString() ?? '',
          name: r['display_name']?.toString() ?? 'مستخدم Zuparty',
          avatarPath: r['avatar_url']?.toString(),
          gender: r['gender']?.toString(),
          level: (r['level'] as num?)?.toInt() ?? 1,
          isVip: DateTime.tryParse(r['vip_until']?.toString() ?? '')?.isAfter(DateTime.now()) ?? false,
        )).toList();
      });
    } catch (_) {
      if (mounted) setState(() => _serverUsers = []);
    }
  }

  void _clearRecent() => setState(() => _recent.clear());

  List<UserModel> get _userResults {
    final q = _query.toLowerCase();
    return _allUsers.where((u) => u.name.toLowerCase().contains(q)).toList();
  }

  List<RoomModel> get _roomResults {
    final q = _query.toLowerCase();
    return _serverRooms.where((r) => r.name.toLowerCase().contains(q) || (r.roomCode?.toLowerCase().contains(q) ?? false)).toList();
  }

  List<GameModel> get _gameResults => const <GameModel>[];

  List<_IdResult> get _idResults {
    final q = _query.toLowerCase();
    final results = <_IdResult>[];
    for (final u in _allUsers) {
      if (u.id.toLowerCase().contains(q)) results.add(_IdResult.user(u));
    }
    for (final r in _serverRooms) {
      if ((r.roomCode ?? '').toLowerCase().contains(q)) results.add(_IdResult.room(r));
    }
    return results;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        titleSpacing: 0,
        title: _buildSearchBar(),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.grey500,
          indicatorColor: AppColors.primary,
          labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          tabs: _tabs.map((k) => Tab(text: S.tr(k))).toList(),
        ),
      ),
      body: _query.isEmpty
          ? _recentSearchesView()
          : TabBarView(
              controller: _tabController,
              children: [
                _usersResultsView(),
                _roomsResultsView(),
                _gamesResultsView(),
                _idsResultsView(),
              ],
            ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 8),
      child: Row(
        children: [
          IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18), onPressed: () => Navigator.pop(context)),
          Expanded(
            child: Container(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(AppRadius.pill)),
              child: TextField(
                controller: _controller,
                autofocus: true,
                textInputAction: TextInputAction.search,
                onSubmitted: _submitSearch,
                decoration: InputDecoration(
                  isCollapsed: true,
                  border: InputBorder.none,
                  hintText: S.tr('search_hint'),
                  hintStyle: AppTextStyles.caption,
                  prefixIcon: const Icon(Icons.search, size: 19, color: AppColors.grey500),
                  prefixIconConstraints: const BoxConstraints(minWidth: 32),
                  suffixIcon: _controller.text.isEmpty
                      ? null
                      : GestureDetector(
                          onTap: () => setState(() {
                            _controller.clear();
                            _query = '';
                          }),
                          child: const Icon(Icons.close_rounded, size: 17, color: AppColors.grey500),
                        ),
                ),
                onChanged: (v) => setState(() {}),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _recentSearchesView() {
    if (_recent.isEmpty) {
      return AppEmptyState(icon: Icons.history_rounded, title: S.tr('search_recent'));
    }
    return ListView(
      padding: const EdgeInsets.all(AppSpacing.lg),
      children: [
        Row(
          children: [
            Text(S.tr('search_recent'), style: AppTextStyles.h3),
            const Spacer(),
            GestureDetector(
              onTap: _clearRecent,
              child: Text(S.tr('search_clear'), style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 12.5)),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _recent
              .map((s) => GestureDetector(
                    onTap: () {
                      _controller.text = s;
                      _submitSearch(s);
                    },
                    child: ZpPill(label: s, color: AppColors.surface, icon: Icons.history_rounded),
                  ))
              .toList(),
        ),
      ],
    );
  }

  Widget _emptyResults() => AppEmptyState(icon: Icons.search_off_rounded, title: S.tr('search_empty'));

  Widget _usersResultsView() {
    final results = _userResults;
    if (results.isEmpty) return _emptyResults();
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: results.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final u = results[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: ZpAvatar(imagePath: u.avatarPath, size: 46, showVipRing: u.isVip, showOnlineDot: u.isOnline),
          title: Text(u.name, style: AppTextStyles.bodyBold),
          subtitle: Row(mainAxisSize: MainAxisSize.min, children: [
            Text('ID: ${u.id}', style: AppTextStyles.caption),
            const SizedBox(width: 6),
            ZpLevelBadge(level: u.level, height: 14),
          ]),
          onTap: () => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: u))),
        );
      },
    );
  }

  Widget _roomsResultsView() {
    final results = _roomResults;
    if (results.isEmpty) return _emptyResults();
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: results.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final r = results[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.sm),
            child: r.imagePath != null
                ? Image.asset(r.imagePath!, width: 46, height: 46, fit: BoxFit.cover)
                : Container(width: 46, height: 46, color: AppColors.grey100, child: const Icon(Icons.meeting_room_outlined, color: AppColors.grey500)),
          ),
          title: Text(r.name, style: AppTextStyles.bodyBold),
          subtitle: Text('${r.onlineCount} متصل الآن${r.roomCode != null ? ' — ${r.roomCode}' : ''}', style: AppTextStyles.caption),
          onTap: () => Navigator.push(
            context,
            appPageRoute(builder: (_) => RoomDetailsScreen(room: r, onOpenRoom: widget.onOpenRoom ?? (_) async {})),
          ),
        );
      },
    );
  }

  Widget _gamesResultsView() {
    final results = _gameResults;
    if (results.isEmpty) return _emptyResults();
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: results.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final g = results[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(color: g.color.withOpacity(0.15), borderRadius: BorderRadius.circular(AppRadius.sm)),
            child: Center(child: Text(g.emoji, style: const TextStyle(fontSize: 22))),
          ),
          title: Text(g.name, style: AppTextStyles.bodyBold),
          subtitle: Text(g.isPlayable ? '${g.players} لاعب الآن' : S.tr('events_locked'), style: AppTextStyles.caption),
          onTap: () {
            if (widget.onOpenGame != null) {
              widget.onOpenGame!(g);
            } else {
              zpToast(context, S.tr('coming_soon'), icon: Icons.info_outline_rounded, color: AppColors.info);
            }
          },
        );
      },
    );
  }

  Widget _idsResultsView() {
    final results = _idResults;
    if (results.isEmpty) return _emptyResults();
    return ListView.separated(
      padding: const EdgeInsets.all(AppSpacing.lg),
      itemCount: results.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
      itemBuilder: (context, i) {
        final entry = results[i];
        if (entry.user != null) {
          final u = entry.user!;
          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: ZpAvatar(imagePath: u.avatarPath, size: 46),
            title: Text(u.name, style: AppTextStyles.bodyBold),
            subtitle: Text('ID: ${u.id}', style: AppTextStyles.caption),
            onTap: () => Navigator.push(context, appPageRoute(builder: (_) => ProfileScreen(user: u))),
          );
        }
        final r = entry.room!;
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const CircleAvatar(backgroundColor: AppColors.surface, child: Icon(Icons.meeting_room_outlined, color: AppColors.grey600, size: 19)),
          title: Text(r.name, style: AppTextStyles.bodyBold),
          subtitle: Text('ID: ${r.roomCode}', style: AppTextStyles.caption),
          onTap: () => Navigator.push(
            context,
            appPageRoute(builder: (_) => RoomDetailsScreen(room: r, onOpenRoom: widget.onOpenRoom ?? (_) async {})),
          ),
        );
      },
    );
  }
}

class _IdResult {
  final UserModel? user;
  final RoomModel? room;
  _IdResult.user(this.user) : room = null;
  _IdResult.room(this.room) : user = null;
}
