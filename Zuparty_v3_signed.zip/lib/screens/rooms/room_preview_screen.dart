import 'package:flutter/material.dart';
import '../../data/models.dart';
import '../../theme/app_theme.dart';
import '../../l10n/app_strings.dart';
import 'room_shared_widgets.dart';

/// ============================================================
/// شاشة "معاينة الغرفة" (Room Preview) — Phase 3 Part 2
/// معاينة سريعة قبل الدخول الفعلي للروم: غلاف كبير، معلومات
/// الروم وصاحبه، معاينة المتصلين، وزر "دخول الروم" الذي يفتح
/// LiveRoomScreen الموجودة فعليًا عبر onOpenRoom (بلا أي تعديل
/// فمنطق الروم الصوتي نفسه).
/// ============================================================
class RoomPreviewScreen extends StatefulWidget {
  final RoomModel room;
  final void Function(RoomModel room) onOpenRoom;

  const RoomPreviewScreen({super.key, required this.room, required this.onOpenRoom});

  @override
  State<RoomPreviewScreen> createState() => _RoomPreviewScreenState();
}

class _RoomPreviewScreenState extends State<RoomPreviewScreen> {
  // "متابعة/مفضلة" محلية بحتة (Session فقط) — الموديل الحالي ما كيدعمهاش
  // بشكل دائم، فهاد الحالة كتبقى UI-only كيما مطلوب فالمواصفات.
  bool _isFavorite = false;

  @override
  Widget build(BuildContext context) {
    final room = widget.room;
    final onlinePreview = <UserModel>[];

    return Scaffold(
      backgroundColor: AppColors.surface,
      body: Stack(
        children: [
          // الغلاف الكبير
          SizedBox(
            height: 320,
            width: double.infinity,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  room.imagePath ?? 'assets/images/room_bg_official.webp',
                  fit: BoxFit.cover,
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.15), Colors.black.withOpacity(0.75)],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // زر رجوع + مفضلة أعلى الغلاف
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
              child: Row(
                children: [
                  _RoundIconButton(icon: Icons.arrow_forward, onTap: () => Navigator.pop(context)),
                  const Spacer(),
                  _RoundIconButton(
                    icon: _isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: _isFavorite ? AppColors.primary : Colors.white,
                    onTap: () {
                      setState(() => _isFavorite = !_isFavorite);
                      showRoomMockFeedback(
                        context,
                        _isFavorite ? S.tr('room_preview_favorite_added') : S.tr('room_preview_favorite_removed'),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),

          // المحتوى القابل للتمرير
          DraggableScrollableSheet(
            initialChildSize: 0.62,
            minChildSize: 0.62,
            maxChildSize: 0.92,
            builder: (context, scrollController) {
              return Container(
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
                ),
                child: ListView(
                  controller: scrollController,
                  padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.lg, AppSpacing.xxl),
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(color: AppColors.grey300, borderRadius: BorderRadius.circular(4)),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),

                    Row(
                      children: [
                        Expanded(
                          child: Text(room.name, style: AppTextStyles.h2, maxLines: 2, overflow: TextOverflow.ellipsis),
                        ),
                        if (room.isRoomLocked) ...[
                          const SizedBox(width: 6),
                          const Icon(Icons.lock_outline, size: 18, color: AppColors.grey500),
                        ],
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text('ID: ${room.roomCode ?? room.id ?? '—'}', style: AppTextStyles.caption),
                    const SizedBox(height: AppSpacing.sm),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        if (room.category != null)
                          RoomTagChip(icon: Icons.category_outlined, label: room.category!),
                        RoomTagChip(
                          icon: Icons.people_alt_outlined,
                          label: S.trParams('room_online_count_template', {'count': '${room.onlineCount}'}),
                          background: AppColors.primaryLight,
                          foreground: AppColors.primary,
                        ),
                        RoomTagChip(
                          icon: room.isRoomLocked ? Icons.lock_outline : Icons.public,
                          label: room.isRoomLocked ? S.tr('room_details_tag_private') : S.tr('room_details_tag_public'),
                        ),
                      ],
                    ),

                    const SizedBox(height: AppSpacing.lg),

                    // صاحب الروم
                    RoomInfoSection(
                      title: S.tr('room_owner_title'),
                      child: Row(
                        children: [
                          RoomAvatarCircle(
                            imagePath: room.ownerAvatarPath ?? 'assets/images/profile.png',
                            fallbackText: room.ownerName ?? '?',
                            size: 44,
                            borderColor: AppColors.border,
                          ),
                          const SizedBox(width: AppSpacing.md),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(room.ownerName ?? S.tr('unknown_owner'), style: AppTextStyles.bodyBold),
                                const SizedBox(height: 2),
                                Text(S.tr('room_owner_label'), style: AppTextStyles.caption),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: AppSpacing.md),

                    // معاينة المتصلين
                    RoomInfoSection(
                      title: S.tr('home_section_online_now'),
                      child: Row(
                        children: [
                          SizedBox(
                            height: 40,
                            child: Stack(
                              children: List.generate(onlinePreview.length, (i) {
                                return Positioned(
                                  right: i * 26.0,
                                  child: RoomAvatarCircle(
                                    imagePath: onlinePreview[i].avatarPath,
                                    fallbackText: onlinePreview[i].name,
                                    size: 34,
                                  ),
                                );
                              }),
                            ),
                          ),
                          SizedBox(width: onlinePreview.length * 26.0 + 8),
                          Expanded(
                            child: Text(
                              S.trParams('room_preview_people_here_template', {'count': '${room.onlineCount}'}),
                              style: AppTextStyles.caption,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),

                    if (room.announcement.trim().isNotEmpty) ...[
                      const SizedBox(height: AppSpacing.md),
                      RoomInfoSection(
                        title: S.tr('room_announcement_title'),
                        child: Text(room.announcement, style: AppTextStyles.body),
                      ),
                    ],

                    const SizedBox(height: AppSpacing.md),

                    // أزرار مشاركة / دعوة
                    RoomInfoSection(
                      title: S.tr('room_preview_share_title'),
                      child: Row(
                        children: [
                          Expanded(
                            child: RoomActionButton(
                              icon: Icons.share_outlined,
                              label: S.tr('share'),
                              onTap: () => showRoomMockFeedback(context, S.tr('copy_room_link_toast')),
                            ),
                          ),
                          const SizedBox(width: AppSpacing.sm),
                          Expanded(
                            child: RoomActionButton(
                              icon: Icons.person_add_alt_1_outlined,
                              label: S.tr('invite'),
                              onTap: () => showRoomMockFeedback(context, S.tr('invite_sent_toast')),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: AppSpacing.xxl + AppSpacing.lg),
                  ],
                ),
              );
            },
          ),

          // زر "دخول الروم" ثابت فالأسفل
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.sm, AppSpacing.lg, AppSpacing.md),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 12, offset: const Offset(0, -3))],
                ),
                child: SizedBox(
                  height: 50,
                  child: ElevatedButton.icon(
                    onPressed: () => showJoinRoomFlow(context, room: room, onOpenRoom: widget.onOpenRoom),
                    icon: const Icon(Icons.login_rounded, size: 20),
                    label: Text(S.tr('room_preview_enter_button')),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  const _RoundIconButton({required this.icon, required this.onTap, this.color = Colors.white});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withOpacity(0.35),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(9),
          child: Icon(icon, color: color, size: 20),
        ),
      ),
    );
  }
}
