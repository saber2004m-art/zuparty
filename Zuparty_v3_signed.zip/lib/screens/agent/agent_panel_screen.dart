import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../services/zuparty_backend.dart';

class AgentPanelScreen extends StatefulWidget {
  const AgentPanelScreen({super.key});
  @override
  State<AgentPanelScreen> createState() => _AgentPanelScreenState();
}

class _AgentPanelScreenState extends State<AgentPanelScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) { if (mounted) setState(() => _loading = false); },
        onWebResourceError: (e) { if (mounted) setState(() { _loading = false; _error = e.description; }); },
      ));
    _load();
  }

  Future<void> _load() async {
    try {
      final role = await ZupartyBackend.instance.getMyStaffRole();
      final isAllowed = role['status'] == 'active' && (role['role'] == 'admin' || (role['role'] == 'agent' && role['shipping_agency'] == true));
      if (!isAllowed) throw StateError('ليس لديك صلاحية لوحة الشحن');
      await _controller.loadRequest(Uri.parse(ZupartyBackend.instance.agentPanelUrl()));
    } catch (e) {
      if (mounted) setState(() { _loading = false; _error = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('لوحة شحن Zuparty'), centerTitle: true),
    body: Stack(children: [
      WebViewWidget(controller: _controller),
      if (_loading) const Center(child: CircularProgressIndicator()),
      if (_error != null) Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center))),
    ]),
  );
}
