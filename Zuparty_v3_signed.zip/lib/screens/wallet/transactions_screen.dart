import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import 'wallet_screen.dart';

class TransactionsScreen extends StatefulWidget {
  final List<WalletTransaction>? serverTransactions;
  const TransactionsScreen({super.key, this.serverTransactions});
  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  String _filter = 'الكل';
  static const _filters = ['الكل', 'شحن', 'هدايا', 'ألعاب', 'VIP'];
  List<WalletTransaction> get _all => widget.serverTransactions ?? const [];
  List<WalletTransaction> get _filtered {
    switch (_filter) {
      case 'شحن': return _all.where((t) => t.type == WalletTxType.recharge).toList();
      case 'هدايا': return _all.where((t) => t.type == WalletTxType.giftSent || t.type == WalletTxType.giftReceived).toList();
      case 'ألعاب': return _all.where((t) => t.type == WalletTxType.gameWin || t.type == WalletTxType.gameLoss).toList();
      case 'VIP': return _all.where((t) => t.type == WalletTxType.vipSub).toList();
      default: return _all;
    }
  }
  @override
  Widget build(BuildContext context) {
    final items = _filtered;
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(backgroundColor: Colors.white, elevation: 0, centerTitle: true, title: const Text('سجل المعاملات', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
      body: Column(children: [
        SizedBox(height: 44, child: ListView.separated(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.sm), itemCount: _filters.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) { final selected = _filters[i] == _filter; return GestureDetector(onTap: () => setState(() => _filter = _filters[i]), child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7), decoration: BoxDecoration(color: selected ? AppColors.primary : Colors.white, borderRadius: BorderRadius.circular(AppRadius.pill), boxShadow: AppShadows.card), child: Text(_filters[i], style: TextStyle(color: selected ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.w700, fontSize: 12)))); })),
        Expanded(child: items.isEmpty ? const AppEmptyState(icon: Icons.receipt_long_outlined, title: 'ما كايناش معاملات فهاد التصنيف') : ListView.builder(padding: const EdgeInsets.all(AppSpacing.lg), itemCount: items.length, itemBuilder: (_, i) => TxTile(tx: items[i]))),
      ]),
    );
  }
}
