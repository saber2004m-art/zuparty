import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_states.dart';
import '../../data/models.dart';
import '../../routing/app_page_route.dart';
import '../../services/zuparty_backend.dart';
import '../../l10n/app_strings.dart';
import '../shared/zp_widgets.dart';
import 'transactions_screen.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool _loading = true;
  int _balance = 0;
  bool _shippingAgent = false;
  bool _isAdmin = false;
  List<WalletTransaction> _transactions = [];

  @override
  void initState() {
    super.initState();
    _loadWallet();
  }

  Future<void> _loadWallet() async {
    try {
      final profile = await ZupartyBackend.instance.getWalletProfile();
      final rows = await ZupartyBackend.instance.getWalletTransactions();
      final staff = await ZupartyBackend.instance.getMyStaffRole();
      final shipping = staff['status'] == 'active' && staff['shipping_agency'] == true;
      final admin = staff['status'] == 'active' && staff['role'] == 'admin';
      final balance = (profile['coins'] as num?)?.toInt() ?? 0;
      final txs = rows.map(_txFromRow).toList();
      if (mounted) {
        setState(() {
          _balance = balance;
          _transactions = txs;
          _shippingAgent = shipping;
          _isAdmin = admin;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  WalletTransaction _txFromRow(Map<String, dynamic> row) {
    final type = switch (row['type']?.toString()) {
      'recharge' => WalletTxType.recharge,
      'game_win' => WalletTxType.gameWin,
      'game_bet' => WalletTxType.gameLoss,
      'gift_sent' => WalletTxType.giftSent,
      'gift_received' => WalletTxType.giftReceived,
      'vip_sub' => WalletTxType.vipSub,
      _ => WalletTxType.recharge,
    };
    final created = DateTime.tryParse(row['created_at']?.toString() ?? '') ?? DateTime.now();
    return WalletTransaction(
      id: row['id']?.toString() ?? created.microsecondsSinceEpoch.toString(),
      type: type,
      title: _titleFor(row['type']?.toString()),
      amount: (row['amount'] as num?)?.toInt() ?? 0,
      time: created.toLocal(),
    );
  }

  String _titleFor(String? type) {
    switch (type) {
      case 'game_win': return 'ربح لعبة';
      case 'game_bet': return 'لعب — خصم Coins';
      case 'recharge': return 'إعادة شحن';
      default: return type ?? 'معاملة';
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: zpAppBar('المحفظة', actions: [
        IconButton(
          icon: const Icon(Icons.receipt_long_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.push(context, appPageRoute(builder: (_) => TransactionsScreen(serverTransactions: _transactions))),
        ),
      ]),
      body: _loading
          ? const AppSkeletonList(itemCount: 6, itemHeight: 60)
          : RefreshIndicator(
              onRefresh: _loadWallet,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(AppSpacing.lg),
                children: [
                  _buildBalanceCard(),
                  const SizedBox(height: AppSpacing.md),
                  _buildRechargeAccessCard(),
                  const SizedBox(height: AppSpacing.xl),
                  ZpSectionHeader(title: 'آخر المعاملات', actionLabel: 'عرض الكل', onAction: () => Navigator.push(context, appPageRoute(builder: (_) => TransactionsScreen(serverTransactions: _transactions)))),
                  ..._buildRecentTx(),
                ],
              ),
            ),
    );
  }


  Widget _buildRechargeAccessCard() => _shippingAgent
      ? Container(
          padding: const EdgeInsets.all(AppSpacing.lg),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
          child: Row(children: [
            Container(width: 44, height: 44, decoration: BoxDecoration(color: AppColors.primary.withOpacity(.1), shape: BoxShape.circle), child: const Icon(Icons.local_shipping_rounded, color: AppColors.primary)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('الشحن عبر وكيل شحن معتمد', style: TextStyle(fontWeight: FontWeight.w800)),
              SizedBox(height: 3),
              Text('هذه هي الطريقة الوحيدة للشحن. وكلاء الشحن المعتمدون فقط يمكنهم تنفيذ العملية.', style: TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
            ])),
            IconButton(onPressed: _openAgentRecharge, icon: const Icon(Icons.arrow_forward_ios_rounded, size: 17))
          ]),
        )
      : Container(
          padding: const EdgeInsets.all(AppSpacing.lg),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.lg), boxShadow: AppShadows.card),
          child: const Row(children: [
            Icon(Icons.lock_outline_rounded, color: AppColors.grey500),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('الشحن متاح عن طريق وكيل شحن فقط', style: TextStyle(fontWeight: FontWeight.w800)),
              SizedBox(height: 3),
              Text('طرق الدفع المباشر غير متاحة حالياً. سيتم توفيرها لاحقاً.', style: TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
            ])),
          ]),
        );

  Future<void> _openAgentRecharge() async {
    try {
      final users = await ZupartyBackend.instance.agentSearchUsers('');
      if (!mounted) return;
      await showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.white, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))), builder: (_) => _AgentRechargeSheet(users: users));
      await _loadWallet();
    } catch (e) {
      if (mounted) zpToast(context, 'تعذر فتح شاشة الشحن: $e');
    }
  }

  Widget _buildBalanceCard() => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(AppSpacing.xl),
    decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl), boxShadow: AppShadows.card),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('رصيدك الحالي', style: TextStyle(color: Colors.white70, fontSize: 12.5)),
      const SizedBox(height: 6),
      Row(children: [
        Image.asset('assets/wallet/wallet_base_coin_ic.webp', width: 28, height: 28, errorBuilder: (_, __, ___) => const Icon(Icons.monetization_on_rounded, color: Colors.white, size: 28)),
        const SizedBox(width: 8),
        Text('$_balance', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 30)),
      ]),
      const SizedBox(height: 4),
      const Text('Coins — محفوظة على السيرفر', style: TextStyle(color: Colors.white70, fontSize: 12)),
    ]),
  );


  List<Widget> _buildRecentTx() {
    final tx = _transactions.take(4).toList();
    if (tx.isEmpty) return [const AppEmptyState(icon: Icons.receipt_long_outlined, title: 'لا توجد معاملات بعد')];
    return tx.map((t) => TxTile(tx: t)).toList();
  }
}


class _AgentRechargeSheet extends StatefulWidget {
  final List<Map<String,dynamic>> users;
  const _AgentRechargeSheet({required this.users});
  @override State<_AgentRechargeSheet> createState()=>_AgentRechargeSheetState();
}
class _AgentRechargeSheetState extends State<_AgentRechargeSheet>{
  String? _selected; final _coins=TextEditingController(text:'35000000'); final _note=TextEditingController(); bool _busy=false;
  @override void dispose(){_coins.dispose();_note.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>SafeArea(child: Padding(padding: EdgeInsets.only(left:20,right:20,top:16,bottom:MediaQuery.of(context).viewInsets.bottom+20),child: Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('شحن مستخدم — وكيل شحن',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)), const SizedBox(height:6), const Text('العملية تُسجل في السيرفر وتزيد محفظة المستخدم مباشرة.',style:TextStyle(color:AppColors.textSecondary,fontSize:12)), const SizedBox(height:14),
    DropdownButtonFormField<String>(value:_selected,items:widget.users.map((u)=>DropdownMenuItem(value:u['user_id'].toString(),child:Text(u['display_name']?.toString().isNotEmpty==true?u['display_name'].toString():u['user_id'].toString()))).toList(),onChanged:(v)=>setState(()=>_selected=v),decoration:const InputDecoration(labelText:'المستخدم')), const SizedBox(height:10),
    TextField(controller:_coins,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Coins')), const SizedBox(height:10),
    TextField(controller:_note,decoration:const InputDecoration(labelText:'ملاحظة (اختياري)')), const SizedBox(height:14),
    SizedBox(width:double.infinity,child:ElevatedButton(onPressed:_busy||_selected==null?null:_submit,child:_busy?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Text('تأكيد الشحن')))
  ])));
  Future<void> _submit() async { final n=int.tryParse(_coins.text.trim()); if(n==null||n<=0)return; setState(()=>_busy=true); try{await ZupartyBackend.instance.agentRechargeUser(userId:_selected!,coins:n,note:_note.text.trim()); if(mounted){Navigator.pop(context);zpToast(context,'تم الشحن وتسجيل العملية في السيرفر',icon:Icons.check_circle_rounded,color:AppColors.success);}}catch(e){if(mounted)zpToast(context,'تعذر الشحن: $e');}finally{if(mounted)setState(()=>_busy=false);}}
}

class TxTile extends StatelessWidget {
  final WalletTransaction tx;
  const TxTile({super.key, required this.tx});
  IconData get _icon => switch (tx.type) {
    WalletTxType.recharge => Icons.add_card_rounded,
    WalletTxType.giftSent => Icons.card_giftcard_rounded,
    WalletTxType.giftReceived => Icons.redeem_rounded,
    WalletTxType.gameWin => Icons.emoji_events_rounded,
    WalletTxType.gameLoss => Icons.sports_esports_rounded,
    WalletTxType.vipSub => Icons.workspace_premium_rounded,
  };
  @override
  Widget build(BuildContext context) {
    final positive = tx.amount >= 0;
    return Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(AppSpacing.md), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.md), boxShadow: AppShadows.card), child: Row(children: [
      Container(width: 40, height: 40, decoration: BoxDecoration(color: (positive ? AppColors.success : AppColors.danger).withOpacity(.1), shape: BoxShape.circle), child: Icon(_icon, size: 19, color: positive ? AppColors.success : AppColors.danger)),
      const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tx.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)), Text('${tx.time.day}/${tx.time.month} — ${tx.time.hour.toString().padLeft(2,'0')}:${tx.time.minute.toString().padLeft(2,'0')}', style: const TextStyle(fontSize: 10.5, color: AppColors.grey500))])),
      Text('${positive ? '+' : ''}${tx.amount}', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: positive ? AppColors.success : AppColors.danger)),
    ]));
  }
}
