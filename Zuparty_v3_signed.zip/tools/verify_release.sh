#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo '[1/5] Required project files'
test -f pubspec.yaml
test -f lib/services/zuparty_backend.dart
test -d supabase/migrations
test -d assets

echo '[2/5] Security / recharge checks'
grep -R "shipping_agent_required" supabase/migrations >/dev/null
grep -R "idempotency" supabase/migrations >/dev/null

echo '[3/5] Game ambiguity hardening'
grep -R "where gr.game_id = v_game_id\|where gr.game_id = p_game_id" supabase/migrations/20260831220000_runtime_hardening.sql >/dev/null

echo '[4/5] VIP / levels'
grep -R "between 1 and 13\|between 1 and 10" supabase/migrations >/dev/null
grep -R "account_xp\|account_level" supabase/migrations/20260831232000_account_levels_final.sql >/dev/null

echo '[5/5] Assets'
COUNT=$(find assets -type f | wc -l)
echo "Assets: $COUNT"
echo 'Static release checks: PASS'
