import 'dart:math';
import 'package:supabase_flutter/supabase_flutter.dart';

class ZupartyConfig {
  static const supabaseUrl = 'https://kwlcvnyznahfkyfvmymw.supabase.co';
  static const supabasePublishableKey = 'sb_publishable_pzWRXTsydWX_FoyWnF_Tmg_5VWO-vKd';
  static const agoraAppId = '9c9ae439ddc34fc383b97ccf34dacd5a';
}

class ZupartyBackend {
  ZupartyBackend._();
  static final instance = ZupartyBackend._();
  SupabaseClient get client => Supabase.instance.client;

  Future<void> ensureSignedIn() async {
    if (client.auth.currentSession != null && client.auth.currentUser != null) return;
    throw StateError('not_authenticated');
  }

  Future<AuthResponse> signUp({required String email, required String password, required String name, String? gender}) async {
    final response = await client.auth.signUp(email: email.trim(), password: password);
    if (response.user != null && response.session != null) {
      await ensureProfile(name: name, gender: gender);
    }
    return response;
  }

  Future<AuthResponse> signIn({required String email, required String password}) async {
    final response = await client.auth.signInWithPassword(email: email.trim(), password: password);
    if (response.session == null || response.user == null) throw StateError('login_failed');
    return response;
  }

  Future<void> signOut() => client.auth.signOut();

  Future<Map<String, dynamic>> updateMyProfile({String? name, String? gender, String? avatarUrl}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_update_my_profile', params: {
      'p_display_name': name,
      'p_gender': gender,
      'p_avatar_url': avatarUrl,
    });
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid profile response');
  }

  Future<List<Map<String,dynamic>>> getGiftCatalog() async {
    await ensureSignedIn();
    final rows = await client.from('zp_gifts').select('id,name,emoji,price').eq('enabled', true).order('price');
    return (rows as List).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> sendGift({required String receiverId, required String giftId, int quantity = 1, String? idempotencyKey}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_send_gift', params: {
      'p_receiver_id': receiverId,
      'p_gift_id': giftId,
      'p_quantity': quantity,
      'p_idempotency_key': idempotencyKey ?? 'gift-${DateTime.now().microsecondsSinceEpoch}-${receiverId.substring(0, 8)}',
    });
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid gift response');
  }

  Future<String> ensureProfile({required String name, String? gender}) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    await client.rpc('zp_update_my_profile', params: {
      'p_display_name': name.isEmpty ? 'مستخدم Zuparty' : name,
      'p_gender': gender,
      'p_avatar_url': null,
    });
    return uid;
  }


  /// Public user search for the production search screen.
  /// Only profile fields are exposed; auth credentials are never queried.
  Future<List<Map<String,dynamic>>> searchProfiles(String query) async {
    await ensureSignedIn();
    final q = query.trim();
    var req = client
        .from('zp_profiles')
        .select('id,display_name,avatar_url,gender,level,vip_until,updated_at')
        .order('updated_at', ascending: false)
        .limit(50);
    if (q.isNotEmpty) req = req.ilike('display_name', '%$q%');
    final rows = await req;
    return (rows as List).map((e) => Map<String,dynamic>.from(e as Map)).toList();
  }
  Future<List<Map<String,dynamic>>> agentSearchUsers(String query) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_agent_search_users', params: {'p_query': query});
    if (result is List) return result.map((e)=>Map<String,dynamic>.from(e as Map)).toList();
    return <Map<String,dynamic>>[];
  }

  Future<Map<String,dynamic>> agentRechargeUser({required String userId, required int coins, String note=''}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_agent_recharge_user', params: {'p_user_id': userId, 'p_coins': coins, 'p_note': note});
    if (result is List && result.isNotEmpty) return Map<String,dynamic>.from(result.first);
    if (result is Map) return Map<String,dynamic>.from(result);
    throw StateError('Invalid agent recharge response');
  }

  Future<List<Map<String, dynamic>>> loadDirectMessages(String otherUserId, {int limit = 100}) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    final rows = await client
        .from('zp_direct_messages')
        .select('id,sender_id,receiver_id,text,created_at,read_at')
        .or('and(sender_id.eq.$uid,receiver_id.eq.$otherUserId),and(sender_id.eq.$otherUserId,receiver_id.eq.$uid)')
        .order('created_at', ascending: true)
        .limit(limit);
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<String> sendDirectMessage({required String receiverId, required String text}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_send_direct_message', params: {
      'p_receiver_id': receiverId,
      'p_text': text,
    });
    return result.toString();
  }

  Future<Map<String, dynamic>> getMyStaffRole() async {
    await ensureSignedIn();
    final result = await client.rpc('zp_my_staff_role');
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    return <String, dynamic>{};
  }

  String agentPanelUrl() {
    final token = client.auth.currentSession?.accessToken;
    if (token == null || token.isEmpty) throw StateError('not_authenticated');
    return '${ZupartyConfig.supabaseUrl}/functions/v1/agent-panel?token=${Uri.encodeComponent(token)}';
  }

  Future<void> joinRoom(String roomId) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    await client.from('zp_room_members').upsert({'room_id': roomId, 'user_id': uid});
  }

  Future<void> leaveRoom(String roomId) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    await client.from('zp_room_members').delete().eq('room_id', roomId).eq('user_id', uid);
  }

  /// المقاعد المشغولة حاليًا فالغرفة (seat_index != null) مع بيانات صاحب كل مقعد.
  Future<List<Map<String, dynamic>>> loadRoomSeats(String roomId) async {
    await ensureSignedIn();
    final rows = await client
        .from('zp_room_members')
        .select('user_id,seat_index,mic_muted,role,zp_profiles(display_name,avatar_url)')
        .eq('room_id', roomId)
        .not('seat_index', 'is', null);
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// أخذ مقعد بشكل ذرّي (atomic) عبر RPC فالسيرفر — كيمنع Race Condition
  /// بين لاعبين يحاولو ياخدو نفس المقعد فنفس الوقت (zp_take_seat فقاعدة البيانات).
  Future<Map<String, dynamic>?> takeSeat({required String roomId, required int seatIndex}) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_take_seat', params: {
      'p_room_id': roomId,
      'p_seat_index': seatIndex,
    });
    if (result is Map) return Map<String, dynamic>.from(result);
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    return null;
  }

  /// مغادرة المقعد الحالي (بدون مغادرة الروم بالكامل).
  Future<void> leaveSeat({required String roomId}) async {
    await ensureSignedIn();
    await client.rpc('zp_leave_seat', params: {'p_room_id': roomId});
  }

  /// كتسجل حالة كتم المايك ديال المستخدم الحالي فهاد الروم فقاعدة البيانات،
  /// باش تنعكس عبر Realtime عند بقية الأعضاء (zp_room_members.mic_muted).
  Future<void> setMicMuted({required String roomId, required bool muted}) async {
    await ensureSignedIn();
    await client.rpc('zp_set_mic_muted', params: {
      'p_room_id': roomId,
      'p_muted': muted,
    });
  }

  /// كتسجل حالة كتم المايك ديال عضو آخر فنفس الروم — صاحب الروم فقط
  /// (zp_set_member_mic_muted كتتحقق owner_id = auth.uid() فالسيرفر، بلا أي
  /// صلاحية إضافية زيادة على اللي كاينة ديجا لباقي إعدادات الروم).
  Future<void> setMemberMicMuted({required String roomId, required String targetUserId, required bool muted}) async {
    await ensureSignedIn();
    await client.rpc('zp_set_member_mic_muted', params: {
      'p_room_id': roomId,
      'p_target_user_id': targetUserId,
      'p_muted': muted,
    });
  }

  /// كتسجل إعدادات الروم (الاسم، الوصف، من يقدر يتكلم/يدردش، هدايا الزوار،
  /// خاص/عام) فقاعدة البيانات. المالك فقط — الـ RPC كتتحقق owner_id = auth.uid().
  Future<Map<String, dynamic>> updateRoomSettings({
    required String roomId,
    required String name,
    required String description,
    required String whoCanSpeak,
    required String whoCanChat,
    required bool allowGuestGifts,
    required bool isPrivate,
  }) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_update_room_settings', params: {
      'p_room_id': roomId,
      'p_name': name,
      'p_description': description,
      'p_who_can_speak': whoCanSpeak,
      'p_who_can_chat': whoCanChat,
      'p_allow_guest_gifts': allowGuestGifts,
      'p_is_private': isPrivate,
    });
    if (result is Map) return Map<String, dynamic>.from(result);
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    throw StateError('Invalid room settings response');
  }

  /// قناة Realtime حقيقية على جدول zp_room_members مفلترة على غرفة معيّنة.
  /// كتنادي [onChange] عند أي INSERT/UPDATE/DELETE (جلوس/تغيير مقعد/مغادرة)
  /// من أي لاعب داخل نفس الغرفة. الـ caller مسؤول يدير subscribe()
  /// و removeChannel() عند dispose.
  RealtimeChannel roomSeatsChannel(String roomId, void Function() onChange) {
    final channel = client.channel('room_seats_$roomId');
    channel.onPostgresChanges(
      event: PostgresChangeEvent.all,
      schema: 'public',
      table: 'zp_room_members',
      filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'room_id', value: roomId),
      callback: (payload) => onChange(),
    );
    return channel;
  }

  /// كل الأعضاء الحاليين فالروم (فوق الكراسي أو لا) مع بروفايلهم — كتخدم مع
  /// [roomSeatsChannel] (نفس الجدول) باش تبقى اللائحة و"عدد الحاضرين" حقيقيين
  /// فالرومات الحقيقية، بدل ما يبقاو Mock.
  Future<List<Map<String, dynamic>>> loadRoomMembers(String roomId) async {
    await ensureSignedIn();
    final rows = await client
        .from('zp_room_members')
        .select('user_id,seat_index,mic_muted,role,joined_at,zp_profiles(display_name,avatar_url)')
        .eq('room_id', roomId)
        .order('joined_at', ascending: true);
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> listRooms() async {
    await ensureSignedIn();
    final raw = await client.from('zp_rooms').select().order('created_at', ascending: false).limit(100);
    final rooms = (raw as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final ownerIds = rooms.map((r) => r['owner_id']?.toString()).whereType<String>().toSet().toList();
    if (ownerIds.isNotEmpty) {
      final profiles = await client.from('zp_profiles').select('id,display_name,avatar_url').inFilter('id', ownerIds);
      final byId = <String, Map<String,dynamic>>{};
      for (final p in profiles as List) { final m=Map<String,dynamic>.from(p as Map); byId[m['id'].toString()]=m; }
      for (final r in rooms) { final o=byId[r['owner_id']?.toString()]; if(o!=null){ r['owner_name']=o['display_name']; r['owner_avatar']=o['avatar_url']; } }
    }
    return rooms;
  }

  Future<Map<String, dynamic>> createRoom({
    required String name,
    required String roomCode,
    required String? imagePath,
    required String? category,
    required String description,
    required String announcement,
    required bool isPrivate,
    required int effectIndex,
  }) async {
    await ensureSignedIn();
    final row = await client.from('zp_rooms').insert({
      'room_code': roomCode,
      'name': name,
      'image_path': imagePath,
      'category': category,
      'description': description,
      'announcement': announcement,
      'is_private': isPrivate,
      'effect_index': effectIndex,
      'owner_id': client.auth.currentUser!.id,
    }).select().single();
    return Map<String, dynamic>.from(row);
  }

  Future<Map<String, dynamic>> getOrCreateGameRound(String gameId) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_get_or_create_game_round', params: {'p_game_id': gameId});
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Unable to create game round');
  }

  Future<Map<String, dynamic>> placeGameBet({
    required String gameId, required String roundId, required String choice, required int amount,
  }) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_place_game_bet', params: {
      'p_game_id': gameId,
      'p_round_id': roundId,
      'p_choice': choice,
      'p_amount': amount,
    });
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid game bet response');
  }

  Future<Map<String, dynamic>> resolveGameRound(String roundId) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_resolve_game_round', params: {'p_round_id': roundId});
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid game resolve response');
  }

  Future<Map<String, dynamic>> getVipStatus() async {
    await ensureSignedIn();
    final result = await client.rpc('zp_get_vip_status');
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid VIP response');
  }

  Future<Map<String, dynamic>> subscribeVip(int level) async {
    await ensureSignedIn();
    final result = await client.rpc('zp_subscribe_vip', params: {'p_level': level});
    if (result is Map) return Map<String, dynamic>.from(result);
    if (result is List && result.isNotEmpty) return Map<String, dynamic>.from(result.first);
    throw StateError('Invalid VIP subscription response');
  }

  Future<List<Map<String, dynamic>>> getMyRewards() async {
    await ensureSignedIn();
    final rows = await client.rpc('zp_my_rewards');
    if (rows is List) return rows.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    return <Map<String, dynamic>>[];
  }

  Future<Map<String, dynamic>> getAccountProgress() async {
    await ensureSignedIn();
    final result = await client.rpc('zp_get_account_progress');
    if (result is Map) return Map<String, dynamic>.from(result);
    throw StateError('Invalid account progress response');
  }

  Future<Map<String, dynamic>> getMyProfile() async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    final row = await client.from('zp_profiles').select('id,display_name,gender,avatar_url,coins').eq('id', uid).single();
    return Map<String, dynamic>.from(row);
  }

  Future<String> uploadMyAvatarBytes(List<int> bytes, {String extension = 'jpg'}) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    final safeExt = extension.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    final ext = safeExt.isEmpty ? 'jpg' : safeExt;
    final path = '$uid/avatar_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await client.storage.from('avatars').uploadBinary(
      path,
      bytes,
      fileOptions: FileOptions(contentType: 'image/$ext', upsert: true),
    );
    final url = client.storage.from('avatars').getPublicUrl(path);
    await updateMyProfile(avatarUrl: url);
    return url;
  }

  Future<Map<String, dynamic>> getWalletProfile() async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    final row = await client.from('zp_profiles').select('coins').eq('id', uid).single();
    return Map<String, dynamic>.from(row);
  }

  Future<List<Map<String, dynamic>>> getWalletTransactions({int limit = 50}) async {
    await ensureSignedIn();
    final uid = client.auth.currentUser!.id;
    final rows = await client.from('zp_wallet_transactions').select().eq('user_id', uid).order('created_at', ascending: false).limit(limit);
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }


  Future<List<Map<String, dynamic>>> loadRoomMessages(String roomId) async {
    await ensureSignedIn();
    final rows = await client.from('zp_room_messages').select().eq('room_id', roomId).order('created_at', ascending: true).limit(100);
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> sendRoomMessage({required String roomId, required String text}) async {
    await ensureSignedIn();
    await client.from('zp_room_messages').insert({
      'room_id': roomId,
      'sender_id': client.auth.currentUser!.id,
      'message_type': 'text',
      'text': text,
    });
  }

  Future<Map<String, dynamic>> getAgoraToken({required String channel, required int uid}) async {
    await ensureSignedIn();
    final response = await client.functions.invoke('agora-token', body: {
      'channel': channel,
      'uid': uid,
    });
    if (response.data is! Map) throw StateError('Invalid Agora token response');
    return Map<String, dynamic>.from(response.data as Map);
  }

  /// حذف حقيقي للحساب: يستدعي Edge Function تشتغل بصلاحية service-role
  /// (لا يمكن تنفيذ حذف auth.users من طرف العميل مباشرة)، ثم يقطع الجلسة
  /// المحلية بغض النظر عن نجاح استجابة الشبكة.
  Future<void> deleteMyAccount() async {
    await ensureSignedIn();
    try {
      final response = await client.functions.invoke('delete-account');
      if (response.status != 200) {
        throw StateError('delete_account_failed: ${response.status}');
      }
    } finally {
      await client.auth.signOut();
    }
  }

  int stableAgoraUid() {
    final id = client.auth.currentUser?.id;
    if (id == null) return Random().nextInt(0x7fffffff) + 1;
    var hash = 2166136261;
    for (final c in id.codeUnits) {
      hash ^= c;
      hash = (hash * 16777619) & 0x7fffffff;
    }
    return hash == 0 ? 1 : hash;
  }
}
